<template>
  <div class="main" style="position: relative;">
    <div class="row settings-title">
      Account Information
    </div>
    <div class="container">
      <div class="row account">
        <span class="account__text">
          <div class="account__text--title">Name</div>
          <div class="account__text--value" :class="{'blurry-text':!confirmed}">{{ user.firstName }} {{ user.lastName }}</div>
        </span>
        <span class="account__button">
          <button
            type="button"
            class="btn"
            @click="edit('name')">
            Edit
          </button>
        </span>
      </div>
      <div class="row account">
        <span class="account__text">
          <div class="account__text--title">Email Address</div>
          <div class="account__text--value" :class="{'blurry-text':!confirmed}">{{ user.email }}</div>
        </span>
        <span class="account__button">
          <button
            type="button"
            class="btn"
            @click="edit('email')">
            Edit
          </button>
        </span>
      </div>
      <div class="row account">
        <span class="account__text">
          <div class="account__text--title">Password</div>
          <div class="account__text--value">
            You can change the password for accessing your account
          </div>
        </span>
        <span class="account__button">
          <button
            type="button"
            class="btn"
            @click="edit('password')">
            Edit
          </button>
        </span>
      </div>
      <div class="row account">
        <span class="account__text">
          <div class="account__text--title">Store Location</div>
          <div class="account__text--value">{{ user.location }}</div>
        </span>
        <span class="account__button">
          <button
            type="button"
            class="btn"
            @click="edit('location')">
            Edit
          </button>
        </span>
      </div>

    <password-confirm ref="passwordConfirmModal" @confirm="passwordConfirm" />
    </div>
    <div class="m-5"></div>
    <edit-name ref="nameModal" :firstName="user.firstName" :lastName="user.lastName" @changed="nameUpdated" />
    <change-password ref="passwordModal" @changed="passwordUpdated" />
    <edit-email ref="emailModal" :email="user.email" @changed="emailUpdated" />
    <store-location ref="storeSelectionModal" @changed="storeUpdated" />
  </div>
</template>

<script>
import PasswordConfirm from "@/components/modals/password-confirm.vue";
import EditName from '@/components/modals/edit-name.vue';
import ChangePassword from '@/components/modals/change-password.vue';
import EditEmail from '@/components/modals/edit-email.vue';
import StoreLocation from '@/components/modals/store-location.vue';
import UserApiService from '@/api-services/user.service';

export default {
  name: 'SettingsAccountPage',
  components: {
    PasswordConfirm,
    EditName,
    ChangePassword,
    EditEmail,
    StoreLocation
  },
  data() {
    return {
      accountForm: {},
      confirmed: true,
      user: {
        firstName: '',
        lastName: '',
        email: '',
          location: ''
      }
    };
  },
  mounted() {
    UserApiService.getDetails().then(res => {
        const d = res.data.data;
        this.user.firstName = d.first_name;
        this.user.lastName = d.last_name;
        this.user.email = d.email;
        this.user.location = d.store_name;
    });
  },
  methods: {
    edit(type) {
      if(this.confirmed) {
        switch (type) {
          case 'name': {
            this.$refs.nameModal.showModal();
            break;
          }
          case 'email': {
            this.$refs.emailModal.showModal();
            break;
          }
          case 'password': {
            this.$refs.passwordModal.showModal();
            break;
          }
          case 'location': {
              this.$refs.storeSelectionModal.showModal();
              break;
          }
        }
      } else {
        this.$refs.passwordConfirmModal.showModal();
      }
    },
    nameUpdated(obj) {
      this.user.firstName = obj.firstName;
      this.user.lastName = obj.lastName;
    },
    emailUpdated(email) {
      this.user.email = email;
    },
    passwordUpdated() {

    },
    storeUpdated(obj) {
      this.user.location = obj.name;
    },
    passwordConfirm(value) {
      if(value) {
        this.confirmed = true;
      }
    }
  }
};
</script>

<style lang="scss">
  .account {
    border-bottom: 1px solid #eaeaeb;
    margin-top: 15px;
    margin-bottom: 15px;

    &__text {
      margin-right: auto;

      &--title {
        font-weight: 700;
      }

      &--value {
        font-family: 'Courier New', Courier, monospace;
        margin-top: 5px;
        margin-bottom: 5px;
      }
    }

    &__button {
      margin-left: auto;

      .btn {
        border: 2px solid #ed6730;
        color: #ed6730;
      }
    }
  }

  .blurry-text {
    color: transparent;
    text-shadow: 0 0 4px rgba(0,0,0,0.6);
  }
</style>

