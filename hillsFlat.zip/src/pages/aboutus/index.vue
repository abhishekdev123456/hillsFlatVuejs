<template>
  <main>
    <div class="container">
      <div class="row">

        <div class="col-md-8">
          <div class="card">
            <div class="card-body" v-html="content">
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card" v-for="loc in business.about_us.locations" :key="loc.name">
            <div class="card-header">
              {{ loc.name }} Location
            </div>
            <div class="card-body">
              <div class="address" v-html="fullAddress(loc)"></div>
              <div class="phone">{{ loc.phone }}</div>
              <div class="store-hours">
                <span class="hour-title">Store Hours</span>
                <div v-for="(hours, day) in loc.hours" :key="day.dayOfWeek">
                  <div class="row pb-2">
                    <div class="col-md-6">
                      <span>{{ dayName(day) }}</span>
                    </div>
                    <div class="col-md-6">
                      <span class="ml-2">{{ dayHours(hours) }}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </main>
</template>

<script>
import HomePageApiService from '@/api-services/homepage.service';

export default {
  name: 'aboutus',
  data() {
    return {
      info: {},
      content: '',
      business: {
        about_us: {
          locations: []
        }
      }
    };
  },
  computed: {
  },
  async mounted() {
    let resp = await HomePageApiService.getBusinessDetails();
    this.business = resp.data.data;
    this.content = this.business.about_us.description;
  },
  methods: {
    fullAddress(loc) {
        return `<div class="street">${loc.address}</div>
          <b><i><span class="city">${loc.city}</span>,
          <span class="state">${loc.state}</span>
          <span class="zipcode">${loc.zip}</span></i></b>`;
    },
    dayName(day) {
      const map = {
          sun: 'Sunday',
          mon: 'Monday',
          tue: 'Tuesday',
          wed: 'Wednesday',
          thu: 'Thursday',
          fri: 'Friday',
          sat: 'Saturday',
      };
      return map[day];
    },
    dayHours(hours) {
      if ( !hours ) {
          return 'Closed';
      }
      return `${hours.open} - ${hours.close}`;
    }
  }
};
</script>

<style lang="scss" scoped>
  .card {
    margin-bottom: 30px;
    .card-header {
      font-size: 20px;
      font-weight: bold;
      background: #fff;
    }
    .card-body {
      font-size: 14px;
      line-height: 22px;
    }
  }
  .address, .phone {
    background-repeat: no-repeat;
    padding-left: 38px;
    background-position: 0 50%;
  }
  .address {
    background-image: url('data:image/svg+xml;base64,Cjxzdmcgd2lkdGg9IjE3cHgiIGhlaWdodD0iMjNweCIgdmlld0JveD0iMCAwIDE3IDIzIiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPGcgaWQ9IldpcmVmcmFtZXMtZGVzaWducyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9IlN0b3JlLUhvdXJzLSZhbXA7LUluZm8iIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05ODUuMDAwMDAwLCAtNjQ5LjAwMDAwMCkiIGZpbGw9IiNFRDY3MkYiIGZpbGwtcnVsZT0ibm9uemVybyI+CiAgICAgICAgICAgIDxwYXRoIGQ9Ik05OTMuNSw2NDkgQzk4OC44MTMwNzUsNjQ5IDk4NSw2NTIuNzM2Njk2IDk4NSw2NTcuMzI5Njk0IEM5ODUsNjYzLjAyOTc0OCA5OTIuNjA2NjY3LDY3MS4zOTc3NiA5OTIuOTMwNTI4LDY3MS43NTEyMDUgQzk5My4yMzQ3MjMsNjcyLjA4MzIyMyA5OTMuNzY1ODI3LDY3Mi4wODI2MzkgOTk0LjA2OTQ3Miw2NzEuNzUxMjA1IEM5OTQuMzkzMzMzLDY3MS4zOTc3NiAxMDAyLDY2My4wMjk3NDggMTAwMiw2NTcuMzI5Njk0IEMxMDAyLDY1Mi43MzY2OTYgOTk4LjE4Njg3OSw2NDkgOTkzLjUsNjQ5IFogTTk5My41LDY2MS41MjA1OTUgQzk5MS4xNDE4OTEsNjYxLjUyMDU5NSA5ODkuMjIzNDgxLDY1OS42NDA1NjggOTg5LjIyMzQ4MSw2NTcuMzI5Njk0IEM5ODkuMjIzNDgxLDY1NS4wMTg4MiA5OTEuMTQxOTM3LDY1My4xMzg4MzcgOTkzLjUsNjUzLjEzODgzNyBDOTk1Ljg1ODA2Myw2NTMuMTM4ODM3IDk5Ny43NzY0NzMsNjU1LjAxODg2NSA5OTcuNzc2NDczLDY1Ny4zMjk3MzkgQzk5Ny43NzY0NzMsNjU5LjY0MDYxMyA5OTUuODU4MDYzLDY2MS41MjA1OTUgOTkzLjUsNjYxLjUyMDU5NSBaIiBpZD0iU2hhcGUiPjwvcGF0aD4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==');
    line-height: 18px;
    margin-bottom: 20px;
  }
  .phone {
    background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTlweCIgaGVpZ2h0PSIxOHB4IiB2aWV3Qm94PSIwIDAgMTkgMTgiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8ZyBpZD0iV2lyZWZyYW1lcy1kZXNpZ25zIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iU3RvcmUtSG91cnMtJmFtcDstSW5mbyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTk4NC4wMDAwMDAsIC03MTMuMDAwMDAwKSIgZmlsbD0iI0VENjcyRiIgZmlsbC1ydWxlPSJub256ZXJvIj4KICAgICAgICAgICAgPHBhdGggZD0iTTEwMDIuNTc0MDUsNzI3LjIzNzEzMyBMOTk5LjYzOTgwMSw3MjQuNDUwNzA0IEM5OTkuMDU1MzUyLDcyMy44OTc5ODkgOTk4LjA4NzQ5Myw3MjMuOTE0NzgyIDk5Ny40ODI2ODQsNzI0LjQ4OTI2NSBMOTk2LjAwNDM5NCw3MjUuODkyNjEyIEM5OTUuOTEwOTk4LDcyNS44NDM3MzcgOTk1LjgxNDMyNyw3MjUuNzkyNjg0IDk5NS43MTI2ODgsNzI1LjczODUyMiBDOTk0Ljc3OTE2NCw3MjUuMjQ3MzgyIDk5My41MDE0NzcsNzI0LjU3NDIxNSA5OTIuMTU2OTc3LDcyMy4yOTY2NTkgQzk5MC44MDg0OTIsNzIyLjAxNjQwOCA5OTAuMDk4ODc4LDcyMC44MDEzNTggOTg5LjU4MDA0MSw3MTkuOTE0MzkzIEM5ODkuNTI1MjkxLDcxOS44MjA0MjUgOTg5LjQ3MjgzNSw3MTkuNzI5ODI3IDk4OS40MjEwMzMsNzE5LjY0Mzc4OSBMOTkwLjQxMzE4Miw3MTguNzAzMTI3IEw5OTAuOTAwOTYsNzE4LjIzOTQwNSBDOTkxLjUwNjY5Nyw3MTcuNjY0MDkzIDk5MS41MjM0MDEsNzE2Ljc0NTM1NiA5OTAuOTQwMzE2LDcxNi4xOTEwMzQgTDk4OC4wMDYwNjMsNzEzLjQwNDI5NSBDOTg3LjQyMjk3OCw3MTIuODUwNzUxIDk4Ni40NTQ2ODMsNzEyLjg2NzU0NCA5ODUuODQ4OTQ1LDcxMy40NDI4NTYgTDk4NS4wMjE5NzIsNzE0LjIzMjU4OSBMOTg1LjA0NDU3MSw3MTQuMjUzODkxIEM5ODQuNzY3Mjc1LDcxNC41ODk4NTIgOTg0LjUzNTU1OSw3MTQuOTc3MzMzIDk4NC4zNjMxMjMsNzE1LjM5NTE4NiBDOTg0LjIwNDE2OSw3MTUuNzkyOTI5IDk4NC4xMDUyMDYsNzE2LjE3MjQ3OSA5ODQuMDU5OTU0LDcxNi41NTI4MDcgQzk4My42NzI1MDUsNzE5LjYwMjY4OCA5ODUuMTQwMzE0LDcyMi4zOTAwNDkgOTg5LjEyMzc1OSw3MjYuMTcyNDQyIEM5OTQuNjMwMDksNzMxLjQwMDQyNCA5OTkuMDY3NDcsNzMxLjAwNTQ3OSA5OTkuMjU4OTAyLDczMC45ODYxOTkgQzk5OS42NzU4MjgsNzMwLjkzODg3OCAxMDAwLjA3NTM5LDczMC44NDQyODggMTAwMC40ODE0Niw3MzAuNjk0NTUyIEMxMDAwLjkxNzcxLDczMC41MzI3MzkgMTAwMS4zMjU1Miw3MzAuMzEzMDMyIDEwMDEuNjc5MTIsNzMwLjA1MDMwNiBMMTAwMS42OTcxOSw3MzAuMDY1NTQ0IEwxMDAyLjUzNDk3LDcyOS4yODY1OTIgQzEwMDMuMTM5NDUsNzI4LjcxMTM4MyAxMDAzLjE1Njg3LDcyNy43OTIzMzUgMTAwMi41NzQwNSw3MjcuMjM3MTMzIFoiIGlkPSJQYXRoIj48L3BhdGg+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4=');
    font-weight: bold;
  }
  .store-hours {
    margin-top: 20px;
    font-size: 14px;
    .hour-title {
      font-size: 16px;
      font-weight: bold;;
    }
  }
</style>

