<template>
  <div id="wrapper">
    <!-- <div class="brand">
      <img class="brand-logo-image" src="/icons/logo.png" alt="Logo">
      AAA Hardware
    </div> -->
    <div class="container-fluid">
      <div class="card card-primary mb-5">
        <div class="card-header" :class="{'shrink' : message}">
          Sign Up
          <div class="alt-message" v-if="message">{{ message }}</div>
        </div>
        <div class="card-body flex-column">
          <b-form @submit.prevent="signUp">
            <div class="form-group half" style="padding-right: 10px;">
              <label for="first-name">First Name</label>
              <input
                v-model="signUpForm.first_name"
                id="first-name"
                type="text"
                class="form-control"
                required
                placeholder="Enter your first name">
            </div>
            <div class="form-group half" style="padding-left: 10px;">
              <label for="last-name">Last Name</label>
              <input
                v-model="signUpForm.last_name"
                id="last-name"
                type="text"
                class="form-control"
                required
                placeholder="Enter your last name">
            </div>
            <div class="form-group">
              <label for="phone">Mobile phone</label>
              <input
                v-model="signUpForm.telephone"
                id="phone"
                type="tel"
                class="form-control"
                required
                minlength="10"
                maxlength="10"
                placeholder="Enter your phone number">
            </div>
            <div class="form-group">
              <label for="email">Email Address</label>
              <input
                v-model="signUpForm.email"
                id="email"
                type="email"
                class="form-control"
                required
                pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
                placeholder="Enter your email address">
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input
                v-model="signUpForm.password"
                id="password"
                type="password"
                class="form-control"
                required
                pattern=".{8,}"
                title="Password must be at least 6 letters long"
                placeholder="Enter your password">
            </div>
            <div class="mb-5"></div>
            <!-- <div class="form-group pb-5">
              <label for="password">Confirm Password</label>
              <input
                v-model="signUpForm.passwordConfirm"
                id="password-confirm"
                type="password"
                class="form-control"
                required
                placeholder="Re-enter your password">
            </div> -->

            <b-alert
              :show="alert.show"
              :variant="alert.variant"
              dismissible
              @dismissed="alert.show = false">
              {{ alert.message }}
            </b-alert>
            <button class="btn btn-primary mb-3">
              Sign up
            </button>
            <p class="m-0">
              Already have an account?
              <router-link to="/login" class="text-primary">Log In</router-link>
            </p>
          </b-form>
        </div>
      </div>
    </div>
    <footer>
      <hr>
      <div class="container py-0">
        <p>All product and company names are trademarks™ or registered® trademarks of their respective holders. Use of them does not imply any affiliation with or endorsement by them.</p>
      </div>
    </footer>
  </div>
</template>

<script>
import UserApiService from '@/api-services/user.service';
import AuthApiService from '@/api-services/auth.service';
import AuthController from '@/controllers/auth.controller';

export default {
  name: 'SingUpPage',
  data() {
    return {
      alert: {
        show: false,
        variant: 'success',
        message: 'Successfully registered! Please login.'
      },
      signUpForm: {
        first_name: '',
        last_name: '',
        telephone: '',
        email: '',
        password: ''
      },
      message: ''
    };
  },
  beforeMount() {
    const routeParams = this.$route.params;
    if (routeParams) {
      this.signUpForm.email = routeParams.email;
      this.signUpForm.telephone = routeParams.phone;
      this.message = routeParams.message;
    }
  },
  methods: {
    signUp() {
      UserApiService.register(this.signUpForm)
        .then((res) => {
          if(!res || res.data.status === 'error') {
            this.alert.show = true;
            this.alert.variant = 'danger';
            this.alert.message = 'Error occurred during sign up. Please check the fields again';
          } else if(res.data.status === 'success') {
            this.alert.show = true;
            this.alert.variant = 'success';
            this.alert.message = 'Successfully registered! You will be redirected shortly...';
            // setTimeout(() => this.$router.push({name: 'login'}), 2000)
            AuthApiService.login(this.signUpForm.email, this.signUpForm.password, this.$store.state.device_id)
            .then(response => {
              if (response.data.status == "success") {
                let data = response.data;
                data.access_token = response.data.access_token;
                this.$swal({
                  toast: true,
                  position: 'top',
                  showConfirmButton: false,
                  timer: 3000,
                  type: 'success',
                  title: 'Congratulations for registering!'
                });
                AuthController.login(data);
                this.$router.push({name: 'index'});
              }
            })
            .catch((error) => {
              console.log('error while log in', error);
              this.alert.show = true;
              this.alert.variant = 'danger';
              this.alert.message = 'Unsuccessful login. Please try again.';
            });
          }
        })
        .catch(error => {
          console.log('error while signing up', error);
          let errors = error.response.data.errors;
          let firstError = errors[Object.keys(errors)[0]];
          this.alert.show = true;
          this.alert.variant = 'danger';
          this.alert.message = 'Error: ' + firstError;
        });

    },

  }
};
</script>

<style lang="scss" scoped>
@import '@/assets/scss/auth.scss';
.card-header.shrink {
  padding-top: 20px !important;
  padding-bottom: 10px !important;
}
.half {
  width: 50%;
  display: inline-block;
}
.alt-message {
  font-size: 13px;
  font-weight: normal;
}
</style>
