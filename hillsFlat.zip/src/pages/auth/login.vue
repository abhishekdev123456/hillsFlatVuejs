<template>
  <div id="wrapper">
    <!-- <div class="brand">
      <img src="/icons/logo.png" class="brand-logo-image" alt="Logo">
      AAA Hardware
    </div> -->
    <div class="container-fluid">
      <div class="card card-primary mb-5">
        <div class="card-header">
          Sign In
        </div>
        <div class="card-body flex-column">
          <b-form @submit.prevent="login">
            <template v-if="step === 1">
              <div class="form-group">
                <label for="phone">Mobile Number</label>
                <input
                  v-model="phone"
                  id="number"
                  type="tel"
                  minlength="10"
                  maxlength="10"
                  class="phone-input form-control"
                  placeholder="Enter your mobile number"
                  :disabled="this.email != ''"
                >
              </div>
              <center>OR</center>
              <div class="form-group">
                <label for="email">Email</label>
                <input
                  v-model="email"
                  id="email"
                  type="email"
                  class="email-input form-control"
                  placeholder="Enter your email"
                  :disabled="this.phone != ''"
                >
              </div>
              <button
                type="button"
                :disabled="!allowLogin"
                @click="nextStep"
                class="btn btn-primary w-100 mb-5">
                <b-spinner v-if="signingIn" label="Spinning" style="width: 1rem; height: 1rem"></b-spinner>
                <span v-else>Next</span>
              </button>
            </template>
            <div v-if="step === 2">
              <b-alert
                :show="alert.show"
                variant="danger"
                dismissible
                @dismissed="alert.show = false">
                {{ alert.message }}
              </b-alert>
              <auth-with-phone
                v-if="phone.length === 10"
                :phone.sync="phone"
                :code.sync="code" />
              <auth-with-email
                v-else
                :email.sync="email"
                :password.sync="password" />
              <button class="btn btn-primary w-100 mb-2" :disabled="(this.password == '' && this.email == '') && (this.phone == '' && this.code == '') || signingIn">
                <b-spinner v-if="signingIn" label="Spinning" style="width: 1rem; height: 1rem"></b-spinner>
                <span v-else>Sign In</span>
              </button>
              <div class="custom-control custom-checkbox my-4">
                <input id="cbRememberMe" type="checkbox" class="custom-control-input" v-model="loginKeep">
                <label class="custom-control-label" for="cbRememberMe">
                  Keep me signed in
                </label>
              </div>
            </div>
            <hr>
            <p>New at Hills Flat Lumber?</p>
            <router-link to="/register" class="btn btn-outline-primary w-100">
              Create a new account
            </router-link>
          </b-form>
        </div>
      </div>
    </div>
    <footer>
      <hr>
      <div class="container py-0">
        <p>All product and company names are trademarks™ or registered® trademarks of their respective holders. Use of them does not imply any affiliation with or endorsement by them.</p>
      </div>
    </footer>
  </div>
</template>

<script>
import AuthApiService from '@/api-services/auth.service';
import AuthController from '@/controllers/auth.controller';

export default {
  name: 'LoginPage',
  data() {
    return {
      step: 1,
      phone: '',
      email: '',
      password: '',
      code: '',
      alert: {
        show: false,
        message: ''
      },
      loginKeep: false,
      signingIn: false,
    };
  },
  computed: {
    allowLogin() {
      if (this.phone) {
        if (this.phone && this.phone.length === 10) return true;
      } else if (this.email) {
        if (this.email && this.email.length >= 6) return true;
      }
      return false;
    }
  },
  methods: {
    async nextStep() {
      try {
        if (this.phone && this.phone.length === 10) {
          this.signingIn = true;
          const response = await AuthApiService.verifyEmailOrPhone({telephone: this.phone});
          if (response) {
            AuthApiService.sendOTP(this.phone);
            this.signingIn = false;
            this.step = 2;
          }
        } else if (this.email) {
          this.signingIn = true;
          const response = await AuthApiService.verifyEmailOrPhone({email: this.email});
          if (response) {
            this.signingIn = false;
            this.step = 2;
          }
        }
      } catch (e) {
          this.signingIn = false;
          this.$router.push({name: 'register', params: {
            email: this.email,
            phone: this.phone,
            message: 'You’re not a registered user, please sign up to continue'
          }});
      }
    },
    login() {
      this.signingIn = true;
      if (this.phone && this.phone.length === 10) {
        AuthApiService.loginByPhone(this.phone, this.code, this.$store.state.device_id).then(response => {
          let data = response.data;
          // data.access_token = response.data.access_token;
          this.signingIn = false;
          AuthController.login(data);
          if (data.is_admin) {
            this.$router.push({ name: 'admin-orders' });
          } else {
            this.$router.push({ name: 'index' });
          }
        })
        .catch(() => {
            this.signingIn = false;
            this.alert.show = true;
          this.alert.variant = 'danger';
          this.alert.message = 'Unsuccessful login. Please try again.';
        });
      } else if (this.email) {
        AuthApiService.login(this.email, this.password, this.$store.state.device_id).then(response => {
          if(response.data.status == "success") {
              this.signingIn = false;
              let data = response.data;
            data.access_token = response.data.access_token;
            data.loginKeep = this.loginKeep;

            AuthController.login(data);
            if (data.is_admin) {
              this.$router.push({ name: 'admin-orders' });
            } else {
              this.$router.push({ name: 'index' });
            }

          } else {
            console.log('error response', response);
          }
        })
        .catch((error) => {
          this.signingIn = false;
          console.log('error while log in', error.response);
          this.alert.show = true;
          this.alert.variant = 'danger';
          this.alert.message = error.response.data.message || 'Unsuccessful login. Please try again.';
        });
      }
    }
  }
};
</script>

<style lang="scss" scoped>
@import '@/assets/scss/auth.scss';
</style>
