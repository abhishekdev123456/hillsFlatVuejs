<template>
  <div class="product-details-box">
    <img v-if="!product" src="/icons/loader.gif" class="loader py-3">
    <div v-else class="container">
      <div id="productDetails">
        <div class="product-section">
          <div class="header-info">
            <div>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb category">
                  <li
                    v-for="(breadcrumb, index) in breadcrumbs"
                    :key="'product-breadcrumb_' + index"
                    class="breadcrumb-item cursor-pointer"
                    :class="{ active: index === breadcrumbs.length - 1 }"
                    @click="redirectToBreadcrumbsItem(breadcrumb)">
                    {{ breadcrumb.title }}
                  </li>
                </ol>
              </nav>
            </div>
            <div class="flex-row justify-content-start align-items-baseline">
              <div v-if="product.promo_price" class="special alert alert-danger" role="alert">
                <span>SPECIAL</span>${{ product.promo_price }}
              </div>
            </div>
          </div>
          <div class="w-40" style="vertical-align: top; height: 400px;">
            <div class="product-view-box">
              <div id="product-preview">
                <ProductZoomer :base-images="images" :base-zoomer-options="zoomerOptions" />
              </div>
            </div>
          </div>
          <div class="w-60">
            <h2 class="font-weight-bold">{{ product.title }}</h2>
            <p class="model">
              <span v-if="product.sku">SKU <b>#{{ product.sku }}</b></span>
              <span v-if="product.model_number">Model <b>#{{ product.model_number }}</b></span>
              <span v-if="product.upc">UPC <b>#{{ product.upc }}</b></span>
            </p>
            <div class="row mb-5">
              <div class="col-md-5">
                <div class="card card-description regular-price font-weight-bold">
                  <div class="title">
                    Regular Price
                  </div>
                  <div class="card-content">
                    ${{ product.price }}
                  </div>
                </div>
              </div>
              <div class="col-md-7" v-if="productCompetitors && productCompetitors.length">
                <div class="card card-description compare-prices">
                  <div class="title">
                    Compare Prices To
                  </div>
                  <div class="card-content d-flex flex-row p-0">
                    <img v-if="!productCompetitors" src="/icons/loader.gif" class="loader">
                    <div class="d-flex flex-column text-center py-2 competitor"
                    v-for="(competitor, index) in productCompetitors" :key="`competitors-item-${product.id}-${index}`">
                      <div class="font-weight-bold">${{ competitor.price }}</div>
                      <div><img :src="competitor.logo"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="card card-primary">
              <div class="card-body">
                <div class="card-title d-flex">
                  <span class="shop-location mr-2"></span>
                  {{ product.num_inventory > 0 ? 'IN-STORE PICKUP' : 'SPECIAL ORDER FROM VENDOR' }}
                </div>
                <!-- <h6>Deliver to EZ-AD - Canyon Country 91387</h6> -->
                <div v-if="businessDetails.show_stock_level" class="stock-text">
                  <template v-if="product.num_inventory <= 0">
                    <span v-if="businessDetails.show_oos_special && product.vendor_id">
                      This product is out of stock, you an still order this product, it will be shipped from the vendor
                    </span>
                    <span v-else>Out of Stock</span>
                  </template>
                  <template v-else>
                    <template v-if="product.num_inventory > 2">
                      <span class="mr-5">Qty Available: {{product.num_inventory}}</span>
                      <span v-if="product.location">In-Store Location: {{product.location}}</span>
                    </template>
                    <template v-else>
                      <span class="mr-5" style="color: red;">Only {{product.num_inventory}} left</span>
                    </template>
                  </template>
                </div>
                <div class="row quantity">
                  <div class="col-12 align-items-center">
                    <change-quantity
                      :qty="quantity"
                      :cartItem="product"
                      :limit="product.num_inventory"
                      :special="Boolean(product.num_inventory === 0 && !!product.vendor_id && businessDetails.show_oos_special)"
                      @quantityUpdated="quantityUpdated" />

                    <span v-if="product.num_inventory >= 1 && quantity <= product.num_inventory">
                      <img src="/icons/arrow-left.png" />
                      Purchase this product for quick pickup
                    </span>
                    <span v-else>
                      <img src="/icons/arrow-left.png" />
                      This product will be shipped by the vendor
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="box-element mb-4" ref="videoPlayer" style="min-height: 253px;">
            <div class="w-50 h-100">
              <div class="card card-primary offers h-100">
                <div class="card-header">Images & Videos</div>
                <div class="card-body video-gallery p-0 h-100">
                  <img v-if="!productVideos" src="/icons/loader.gif" class="loader mb-3">
                  <p v-if="productVideos && !productVideos.length" class="video-wrapper">
                    No videos for this product
                  </p>
                  <div v-if="productVideos" class="video-wrapper">
                    <div class="row">
                      <div v-for="video in productVideos" :key="'product_video_' + video.id" class="col-sm-6 col-xs-12 video-wrapper my-2">
                        <div @click="changeVideo(video)">
                          <img :src="video.thumbnail" class="thumbnail">
                          <img src="/icons/play.png" class="play">
                          <div class="video-title">
                            {{ video.name }}
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
            <div class="w-50 h-100" ref="productDescription">
              <div class="card card-primary mb-0 h-100">
                <div class="card-header">
                  Product Description
                </div>
                <p>{{product.description}}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer mt-3">
          <div id="product-description">
            <div v-if="similarProducts.length > 0 || !loadedSimilarProducts" class="w-100 mb-4">
              <h4>Customers Also Purchased</h4>
              <div class="position-relative">
                <img v-if="similarProducts.length == 0" src="/icons/loader.gif" class="loader">
                <template v-if="similarProducts">
                  <swiper ref="similarProductsSwiper" class="products-slider" :options="{
                    spaceBetween: 20,
                    autoplay: {
                      delay: 3500
                    },
                    slidesPerView: 'auto',
                    draggable: true,
                    allowTouchMove: true,
                    navigation: {
                      disabledClass: 'd-none',
                      nextEl: '#similar-swiper-button-next',
                      prevEl: '#similar-swiper-button-prev',
                    }}">
                    <swiper-slide v-for="(item, index) in similarProducts" :key="'similar-products-' + index">
                      <product-item :item="item" :internal-api="true"/>
                    </swiper-slide>
                  </swiper>
                  <div class="swiper-button-prev" id="similar-swiper-button-prev" slot="button-prev" />
                  <div class="swiper-button-next" id="similar-swiper-button-next" slot="button-next" />
                </template>
              </div>
            </div>
          </div>
        </div>
      </div>

      <video-lightbox ref="lightbox"/>
    </div>
  </div>
</template>

<script>
  import ProductApiService from '@/api-services/product.service';
  import BrandsApiService from '@/api-services/brands.service';

  export default {
    name: 'SingleProductPage',
    data() {
      return {
        loadedSimilarProducts: false,
        // quantity: 0,
        breadcrumbs: null,
        productVideos: null,
        similarProducts: [],
        productCompetitors: null,
        zoomerOptions: {
          zoomFactor: 3,
          pane: 'pane',
          hoverDelay: 300,
          move_by_click: false
        }
      };
    },
    computed: {
      videoPlayerHeight() {
        return this.$refs.productDescription.clientHeight + 'px';
      },
      product() {
        return this.$store.state.products.find(
          item => item.sku === this.$route.params.id
        );
      },
      popularProducts() {
        return this.$store.state.popularProducts;
      },
      favouriteProducts() {
        return this.$store.state.favouriteProducts;
      },
      popularProductsSwiper() {
        return this.$refs.popularProductsSlider.swiper;
      },
      similarProductsSwiper() {
        return this.$refs.similarProductsSlider.swiper;
      },
      favouriteProductsSlider() {
        return this.$refs.favouriteProductsSlider.swiper;
      },
      outOfStock() {
        return !(this.product.num_inventory - this.quantity);
      },
      quantity: {
        get() {
          const cartItems = this.$store.state.cart.parcels;
          if (cartItems && cartItems.length) {
              let pickupParcel = cartItems.find(item => {
                  return item.type === 'pickup';
              });
              if ( !pickupParcel ) {
                  pickupParcel = {items: []};
              }
              const specialParcels = cartItems.filter(item => {
                  return item.type === 'special';
              });
              let specialItems = [];
              if (specialParcels && specialParcels.length) {
                  specialParcels.forEach(parcel => {
                      if (parcel.items && parcel.items.length) {
                          specialItems = [...specialItems, ...parcel.items];
                      }
                  });
              }
              const items = [...specialItems, ...pickupParcel.items];

              // sum the quantity in all matching items, items.find() just did the first one.
              return items.filter(it => it.store_product_id === this.product.id)
                  .reduce((sum, it) => sum + it.quantity, 0);
          }
          else return 0;
        },
        set(val) {
          return val;
        }
      },
      preferences() {
        return this.$store.state.preferences;
      },
      businessDetails() {
        return this.$store.state.businessDetails;
      },
      images() {
        return {
          'normal_size': [{'id': '1', 'url': this.product.image_url}]
        };
      }
    },
    methods: {
      changeVideo(video) {
        this.$refs.lightbox.changeVideo(video);
      },
      quantityUpdated(value) {
        this.quantity = value;
      },
      redirectToBreadcrumbsItem(breadcrumb) {
        if (!breadcrumb.path) {
          return;
        }
        this.$router.push(breadcrumb.path);
      },
      async fetchData() {
        let params = this.$route.params;

        if (!params.id) {
          return redirect('/');
        }

        let products = this.$store.state.products;
        let product = products.find(item => item.sku === params.id);

        if (!products.length || !product || !product.breadcrumbs) {
          await ProductApiService.getProduct(params.id).then(response => {
            if (!product) {
              product = response.data.data;

              product.competitors = null;
              product.similars = null;
              product.videos = null;

              this.$store.commit('addProduct', product);
            } else {
              product.breadcrumbs = response.data.data.breadcrumbs;
            }
          });
        }

        if (!this.popularProducts) {
          ProductApiService.getPopularProducts(product.sku).then(response => {
            let allProducts = [];

            response.data.data.forEach(item => {
              item.competitors = null;
              item.similars = null;
              item.videos = null;

              allProducts.push(item);
            });

            this.$store.commit('addProductsRange', allProducts);
            this.$store.commit('setPopularProducts', allProducts);

            let allSKUs = [];
            allProducts.forEach(item => {
              allSKUs.push(item.sku);
            });

            if (allSKUs.length) {
              ProductApiService.getCompetitorsForSKUList(allSKUs).then(
                response => {
                  this.$store.commit('setMultiCompetitors', response.data.data);
                }
              );
            }
          });
        }

        if (!product.competitors) {
          ProductApiService.getCompetitors(product.sku).then(response => {
            let payload = {
              productId: product.id,
              data: response.data.competitors,
            };
            this.$store.commit('setCompetitors', payload);
            this.productCompetitors = payload.data;
          });
        } else {
          this.productCompetitors = product.competitors;
        }

        var self = this;
        if (!product.similars) {
          ProductApiService.getSimiliarProducts(product.sku).then(response => {
            let allSKUs = [];
            let similarProducts = {
              productId: product.id,
              data: response.data.data,
            };

            similarProducts.data.forEach(item => {
              allSKUs.push(item.upc);
            });

            if (allSKUs.length) {
              ProductApiService.getCompetitorsForSKUList(allSKUs).then(
                response => {
                  let competitors = response.data.data;

                  similarProducts.data.forEach(item => {
                    item.competitors = competitors[item.upc];
                  });

                  this.$store.commit('setSimilarProducts', similarProducts);
                  this.similarProducts = similarProducts.data;
                  self.loadedSimilarProducts = true;
                }
              );
            }
          }).catch(function () {
              self.loadedSimilarProducts = true;
              self.similarProducts = [];
          });
        } else {
          this.similarProducts = product.similars;
        }
        var self = this;
        if (!product.videos) {
          ProductApiService.getVideos(product.sku).then(response => {
            let payload = {productId: product.id, data: response.data.data};

            this.$store.commit('setProductVideos', payload);
            this.productVideos = payload.data;
          }).catch(function () {
              self.productVideos = [];
          });
        } else {
          this.productVideos = product.videos;
        }

        if (!this.favouriteProducts) {
          ProductApiService.getFavouriteProducts().then(response => {
            let allProducts = [];

            response.data.data.forEach(item => {
              item.competitors = null;
              item.similars = null;
              item.videos = null;

              allProducts.push(item);
            });

            this.$store.commit('addProductsRange', allProducts);
            this.$store.commit('setFavouriteProducts', allProducts);

            let allSKUs = [];
            allProducts.forEach(item => {
              allSKUs.push(item.sku);
            });

            if (allSKUs.length) {
              ProductApiService.getCompetitorsForSKUList(allSKUs).then(
                response => {
                  this.$store.commit('setMultiCompetitors', response.data.data);
                }
              );
            }
          });
        }
      },
      async getBrandNameById(brandId) {
        let response = await BrandsApiService.getBrandById(+brandId);
        response = response.data.data;
        return response.brand_name;
      },
      async setBreadcrumbs() {
        let breadcrumbs = localStorage.getItem('product_breadcrumbs');
        breadcrumbs = JSON.parse(breadcrumbs);
        this.breadcrumbs = [];
        if (breadcrumbs.from === 'brands-id') {
          this.breadcrumbs[0] = {
            title: 'Brands',
            path: '/brands'
          };
          let brandName;
          if (breadcrumbs.params && breadcrumbs.params.brand) {
            brandName = breadcrumbs.params.brand.brand_name;
          } else {
            const brandId = breadcrumbs.fullPath.split('/')[2];
            if (brandId) {
              const brands = this.$store.state.brands && this.$store.state.brands.data;
              if (brands) {
                const brand = brands.find(brand => {
                  return brand.brand_id === +brandId;
                });
                if (brand) {
                  brandName = brand.brand_name;
                } else {
                  brandName = await this.getBrandNameById(brandId);
                }
              } else {
                brandName = await this.getBrandNameById(brandId);
              }
            }
          }
          this.breadcrumbs[1] = {
            title: brandName,
            path: breadcrumbs.fullPath
          };
          this.breadcrumbs[2] = {
            title: this.product.title
          };
        } else if (breadcrumbs.from === 'search') {
          this.breadcrumbs[0] = {
            title: 'Search Results',
            path: breadcrumbs.fullPath
          };

          this.breadcrumbs[1] = {
            title: this.product.title
          };
        } else {
          this.breadcrumbs[0] = {
            title: 'Home',
            path: breadcrumbs.fullPath
          };

          this.breadcrumbs[1] = {
            title: this.product.title
          };
        }
      }
    },
    async mounted() {
      window.scrollTo(0, 0);
      await this.fetchData();
      this.setBreadcrumbs();
      this.$refs.videoPlayer.style.height = this.videoPlayerHeight;

      // Hardcoded description
      this.product.description = 'Is your home decor beginning to look a little boring and bland? Give it an upgrade with the rustic charm and unique design of this entertainment credenza from the Better Homes and Gardens Modern Farmhouse collection. Is your home decor beginning to look a little boring and bland? Give it an upgrade with the rustic charm and unique design of this entertainment credenza from the Better Homes and Gardens Modern Farmhouse collection.';
    },
  };
</script>


<style lang="scss" >
  @import '@/assets/scss/home.scss';

  // NOTE: We need this to hide control box of vue-product-zoomer
  .control-box {
    display: none !important;
  }

  #container-zoomer-pane-container {
    left: 43% !important;
    box-shadow: 3px 3px 15px rgba(0,0,0,.1);
    border: 1px solid #cecece;
  }

  .pr-8 {
    padding-right: 84px;
  }

  .product-details-box {
    background: #f7f7f7;
    padding-top: 30px;
  }

  .card.card-primary > p > button {
    background: transparent;
    border: none;
    color: #ed6730;
  }
  .card.card-primary .shop-location {
    background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjBweCIgaGVpZ2h0PSIyMHB4IiB2aWV3Qm94PSIwIDAgMjAgMjAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8ZyBpZD0iV2Vic2l0ZSIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9IlByb2R1Y3QtRGV0YWlscyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTY1NC4wMDAwMDAsIC01NTMuMDAwMDAwKSI+CiAgICAgICAgICAgIDxnIGlkPSJHcm91cC0yNCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNjM1LjAwMDAwMCwgNTM2LjAwMDAwMCkiPgogICAgICAgICAgICAgICAgPGcgaWQ9Ikdyb3VwLTIzIj4KICAgICAgICAgICAgICAgICAgICA8ZyBpZD0iR3JvdXAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIwLjAwMDAwMCwgMTguMDAwMDAwKSI+CiAgICAgICAgICAgICAgICAgICAgICAgIDxnIGlkPSJzaG9wLWxvY2F0aW9uIj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik0xMC4xMjQxODE4LDguOTk3NTQ1NDUgQzkuMDQyNTQ1NDUsOC45NDM1NDU0NSA4LjE4MTgxODE4LDguMDUwMDkwOTEgOC4xODE4MTgxOCw2Ljk1NDU0NTQ1IEM4LjE4MTgxODE4LDguMDg0NDU0NTUgNy4yNjYyNzI3Myw5IDYuMTM2MzYzNjQsOSBDNS4wMDY0NTQ1NSw5IDQuMDkwOTA5MDksOC4wODQ0NTQ1NSA0LjA5MDkwOTA5LDYuOTU0NTQ1NDUgQzQuMDkwOTA5MDksOC4wODQ0NTQ1NSAzLjE3NTM2MzY0LDkgMi4wNDU0NTQ1NSw5IEMwLjkxNTU0NTQ1NSw5IDAsOC4xNDc0NTQ1NSAwLDYuNTQ1NDU0NTUgTDMuMjcyNzI3MjcsMCBMMTMuMDkwOTA5MSwwIEwxNi4zNjM2MzY0LDYuNTQ1NDU0NTUiIGlkPSJQYXRoIiBzdHJva2U9IiNFRDY3MkYiIHN0cm9rZS13aWR0aD0iMS42MzYzNjM2NCI+PC9wYXRoPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBvbHlsaW5lIGlkPSJQYXRoIiBzdHJva2U9IiNFRDY3MkYiIHN0cm9rZS13aWR0aD0iMS42MzYzNjM2NCIgcG9pbnRzPSIyLjQ1NDU0NTQ1IDkgMi40NTQ1NDU0NSAxNi4zNjM2MzY0IDkgMTYuMzYzNjM2NCI+PC9wb2x5bGluZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik0xOCwxMC42MzYzNjM2IEMxOCwxMy4xNzI3MjczIDEzLjkwOTA5MDksMTcuMjYzNjM2NCAxMy45MDkwOTA5LDE3LjI2MzYzNjQgQzEzLjkwOTA5MDksMTcuMjYzNjM2NCA5LjgxODE4MTgyLDEzLjE3MjcyNzMgOS44MTgxODE4MiwxMC42MzYzNjM2IEM5LjgxODE4MTgyLDguMDE4MTgxODIgMTEuOTQ1NDU0NSw2LjU0NTQ1NDU1IDEzLjkwOTA5MDksNi41NDU0NTQ1NSBDMTUuODcyNzI3Myw2LjU0NTQ1NDU1IDE4LDguMDE4MTgxODIgMTgsMTAuNjM2MzYzNiBaIiBpZD0iUGF0aCIgc3Ryb2tlPSIjRUQ2NzJGIiBzdHJva2Utd2lkdGg9IjEuNjM2MzYzNjQiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiPjwvcGF0aD4KICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGUgaWQ9Ik92YWwiIGZpbGw9IiNFRDY3MkYiIGZpbGwtcnVsZT0ibm9uemVybyIgY3g9IjEzLjkwOTA5MDkiIGN5PSIxMC42MzYzNjM2IiByPSIxIj48L2NpcmNsZT4KICAgICAgICAgICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICAgICAgICAgIDwvZz4KICAgICAgICAgICAgICAgIDwvZz4KICAgICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+');
    background-repeat: no-repeat;
    width: 20px;
    height: 20px;
    display: inline-block;
  }

  .card.card-primary > p > button:focus {
    box-shadow: none;
    outline: none;
  }

  .card.card-primary > .card-body {
    padding: 20px;
  }

  .card .card-body > h6 {
    font-size: 14px;
    margin-bottom: 15px;
    line-height: 16px;
    color: #3E80CE;
  }

  .card .card-body {
    .stock-text {
      font-size: 14px;
      margin-bottom: 15px;
      line-height: 16px;
      color: #979A9F;
      font-weight: bold;
    }
  }

  .actions > div > input {
    width: 80px;
    margin-right: 15px;
    border-radius: 5px;
    border: 1px solid #00000020;
  }

  .card.card-primary {
    .card-body {
      .swiper-container {
        border: none !important;

        .swiper-wrapper {
          .swiper-slide-active {
            .swiper-slide > .discounted-item {
              margin: 0 !important;
            }
          }
        }
      }
    }
  }

  .product-section {
    background: #fff;
    border-radius: 3px;
    border: 1px solid #e9e9e9;
    .model {
      margin-top: 16px;
      margin-bottom: 11px;
    }

    .special span {
      margin-right: 8px;
    }

    .box-element {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 30px 0 20px;

      .card {
        margin-left: 15px;
        margin-right: 15px;

        p {
          padding: 20px 30px;
          margin: 0;
          font-size: 14px;
          line-height: 22px;
        }

        .video-player {
          padding: 10px 20px;
          .row {
            .swiper-button-prev,
            .swiper-button-next {
              height: 30px;
              width: 30px;
              border-radius: 30px;
              opacity: 1;
              box-shadow: 0 1px 2px rgba(0,0,0,.1);
              top: 50%;
              background-size: 16px;
              margin-top: -15px;
              background-color: #fff;
            }
            .swiper-button-next {
              right: 0;
            }
            .swiper-button-prev {
              left: 0;
            }
          }
        }
      }
    }
  }


  .video-gallery {
    overflow-y: auto;
    overflow-x: hidden;
    > .row {
      margin-left: -10px;
      margin-right: -10px;
    }

    .video-wrapper {
      position: relative;
      padding-left: 10px;
      padding-right: 10px;

      img.thumbnail {
        width: 100%;
        height: 100%;
        object-fit: cover;
        cursor: pointer;
      }

      img.play {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        cursor: pointer;
      }

      .video-title {
        position: absolute;
        background-color: rgba(0, 0, 0, 0.4);
        width: calc(100% - 20px);
        color: #fff;
        padding: 0 10px;
        left: 10px;
        bottom: 10px;
        font-size: 14px;
        font-weight: 700;
        line-height: 20px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
    }
  }

  #productDetails .header-info > .w-40 {
    width: calc(40% - 4px);
  }

  #productDetails .header-info > .w-60 {
    width: calc(60% - 4px);
  }

  #product-description {
    padding: 10px 0 !important;

    .offers {
      margin-bottom: 30px !important;
    }

    p {
      padding: 15px !important;
    }
  }

  .product-view-box {
    display: flex;
    justify-content: space-between;
    height: 100%;

    #product-preview {
      flex: 3;
      overflow: hidden;
      border: 1px solid #e2e2e7;
      border-radius: 3px;
      margin-bottom: 0 !important;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 200px;
      min-height: 422px;

      img {
        width: 100%;
        object-fit: contain;
      }
    }

    .product-image {
      flex: 1;
    }
  }

  .image-magnifier__zoom {
    z-index: 999 !important;
    top: -40px !important;
    right: -390px !important;
    left: unset !important;
  }

  @media (max-width: 578px) {
    .pr-8 {
      padding-right: 0;
    }
    .justify-content-end {
      justify-content: flex-start !important;
    }
    #productDetails {
      .product-section {
        h2 {
          font-size: 18px;
          margin-bottom: 0;
        }
        .model {
          display: flex;
          flex-direction: column;
          justify-content: flex-start;
          span {
            margin-left: 0 !important;
            font-size: 13px;
          }
        }
      }

      .product-view-box {
        flex-direction: column;
        flex-grow: 1;

        .product-image {
          order: 1;

          .card-body {
            .video-player {
              display: flex;
              margin-top: 20px;

              .video-wrapper {
                img {
                  min-width: 120px;
                }
              }
            }
          }
        }

        #product-preview {
          width: 100%;
          min-height: 300px;
          img {
            padding: 15px 0;
            max-height: 235px;
            height: auto;
          }
        }
      }

      #product-description {
        .w-60 {
          padding: 0 !important;
        }

        .w-40 {
          padding: 0 !important;
        }
      }
    }
  }

  @media (max-width: 767px) {
    #productDetails .header-info > .w-60 {
      display: flex !important;
      justify-content: flex-start !important;
    }
    .swiper-slide:first-of-type > .discounted-item {
      margin-left: 0 !important;
    }
    .products-slider.swiper-container + .swiper-button-prev {
      left: 0;
    }
    .products-slider.swiper-container ~ .swiper-button-next {
      right: 0;
    }
    .box-element .card-primary {
      margin-top: 30px;
    }
    #product-description {
      padding: 0 !important;
    }
    .box-element {
      margin-top: 0 !important;
    }
    .product-section .w-40 {
      height: 100% !important;
    }
    #productDetails .product-section .model {
      display: flex;
      justify-content: space-between;
      span {
        margin-left: 0 !important;
        font-size: 13px;
      }
    }
    .product-details-box {
      padding-bottom: 10px;
    }

  }
  .preview-box {
    padding: 15px;
  }
  @media (max-width: 992px) {
    .box-element {
      flex-direction: column;

      .w-50 {
        width: 100% !important;

        .card-primary {
          margin-bottom: 30px !important;
        }
      }
    }
    .w-60 {
      h2 {
        font-size: 1.2rem;
      }
    }
    .product-details-box {
      margin-top: 92px;
    }
  }

  @media (max-width: 1199px) {
    .product-section {
      .box-element {
        .card {
          p {
            padding: 15px 15px 0 !important;
            font-size: 14px !important;
          }
        }
      }
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1024px) {
    #productDetails {
      .product-section {
        .w-40 {
          height: 100% !important;
        }
        .w-60 {
          h2 {
            font-size: 20px;
          }
        }
        .model {
          display: flex;
          justify-content: space-between;

          span {
            margin-left: 0 !important;
            font-size: 13px;
          }
        }
      }
      .regular-price {
        .card-content {
          font-size: 24px;
        }
      }
    }
  }
</style>
