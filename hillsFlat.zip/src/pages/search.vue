<template>
  <main>
    <div class="container search-container">
      <div class="row">
        <div class="col-lg-3 filterWrapper" :class="{ 'visible' : showFilters }">
          <div class="card">
            <div class="card-body" style="max-width: 450px;">
              <h5 class="mb-4">Filter Results</h5>
              <a href="#" @click="() => showFilters = false" class="d-lg-none filters-close-bt">
                <svg width="11px" height="11px" viewBox="0 0 11 11" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <g id="Admin-Settings-Wireframes" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                      <g id="Admin-View@2x-Copy-3" transform="translate(-1294.000000, -559.000000)" fill="#FF4E4E">
                        <path d="M1301.89779,564.5 L1305,567.602214 L1302.60221,570 L1299.5,566.897786 L1296.39779,570 L1294,567.602214 L1297.10221,564.5 L1294,561.397786 L1296.39779,559 L1299.5,562.102214 L1302.60221,559 L1305,561.397786 L1301.89779,564.5 Z" id="Combined-Shape"></path>
                      </g>
                    </g>
                  </svg>
              </a>
              <!-- Added filters -->
              <div class="filter-items mb-3" v-if="searchResults && searchResults.total">
                <div v-for="(item, key, index) in data.filters" :key="index">
                  <filter-item v-if="item.value" :filterVal="item.displayValue" @click.native="removeFilter(item, key)" />
                </div>
              </div>
              <!-- Products with promos selection -->
              <div class="mb-3" v-if="hasPromos">
                <b-checkbox id="checkbox-1" name="promo-check" @input="selectPromo" v-model="booleanPromo">
                  {{ data.filters.promo.displayValue }}
                </b-checkbox>
              </div>

              <!-- PRICE FILTERS -->
              <div class="mb-3" v-if="priceRanges && searchResults.total" style="max-width: 200px;">
                <h6>Price</h6>
                <ul class="p-0">
                  <li v-for="price in priceRanges" :key="price.min" class="none-style-list price-range mb-1" @click="selectPrice(price)">
                    {{ price.displayValue }}
                    <span class="item-counts"> {{ price.matched_products }} </span>
                  </li>
                  <li class="none-style-list d-flex">
                    <form @submit="selectPrice({start:priceStart,end:priceEnd})" class="d-flex">
                      <input placeholder="min" type="number" size="sm" class="form-control price-range-select price-min" v-model="priceStart" />
                      -
                      <input placeholder="max" type="number" size="sm" class="form-control price-range-select price-max" v-model="priceEnd" />
                      <button type="submit" class="btn btn-primary price-select-btn">
                        <icon name="chevron-right" style="width: 8px;" class="ml-auto"></icon>
                      </button>
                    </form>
                  </li>
                </ul>
              </div>

              <!-- DEPARTMENT FILTERS -->
              <div class="mb-3" v-if="departmentList && departmentList.length">
                <h6>Departments</h6>
                <b-tree-view class="text-capitalize"
                  :data="departmentList"
                  :contextMenu="false"
                  :renameNodeOnDblClick="false"
                  :contextMenuItems="[]"
                  ref="DepartmentstreeView"
                  @nodeSelect="selectDepartment"
                >
                </b-tree-view>
              </div>

              <!-- BRAND FILTERS -->
              <div v-if="brands && brands.length" class="mb-3">
                <h6>Brands</h6>
                <ul class="p-0">
                  <li class="none-style-list m-1">
                    <b-checkbox v-for="brand in brands" :key="brand.title" class="m-1" v-model="brand.selected" @input="selectBrand(brand)">
                      {{ brand.brand_name }} ({{brand.matched_products}})
                    </b-checkbox>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-9" v-if="searchResults">
          <div class="mb-3 search-result-page">

            <!-- INFO TEXT -->
            <div class="search-result-content mb-2">
              <span>{{ searchResults.total }} Results</span>
              <span v-if="data.query != `''`">&nbsp;for "<b>{{ data.query }}</b>"</span>
              <span v-if="data.filters.departments.value && searchResults.total"> in <b>{{ data.filters.departments.displayShortValue }}</b></span>
            </div>

            <!-- secondary -->
            <div class="d-sm-flex align-items-center w-100" v-if="searchResults.total">
              <div class="d-flex" style="flex: 1;">
                <!-- FILTER BUTTON (MOBILE ONLY) -->
                <a href="#" class="filters-toggle d-lg-none mr-2" @click="() => showFilters = true"></a>
                <!-- SORT OPTIONS -->
                <div class="search-result-content justify-content-end justify-content-sm-start">
                  <v-select :options="sortOptions" v-model="selectedSortMethod" @input="sortBy" style="width: 150px;"></v-select>
                </div>
              </div>
              <!-- PAGINATION -->
              <div class="pt-2 pt-sm-0">
                <v-pagination
                  v-if="searchResults.last_page > 1"
                  v-model="currentPage"
                  :page-count="searchResults.last_page"
                  :classes="bootstrapPaginationClasses"
                  :labels="paginationAnchorTexts"
                  :limit="3"
                  @input="gotoPage"
                  style="margin: 0;"
                />
              </div>
            </div>
          </div>
          <!---->
          <div class="preloader d-flex justify-content-center align-items-center w-100 h-100 mt-5" v-if="isLoading">
            <div class="spinner-border" role="status">
              <span class="sr-only">Loading...</span>
            </div>
          </div>
          <div class="search-product row small-gutters" v-if="searchResults.total > 0 && !isLoading">
            <div v-for="item in searchResults.data" :key="item.upc_id" class="col-md-4 col-xl-3 search-product-item mb-1">
              <product-item :item="item" />
            </div>
          </div>
          <div class="row" style="justify-content: center" v-if="searchResults.total == 0 && !isLoading">
            <span class="text-center">
              No products were found for this search
            </span>
          </div>
          <!-- PAGINATION -->
          <div class="d-sm-flex pt-4 justify-content-end w-100" v-if="searchResults.total">
            <div>
              <v-pagination
                v-if="searchResults.last_page > 1"
                v-model="currentPage"
                :page-count="searchResults.last_page"
                :classes="bootstrapPaginationClasses"
                :labels="paginationAnchorTexts"
                :limit="3"
                @input="gotoPage"
                style="margin: 0;"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
import { bTreeView } from 'bootstrap-vue-treeview';
import { paginationConfig } from '@/config/modules';
import FilterItem from '@/components/search/filter-item.vue';
import VSelect from '@alfsnd/vue-bootstrap-select';
import DepartmentsService from '@/api-services/departments.service';

export default {
  name: 'search',
  components: {
    FilterItem,
    bTreeView,
    VSelect
  },
  props: [
    'keyword', 'deptId', 'deptName'
  ],
  data() {
    return {
      ...paginationConfig,
      currentPage: 1,
      hasPromos: false,
      showFilters: false,
      isLoading: false,
      priceStart: null,
      priceEnd: null,
      sortOptions: [
        {value: "relevancy", text: "Relevancy"},
        {value: "price-desc", text: "Price High to Low"},
        {value: "price-asc", text: "Price Low to High"},
        {value: "latest", text: "New Arrivals"},
        {value: "title-asc", text: "Alphabetical"},
      ]
    };
  },
  computed: {
    searchResults: {
      get: function() {
        if(this.$store.state.searchResults)
          return this.$store.state.searchResults.products;
        return null;
      },
      set: function(val) {
        this.results = val;
      }
    },
    departments() {
      return this.$store.state.departmentResults;
    },
    departmentList() {
      // if we have departments from results use that
      if(this.$store.state.searchResults) {
        return this.$store.state.searchResults.departments.map(d => {
          let name = d.dept_name.charAt(0) + d.dept_name.toLowerCase().slice(1);
          d.dept_name = name;
          d.name = name + ' (' + d.count + ')';
          return d;
        });
      }
      if(this.departments) return this.departments.parent_departments;
      return null;
    },
    brands() {
      return null;
    },
    // Get a department name by Id
    selectedDepartment() {
      if(this.departmentList && this.$route.query['dept_id']) {
        let ret = this.departmentList.filter(e => e.dept_id == this.$route.query['dept_id'])[0];
        if(ret)
          return ret;
      }
      return {id: null, name: ''};
    },
    // Get the Selected Price
    selectedPriceRange() {
      let staq = this.$route.query['start_price'];
      let endq = this.$route.query['end_price'];
      let display = '';
      // if there are no price queries invoked on url
      if(staq == undefined && endq == undefined) return { value: false, displayValue: '' };
      if(staq && !endq)
        display = `more than $${staq}`;
      else if(!staq && endq)
        display = `less than $${endq}`;
      else
      display = `$${staq} - $${endq}`;
      return {
        value: {
          start: staq || 0,
          end: endq || 1000000
        },
        displayValue: display
      };
    },
    // Get a department name by Id
    selectedSortMethod: {
      get() {
        if(this.$route.query['sort'])
          return this.sortOptions.filter(e => e.value == this.$route.query['sort'])[0];
        return this.sortOptions[0];
      },
      set(val) {
        return val;
      }
    },
    priceRanges() {
      if(!this.$store.state.searchResults) return null;
      let textData = [[0, 50], [50, 150], [150, 250], [250, 500], [500, null]];
      return this.$store.state.searchResults.priceRanges.filter(e => e.matched_products > 0).map(e => {
        e.value = e.range;
        e.displayValue = textData[e.value][1] == null ? 'more than $500' : `$${textData[e.value][0]} - $${textData[e.value][1]}`;
        e.start = textData[e.value][0];
        e.end = textData[e.value][1];
        return e;
      });
    },
    data() {
      return {
        query: this.$route.query['keyword'] || "''",
        currentPage: 1,
        filters: {
          departments: {
            value: this.$route.query['dept_id'],
            displayValue: this.selectedDepartment.name,
            displayShortValue: this.selectedDepartment.dept_name
          },
          price: {
            value: this.selectedPriceRange.value,
            displayValue: this.selectedPriceRange.displayValue
          },
          promo: {
            value: this.$route.query['promo'],
            displayValue: 'Promo Products'
          }
        },
        sort: this.selectedSortMethod
      };
    },
    booleanPromo: {
      get() {
        return Boolean(Number(this.data.filters.promo.value));
      },
      set(val) {
        return val;
      }
    }
  },
  methods: {
    // Sort By
    sortBy(val) {
      this.$router.push({ query: Object.assign({}, this.$route.query, { sort: val.value }) });
    },
    // Select department from filters list
    selectDepartment(node) {
      this.$router.push({ query: Object.assign({}, this.$route.query, { dept_id: node.data.dept_id }) });
    },
    selectPromo(value) {
      this.$router.push({ query: Object.assign({}, this.$route.query, { promo: Number(value) }) });
    },
    // Select a price from the list
    selectPrice(price) {
      this.$router.push({ query: Object.assign({}, this.$route.query, { start_price: price.start }) });
      this.$router.push({ query: Object.assign({}, this.$route.query, { end_price: price.end }) });
    },
    // Remove a selected sidebar filter
    removeFilter(item, key) {
      let newRouteQuery = {};
      switch(key) {
        case 'departments':
          Object.keys(this.$route.query).forEach(key => { if (key != 'dept_id') newRouteQuery[key] = this.$route.query[key]; });
          break;
        case 'promo':
          Object.keys(this.$route.query).forEach(key => { if (key != 'promo') newRouteQuery[key] = this.$route.query[key]; });
          break;
        case 'price':
          Object.keys(this.$route.query).forEach(key => { if (key != 'end_price' && key != 'start_price') newRouteQuery[key] = this.$route.query[key]; });
          break;
      }
      this.$router.replace({ query: newRouteQuery });
    },
    // Navitagion Methods
    gotoPage() {
      this.data.currentPage = this.currentPage;
      this.getSearch();
    },
    // Search function
    getSearch() {
      this.isLoading = true;
      this.$store.dispatch('search', {
        search: this.data.query,
        dept_id: this.selectedDepartment ? this.selectedDepartment.dept_id : '',
        page: this.data.currentPage,
        start_price: this.data.filters.price.value.start,
        end_price: this.data.filters.price.value.end,
        sort: this.data.sort.value,
        promo: this.data.filters.promo.value
      }).then(() => {
        this.isLoading = false;
      });
    }
  },
  async mounted() {
    // Get and set departments to storage through API if empty
    if(!this.departments) {
      let departments_response = await DepartmentsService.getDepartments();
      this.$store.commit('saveDepartments', departments_response.data.data);
    }
    // Get search
    this.getSearch();
  },
};
</script>

<style scoped lang="scss">
  .filters-toggle {
    background: #fff url('/icons/filters.svg') no-repeat;
    background-size: 22px;
    width: 32px;
    height: 32px;
    border-radius: 4px;
    background-position: center;
  }
  .filters-close-bt {
    position: absolute;
    top: 20px;
    right: 20px;
  }
  .discounted-item {
    width: auto !important;
    margin: 0 !important;
  }

  .promo-check {
    font-size: 16px;
  }

  .none-style-list {
    list-style: none;
  }

  li {
    font-size: 12px;
  }

  .price-range {
    color: #ed6730;
    cursor: pointer;
  }

  .tree-view {
    font-size: 12px;
  }

  .item-counts {
    font-size: 11px;
    color: grey;
  }

  .item-counts::before {
    content: '(';
  }
  .item-counts::after {
    content: ')';
  }

  .price-range.selected {
    font-weight: 500;
  }

  .price-range-select {
    padding: 0;
    font-size: 12px;
    height: 25px;
    text-align: center;
    max-width: 70px;
  }

  .price-range-select.price-min {
    margin-right: 5px;
  }

  .price-range-select.price-max {
    margin-left: 5px;
  }

  .price-select-btn {
    padding: 0px 8px;
    margin-left: 10px;
    height: 25px;
  }

  .departments-list.active {
    color: #48ce3d;
  }

  li.indent-2 {
    margin-left: 10px !important;
  }

  li.indent-2::before, li.indent-3::before {
    content: '↳';
    /* content: '\2713'; */
    margin-right: 5px;
  }

  li.indent-3 {
    margin-left: 20px !important;
  }

  .v-select {
    width: 150px;
  }
  @media (max-width: 991px) {
    .tree-view {
      column-count: 2;
    }
    .filterWrapper {
      position: fixed;
      z-index: 10000;
      top: 0px;
      overflow: auto;
      height: 100%;
      left: -15px;
      width: calc(100% + 30px);
      opacity: 0;
      pointer-events: none;
      transition: .2s opacity;
      > .card {
        margin: 0;
      }
      &.visible {
        opacity: 1;
        pointer-events: all;
      }
    }
  }
  @media screen and (max-width: 767px) {
    .search-product-item {
      width: 50%;
    }
    .card {
      margin-top: 20px;
    }
    .search-result-page {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
    }
    .search-result-content {
      text-align: center;
      width: 100%;
      display: flex;
    }
  }
  .preloader {
    z-index: 1000;
  }
  @media screen and (max-width: 576px) {
    .search-product-item {
      width: 100%;
      padding: 0 15px;
    }
  }

  @media screen and (min-width: 768px) and (max-width: 1024px) {
    .search-container .search-product-item {
      max-width: 33.33%;
      flex: unset;
    }
    .search-container .search-product .search-product-item .product h6 {
      font-size: 12px;
    }
    .product .info > div {
      font-size: 12px !important;
    }
    .search-container {
      margin-top: 30px;
    }
    .none-style-list {
      display: flex;
      justify-content: space-between;
      align-items: center;
      input {
        min-width: 30px;
        max-width: 50px;
      }
    }
  }
</style>