<template>
  <main v-if="brand" class="bg-white">
    <div class="container mt-3">
      <div class="row">
        <div class="col-12">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb category mb-4">
              <li class="breadcrumb-item"><router-link to="/brands">Brands</router-link></li>
              <li class="breadcrumb-item active">{{ brand.brand_name }}</li>
            </ol>
          </nav>
        </div>
      </div>
      <div class="row brand-details">
        <div class="col-12">
          <div class="image-wrapper">
            <img :src="brand.image">
          </div>
          <div class="info">
            <h4>{{ brand.brand_name }}</h4>
            <table>
              <tr>
                <td>
                  <h3>{{ brand.products_count }}</h3>
                  <span>Products</span>
                </td>
                <td class="p-0">
                  <h3>{{ brand.videos_count }}</h3>
                  <span>Videos</span>
                </td>
              </tr>
            </table>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <b-tabs content-class="mt-4" class="mt-5 brand-mob">
            <b-tab title="PRODUCTS" active :title-link-class="'mr-5'">
              <div class="d-sm-flex align-items-center mb-3" v-if="brand.products">
                <div style="flex:1;">
                  <input type="text" class="form-control search-input ml-0" @input="doSearch" v-model="searchQuery" />
                </div>
                <div class="pt-2 px-sm-3 pt-sm-0">
                  <v-pagination
                    class="m-0"
                    ref="top-pagination"
                    v-model="pagination.currentPage"
                    :page-count="pagination.pages"
                    :classes="bootstrapPaginationClasses"
                    :labels="paginationAnchorTexts"
                    @change="goToPage('products')"/>
                </div>
                <div class="mt-sm-0 mt-3">
                  <v-select
                    :options="sortOptions"
                    v-model="sortBy"
                    @input="doSort"
                    :disabled="isProcessing"
                  ></v-select>
                </div>
              </div>
              

              <div v-if="brand.products && brand.products.length === 0">
                There are no products containing "{{ searchQuery }}". Please try with a different query.
              </div>
              <div class="row small-gutters" v-else>
                <img v-if="!brand.products" src="/icons/loader.gif" class="loader">
                <div v-for="(item, index) in brand.products" :key="keyPrefix + index" class="col-sm-6 col-md-4 col-lg-3 mb-1">
                  <product-item :item="item" />
                </div>
              </div>

              <v-pagination
                v-if="brand.products"
                v-model="pagination.currentPage"
                :page-count="pagination.pages"
                :classes="bootstrapPaginationClasses"
                :labels="paginationAnchorTexts"
                @change="goToPage('products')"/>
            </b-tab>
            <b-tab title="VIDEOS">
              <div class="row">
                <img v-if="!brand.videos" src="/icons/loader.gif" class="loader">
                <div class="col-sm-6 col-lg-4" v-for="(item, index) in brand.videos" :key="'brand-products-' + index">
                  <media-item :media="item" :video="true" @click.native="changeVideo(item)" />
                </div>
              </div>
            </b-tab>
          </b-tabs>
        </div>
      </div>
    </div>

    <video-lightbox ref="lightbox" />
  </main>
</template>

<script>
import { debounce } from "debounce";
import { paginationConfig } from '@/config/modules';
import BrandsApiService from '@/api-services/brands.service';
import ProductApiService from '@/api-services/product.service';
import VSelect from '@alfsnd/vue-bootstrap-select';

export default {
  name: 'SingleBrandPage',
  components: {
    VSelect
  },
  props: {
    brandProp: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      ...paginationConfig,
      brand: null,
      keyPrefix: 'product_index_' + Date.now() + '_',
      pagination: {
        pages: 1,
        currentPage: 1,
        perPage: 30,
        total: 0
      },
      sortOptions: [
        {value: "price-desc", text: "Price High to Low"},
        {value: "price-asc", text: "Price Low to High"},
        {value: "latest", text: "New Arrivals"},
        {value: "title-asc", text: "Alphabetical"},
      ],
      searchQuery: '',
      sortBy: { text: 'Price High to Low', value: 'price-desc'},
      isProcessing: false,
    };
  },
  async mounted() {
    let brand_id = this.$route.params.id;
    if (!this.brandProp) {
      let response = await BrandsApiService.getBrandById(brand_id);

      if (!response) this.$router.push({ name: 'index' });
      response = response.data.data;
      this.brand = response;
    } else {
      this.brand = this.brandProp;
    }
    BrandsApiService.getVideos(brand_id).then(response => {
      this.$set(this.brand, 'videos', response.data.data);
    });

    this.goToPage('products');
  },
  methods: {
    urlFriendly(value) {
      return value.replace(/[ /]/g, '+');
    },
    doSort() {
      this.goToPage('products');
    },
    doSearch: debounce(function() {
        this.goToPage('products');
    }, 500),
    changeVideo(video) {
      this.$refs.lightbox.changeVideo(video);
    },
    async goToPage(type) {
      if (this.isProcessing) return;
      this.isProcessing = true;
      let response;
      let settings = this.pagination;
      let brand_id = this.$route.params.id;

      if (type === 'products') {
        response = await BrandsApiService.getProducts(brand_id, settings.currentPage, settings.perPage, this.sortBy.value, this.searchQuery);
      }

      response = response.data.data;
      settings.total = response.total;
      settings.currentPage = response.current_page;
      settings.pages = Math.ceil(settings.total / settings.perPage);
      this.$set(this.brand, type, response.data);
      if (type === 'products') {
        let allSKUs = [];
        let allProducts = [];
        response.data.forEach((item) => {
          item.competitors = null;
          item.similars = null;
          item.videos = null;

          allProducts.push(item);
          allSKUs.push(item.sku);
        });

        this.$store.commit('addProductsRange', allProducts);
        if (allSKUs.length) {
          ProductApiService.getCompetitorsForSKUList(allSKUs)
          .then((response) => {
            let competitors = response.data.data;
            this.$store.commit('setMultiCompetitors', competitors);
            this.setCompetitors(competitors);
          });
        } else {
          this.isProcessing = false;
        }
      }
    },
    setCompetitors(competitors) {
      let products = this.brand.products;
      products = products.map((product) => {
        product.competitors = competitors[product.sku];
        return product;
      });
      this.brand.products = Object.assign({}, products);
      this.keyPrefix = 'product_index_' + Date.now() + '_';
      this.isProcessing = false;
    }
  }
};
</script>


<style scoped>
  .search-input {
    background-image: url('data:image/svg+xml;base64,Cjxzdmcgd2lkdGg9IjE0cHgiIGhlaWdodD0iMTRweCIgdmlld0JveD0iMCAwIDE0IDE0IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPGcgaWQ9IlN5bWJvbHMiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIG9wYWNpdHk9IjAuNSI+CiAgICAgICAgPGcgaWQ9IlNlYXJjaC1iYXIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01MzYuMDAwMDAwLCAtMTMuMDAwMDAwKSIgZmlsbD0iIzJGMzU0MCIgZmlsbC1ydWxlPSJub256ZXJvIj4KICAgICAgICAgICAgPGcgaWQ9IlNlYXJjaC1CYXIiPgogICAgICAgICAgICAgICAgPHBhdGggZD0iTTU0OC41MDgxMTQsMjYuNzQwNTQ4MSBDNTQ4Ljg0OTc5MSwyNy4wODY0ODQgNTQ5LjQwMjA2NiwyNy4wODY0ODQgNTQ5Ljc0Mzc0MywyNi43NDA1NDgxIEM1NTAuMDg1NDE5LDI2LjM5NDYxMjMgNTUwLjA4NTQxOSwyNS44MzQ5ODQ2IDU0OS43NDM3NDMsMjUuNDg5MDQ4NyBMNTQ3LjA0NzQ3NSwyMi43OTQzMTI3IEM1NDcuODEwMDMzLDIxLjc3MjI4MTEgNTQ4LjI2MTQ3MiwyMC41MDQ0NzE5IDU0OC4yNjE0NzIsMTkuMTMxMjE1MyBDNTQ4LjI2MTQ3MiwxNS43NDUwMzg2IDU0NS41MTY2NDgsMTMgNTQyLjEzMDczNiwxMyBDNTM4Ljc0NDgyNCwxMyA1MzYsMTUuNzQ1MDM4NiA1MzYsMTkuMTMxMjE1MyBDNTM2LDIyLjUxNzM5MiA1MzguNzQ0ODI0LDI1LjI2MjQzMDYgNTQyLjEzMDczNiwyNS4yNjI0MzA2IEM1NDMuNTA5MDUyLDI1LjI2MjQzMDYgNTQ0Ljc4MTEzMywyNC44MDc1NTMxIDU0NS44MDUwNzIsMjQuMDM5NzE4MiBMNTQ4LjUwODExNCwyNi43NDA1NDgxIFogTTUzNy43NTE2MzksMTkuMTMxMjE1MyBDNTM3Ljc1MTYzOSwxNi43MTI1MTc3IDUzOS43MTIyMjcsMTQuNzUxNzc1OCA1NDIuMTMwNzM2LDE0Ljc1MTc3NTggQzU0NC41NDkyNDQsMTQuNzUxNzc1OCA1NDYuNTA5ODMzLDE2LjcxMjUxNzcgNTQ2LjUwOTgzMywxOS4xMzEyMTUzIEM1NDYuNTA5ODMzLDIxLjU0OTkxMyA1NDQuNTQ5MjQ0LDIzLjUxMDY1NDggNTQyLjEzMDczNiwyMy41MTA2NTQ4IEM1MzkuNzEyMjI3LDIzLjUxMDY1NDggNTM3Ljc1MTYzOSwyMS41NDk5MTMgNTM3Ljc1MTYzOSwxOS4xMzEyMTUzIFoiIGlkPSJMb3VwZS1JY29uIj48L3BhdGg+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPgo=');
    background-repeat: no-repeat;
    background-position: right 10px center;
    max-width: 300px;
  }


  .discounted-item {
    width: 100% !important;
    margin: 0;
  }

  @media (max-width: 576px) {
    .brand-details .image-wrapper {
      margin-right: 10px;
    }
    .mobile-padding {
      padding: 0 15px 30px;
    }
    .brand-mob {
      margin-top: 1rem !important;
    }
    .search-input {
      max-width: initial;
    }
  }
</style>
