<template>
  <main>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-3 d-md-block sidebar pr-md-1">
          <div class="sidebar-sticky bg-white h-100">
            <ul class="nav flex-md-column my-2 my-md-4 justify-content-center">
              <li class="nav-item">
                <router-link to="/admin/settings/about-us" class="nav-link">About Us</router-link>
              </li>
              <li class="nav-item">
                <router-link to="/admin/settings/pos-data-syncer" class="nav-link">POS Data Syncer</router-link>
              </li>
              <li class="nav-item">
                <router-link to="/admin/settings/fulfillment-options" class="nav-link">Fulfillment Options</router-link>
              </li>
              <li class="nav-item">
                <router-link to="/admin/settings/social-media-accounts" class="nav-link">Social Media Accounts</router-link>
              </li>
              <li class="nav-item">
                <router-link to="/admin/settings/bank" class="nav-link">Bank Settings</router-link>
              </li>
<!--              <li class="nav-item">-->
<!--                <router-link to="/admin/settings/tax-settings" class="nav-link">Tax Settings</router-link>-->
<!--              </li>-->
            </ul>
          </div>
        </div>
        <div class="col-md-9 pl-md-1">
          <div class="content bg-white h-100">
            <router-view></router-view>
          </div>
        </div>
      </div>
    </div>
  </main>
</template>

<script>

  export default {
    name: 'AdminSettings',
    data() {
      return {
      };
    },
    computed: {
    },
    async mounted() {
    },
    methods: {
    }
  };
</script>

<style lang="scss" scoped>
  $primary: #ED6730;
  .sidebar-sticky,
  .content {
    border: 1px solid #eaeaeb;
  }
  .sidebar-sticky {
    .nav {
      .nav-item {
        .nav-link {
          color: #707070;
          &.router-link-exact-active {
            color: $primary;
            cursor: default;
          }
        }
      }
    }
  }

  @media (max-width: 767px) {
    .sidebar-sticky {
      .nav {
        .nav-item {
          .nav-link {
            font-size: 14px;
          }
        }
      }
    }
  }
</style>
