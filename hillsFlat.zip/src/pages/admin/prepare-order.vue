<template>
  <div class="container">
    <h5 class="page-breadcrumbs">Prepare Order</h5>
    <div class="prepare-order">
      <div class="customer-detail">
        <div class="order-header">
          <h4>Prepare Order #{{ order.id }}</h4>
          <button class="btn btn-outline-secondary" @click="showMsgBoxTwo">Cancel</button>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="order-details-info">
              <div class="card-customer">
                <span class="person-detail">
                  <h5>Customer Details</h5>
                  <h3>{{ order.first_name }} {{ order.last_name }}</h3>
                </span>
                <p v-if="order.order_type === 'shipping'">{{ order.address }}<br>
                  {{ order.address2 || '' }}<br>
                  {{ order.city }}, {{ order.state }} {{ order.zip }}
                </p>
                <p v-else>
                  {{ order.address }}, {{ order.zip }}
                </p>
                <div class="contact-detail">
                  <div>{{ order.telephone }}</div>
                  <div>{{ order.email }}</div>
                </div>
              </div>
              <div class="details-info">
                <a :href="`tel:${order.telephone}`"><img src="/icons/phone.png"/>Call</a>
                <a :href="`mailto:${order.email}`"><img src="/icons/mail.png"/>Email</a>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="order-type-details">
            <span class="person-detail mb-1">
              <h6>Order Type</h6>
              <h5 class="blue" v-if="order.order_type === 'shipping'">Shipping</h5>
              <h5 class="green" v-if="order.order_type === 'pickup'">Pickup</h5>
              <h5 class="orange" v-if="order.order_type === 'delivery'">Delivery</h5>
            </span>
              <span class="person-detail mb-1">
              <h6>Parcel Type</h6>
              <h5 class="blue" v-if="parcelType === 'special'">Special</h5>
              <h5 class="green" v-if="parcelType === 'pickup'">Pickup</h5>
              <h5 class="orange" v-if="parcelType === 'delivery'">Delivery</h5>
            </span>
              <span class="person-detail mb-2">
              <h6 v-if="parcelType === 'shipping'">Shipping Time</h6>
              <h6 v-if="parcelType === 'pickup'">Pickup Time</h6>
              <h6 v-if="parcelType === 'delivery'">Delivery Time</h6>
              <span>04/25/2019 &nbsp;<p>3:00-4:00 PM</p></span>
            </span>
              <span class="person-detail">
              <h6>Order Placed</h6>
             <span>04/25/2019 &nbsp;<p>3:00-4:00 PM</p></span>
            </span>
            </div>
          </div>
        </div>
      </div>
      <div class="prepare-items-box">
        <b-tabs :no-key-nav="true">
          <b-tab :disabled="disableFirstTab" :title-link-class="{'disable-tab': activeTab > 0}">
            <template slot="title">
              <div class="num" v-if="activeTab > 0"><img src="/icons/d-check.png"/></div>
              <div class="num" v-else>1</div>
              <div>Prepare Items</div>
            </template>
          </b-tab>
          <b-tab :disabled="disableSecondTab" :title-link-class="{'disable-tab': activeTab > 1}" v-if="parcelType != 'special'">
            <template slot="title">
              <div class="num" v-if="activeTab > 1"><img src="/icons/d-check.png"/></div>
              <div class="num" v-else>2</div>
              <div>Package</div>
            </template>
          </b-tab>
          <b-tab :disabled="disableThirdTab">
            <template slot="title">
              <div class="num">
                {{ parcelType == 'special' ? '2' : '3' }}
              </div>
              <div>Mark as Prepared</div>
            </template>
          </b-tab>
          <template v-if="activeTab == 0">
            <div v-if="fetchingParcelDetails" class="d-flex p-4 justify-content-center" style="z-index:2;background:rgba(255,255,255,.7)">
              <b-spinner label="Spinning"></b-spinner>
            </div>
            <div v-else class="items-pick">
              <h4>Pick the items to prepare them for shipping.</h4>
              <h6>Check off all of the items on the checklist before proceeding.</h6>
              <div class="item-table p-3 w-100">
                <div class="order-table">
                  <template v-if="currentParcel">
                    <div class="table-header" v-if="parcelType === 'special'">
                      <h5>SPECIAL ORDER FROM Vendor ({{currentParcel.special_vendor}})</h5>
                    </div>
                    <div class="table-header" v-else>
                      <h5>{{currentParcel.business_address + ', ' + currentParcel.business_city}}</h5>
                    </div>
                    <b-table striped hover :items="parcelItems" :fields="fields" thead-class="d-none">
                      <template v-slot:cell(checklist)="data">
                        <div class="pt-3 custom-control custom-checkbox text-center">
                          <input type="checkbox" autocomplete="off"
                                 class="custom-control-input"
                                 :id="'prepare-shipping-item-' + data.index">
                          <label class="custom-control-label" :for="'prepare-shipping-item-' + data.index"></label>
                        </div>
                      </template>
                      <template v-slot:cell(image_url)="data">
                        <img :src="data.item.image_url" height="50" width="50"/>
                      </template>
                      <template v-slot:cell(title)="data">
                        {{data.item.title}}
                      </template>
                      <template v-slot:cell(brand_name)="data">
                        {{data.item.brand_name}}
                      </template>
                      <template v-slot:cell(price)="data">
                        ${{data.item.price}}
                      </template>
                      <template v-slot:cell(email_action)="data">
                        <a class="email-button" :href="`mailto:${order.email}`" v-if="parcelType == 'special'">
                          <img class="mr-1" src="/icons/mail.png"/>
                          Email
                        </a>
                        <a class="email-button" href="#" v-else>
                          Out of order
                        </a>
                      </template>
                    </b-table>
                  </template>
                  <div class="total-custom" v-if="parcelItems && parcelItems.length">
                    <div class="pages">
                      <span><p>Subtotal ({{parcelItems.length}} items)</p><h5>${{this.subTotalAmount | toDollar(this.subTotalAmount)}}</h5></span>
                      <span><p>Taxes</p><h5>${{this.taxAmount | toDollar(this.taxAmount)}}</h5></span>
                      <span><p>Total</p><h5>${{this.totalAmount | toDollar(this.totalAmount)}}</h5></span>
                    </div>
                  </div>
                </div>
                <div class="btn-badges flex-end">
                  <button class="btn btn-primary" @click="setActiveTab(parcelType == 'special' ? 2 : 1)">
                    Next <img src="/icons/arrow-right.png" class="ml-2"/></button>
                </div>
              </div>
            </div>
          </template>
          <template v-if="activeTab == 1 && parcelType != 'special'">
            <div class="wrapper-content">
              <ul>
                <li>
                  <a>
                    <div class="round-head">1</div>
                    <span>
                      <h3>Packing</h3>
                      <p>Protect the items with protective packing material, for example wrapping the products with bubble
                        wrap or filling the box with peanuts. When completed, place the items into your box. </p>
                    </span>
                    <div class="check">
                      <div class="m-1 custom-control custom-checkbox">
                        <input type="checkbox" autocomplete="off"
                               class="custom-control-input"
                               id="package-packing"/>
                        <label class="custom-control-label" for="package-packing"></label>
                      </div>
                    </div>
                  </a>
                </li>
                <li>
                  <a>
                    <div class="round-head">2</div>
                    <span>
                      <h3>Order Receipt</h3>
                      <p>Print and insert this document inside of the box as a receipt confirmation. </p>
                    </span>
                    <button class="btn btn-outline-primary"><img src="/icons/printer.png"/>Print</button>
                    <div class="check">
                      <div class="m-1 custom-control custom-checkbox">
                        <input type="checkbox" autocomplete="off"
                               class="custom-control-input"
                               id="package-order-receipt"/>
                        <label class="custom-control-label" for="package-order-receipt"></label>
                      </div>
                    </div>
                  </a>
                </li>
                <li v-if="parcelType !== 'pickup'">
                  <a>
                    <div class="round-head">3</div>
                    <span>
                      <h3>Shipping Label</h3>
                      <p>Print and paste this document on the outside of the box. </p>
                    </span>
                    <button class="btn btn-outline-primary"><img src="/icons/printer.png"/>Print</button>
                    <div class="check">
                      <div class="m-1 custom-control custom-checkbox">
                        <input type="checkbox" autocomplete="off"
                               class="custom-control-input" value="true"
                               id="shipping-label-checkbox">
                        <label class="custom-control-label" for="shipping-label-checkbox"></label>
                      </div>
                    </div>
                  </a>
                </li>
                <li>
                  <a>
                    <div class="round-head">{{parcelType === 'pickup' ? 3 : 4}}</div>
                    <span>
                      <h3>Seal Your Package</h3>
                      <p>Close the small ends to form the bottom of your box, following with the larger ends. Seal the box with tape along all 3 seams on both ends of the box. </p>
                    </span>
                    <div class="check">
                      <div class="m-1 custom-control custom-checkbox">
                        <input type="checkbox" autocomplete="off"
                               class="custom-control-input" value="true"
                               id="package-seal-your-package">
                        <label class="custom-control-label" for="package-seal-your-package"></label>
                      </div>
                    </div>
                  </a>
                </li>
              </ul>
              <span class="error-text text-center d-none">
                <img src="/icons/c-warning.png"/>
                Make sure all checklist boxes are checked and press the “Next” button.
              </span>
            </div>
            <div class="btn-badges">
              <button class="btn btn-outline-secondary" @click="setActiveTab(0)">Previous</button>
              <button class="btn btn-primary" @click="setActiveTab(2)">
                Next <img src="/icons/arrow-right.png" class="ml-2"/></button>
            </div>
          </template>
          <template v-if="activeTab == 2">
            <div class="success-box">
              <div class="img-suc">
                <img src="/icons/success.png"/>
                <h5>Success!</h5>
                <p>
                  You’ve finished preparing your order.
                  You may now mark your order as prepared and transfer it to the shipping area.
                  Job well done!
                </p>
              </div>
              <button class="btn btn-primary w-100" @click="markAsPrepared()" :disabled="preparing">
                <b-spinner v-if="preparing" label="Spinning" style="width: 1rem; height: 1rem"></b-spinner>
                <span v-else>Mark as Prepared</span>
              </button>
            </div>
            <button class="btn-prev btn btn-outline-secondary m-3" @click="setActiveTab(parcelType == 'special' ? 0 : 1)">
              Previous
            </button>
          </template>
        </b-tabs>
      </div>
    </div>
  </div>
</template>
<script>
    import AdminService from '@/api-services/admin.service';

    export default {
        name: 'AdminPrepareOrder',
        data() {
            return {
                activeTab: 0,
                order: {},
                parcelType: '',
                currentParcel: null,
                parcelItems: null,
                subTotalAmount: 0,
                taxAmount: 0,
                totalAmount: 0,
                preparing: false,
                fetchingParcelDetails: false,
                orderId: null,
                parcelId: null,
                disableFirstTab: false,
                disableSecondTab: false,
                disableThirdTab: false,
                fields: ['checklist', 'image_url', 'title', 'brand_name', 'price', 'email_action'],
            };
        },
        filters: {
            toDollar: function(value) {
                return +(value).toFixed(2);
            }
        },
        beforeMount() {
            if (!this.$route.query || !this.$route.query.id) {
                this.goToOrders();
            } else {
                this.orderId = this.$route.query.id;
                this.parcelType = this.$route.query.type;
                this.parcelId = this.$route.query.parce_id;
            }
        },
        async mounted() {
          try {
            this.fetchingParcelDetails = true;
            let resp = await AdminService.getOrder(this.orderId);
            this.fetchingParcelDetails = false;
            this.order = resp.data.order;
            const parcels = this.order.parcels;
            if (parcels && parcels.length) {
              this.currentParcel = parcels.find(parcel => (parcel.id === +this.parcelId));
              this.parcelItems = this.currentParcel.items;
              this.parcelItems.forEach(item => {
                  this.subTotalAmount += +(item.line_price);
              });
              //TODO: Needs to update tax percentage with global settings
              this.taxAmount = this.subTotalAmount * 0.05;
              this.totalAmount = this.subTotalAmount + this.taxAmount;
            }
            setTimeout(() => {
              this.setActiveTab(0);
            }, 100);
          } catch (e) {
            this.fetchingParcelDetails = false;
          }
        },
        methods: {
            setActiveTab(index) {
                this.activeTab = index;
                switch (index) {
                  case 0: {
                    this.disableFirstTab = false;
                    this.disableSecondTab = true;
                    this.disableThirdTab = true;
                    break;
                  }
                  case 1: {
                    this.disableFirstTab = true;
                    this.disableSecondTab = false;
                    this.disableThirdTab = true;
                    break;
                  }
                  case 2: {
                    this.disableFirstTab = true;
                    this.disableSecondTab = true;
                    this.disableThirdTab = false;
                    break;
                  }
                }
            },
            showMsgBoxTwo() {
                this.$bvModal.msgBoxConfirm('Are you sure you want to cancel preparing this order?', {
                    size: 'sm',
                    buttonSize: 'sm',
                    okVariant: 'success',
                    cancelClass:'cancel-class',
                    cancelVariant: 'default',
                    okTitle: 'YES',
                    cancelTitle: 'NO',
                    footerClass: 'p-2 confirmation-footer',
                    hideHeaderClose: false,
                    centered: true
                })
                    .then(value => {
                        if (value) {
                            this.goToOrders();
                        }
                    });
            },
            goToOrders() {
                this.$router.push({name: 'admin-orders'});
            },
            async markAsPrepared() {
                try {
                    this.preparing = true;
                    let response = await AdminService.markPrepared(this.parcelId);
                    response = response.data;
                    this.preparing = false;
                    if (response.status == 'success') {
                        this.showMsgBox();
                    } else {
                        this.makeToast('danger', 'Oops', 'Something went wrong, please try again later!');
                    }
                } catch (e) {
                    this.preparing = false;
                    console.log('error in preparing order : ', e);
                }
            },
            makeToast(variant, title, content) {
                this.$bvToast.toast(content, {
                    title: title,
                    variant: variant,
                    solid: true
                });
            },
            showMsgBox() {
                this.$bvModal.msgBoxOk('Order has been marked as prepared!', {
                    title: 'Success',
                    size: 'sm',
                    buttonSize: 'sm',
                    okVariant: 'success',
                    headerClass: 'p-2 border-bottom-0',
                    footerClass: 'p-2 border-top-0',
                    centered: true
                })
                    .then(() => {
                        this.goToOrders();
                    })
                    .catch(() => {
                        this.goToOrders();
                    });
            }
        }
    };
</script>
<style lang="scss">
  .page-breadcrumbs {
    margin-bottom: 0;
    padding: 20px 0;
    font-weight: 600;
  }
  .confirmation-footer {
    justify-content: space-between;
    .btn-default {
      border: 1px solid #E6E6E6;
    }
  }
  .prepare-order {
    background: #FFFFFF;
    border: 1px solid #EAEAEB;
    border-radius: 5px;
    .customer-detail {
      padding: 24px;
      .order-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
      }
      h4 {
        font-weight: bold;
        font-size: 24px;
        line-height: 28px;
        color: #2F3540;
        margin-bottom: 15px;
      }
      .order-details-info {
        background: #FFFFFF;
        border: 1px solid #E6E6E6;
        box-sizing: border-box;
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
        border-radius: 8px;
        padding: 15px;
        display: flex;
        justify-content: space-between;
        .card-customer {
          .person-detail {
            margin-bottom: 10px;
            h5 {
              font-weight: 500;
              font-size: 14px;
              line-height: 16px;
              color: #ACACAC;
              margin-bottom: 0;
            }
            h3 {
              font-size: 18px;
              line-height: 21px;
              color: #1A212C;
              margin-bottom: 10px;
            }
          }
          p {
            font-size: 16px;
            line-height: 19px;
            color: #1A212C;
            max-width: 200px;
            margin-bottom: 10px;
          }
          .contact-detail {
            font-size: 14px;
            line-height: 16px;
            color: #1A212C;
            text-decoration: none;
          }
        }
        .details-info {
          display: flex;
          flex-direction: column;
          a {
            font-size: 14px;
            line-height: 16px;
            border-radius: 5px;
            margin-bottom: 5px;
            padding: 6px;
            color: #2F3540;
            border: 1px solid #E6E6E6;
            box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
            &:hover {
              text-decoration: none;
            }
            img {
              margin-right: 5px;
            }
          }
        }
      }
    }
    .order-type-details {
      background: #FFFFFF;
      border: 1px solid #E6E6E6;
      box-sizing: border-box;
      box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
      border-radius: 8px;
      padding: 15px;
      .person-detail {
        display: flex;
        flex-direction: column;
        .blue {
          color: #0F84E4;
        }
        .green {
          color: #e74930;
        }
        .orange {
          color: #FD941D;
        }
        h6 {
          font-weight: 500;
          font-size: 14px;
          line-height: 18px;
          color: #ACACAC;
          margin-bottom: 0;
        }
        h5 {
          font-size: 18px;
          line-height: 21px;
          color: #0F84E4;
          margin-bottom: 0;
        }
        span {
          font-size: 16px;
          line-height: 19px;
          color: #1A212C;
          display: flex;
          p {
            margin-bottom: 0;
          }
        }
      }
    }
    .prepare-items-box {
      display: flex;
      .tabs {
        width: 100%;
        display: flex;
        flex-direction: column;
        .nav-tabs {
          display: flex;
          width: 100%;
          .nav-item {
            flex: 1 !important;
            .disable-tab {
              text-decoration: line-through;
            }
            .nav-link {
              align-items: center;
              justify-content: center;
              height: 60px;
              border: none;
              display: flex;
              color: #A5ADB8;
              font-size: 15px;
              > div:last-child {
                flex: 1;
              }
              .num {
                border-radius: 50%;
                width: 28px;
                height: 28px;
                background: #A5ADB8;
                color: #fff;
                text-align: center;
                line-height: 28px;
                font-weight: bold;
                font-size: 13px;
                margin-right: 8px;
                img {
                  width: 10px;
                }
              }
              &.active {
                border-bottom: 2px solid #e74930;
                color: #e74930;
                .num {
                  background: #e74930;
                }
              }
            }
          }
        }
      }
      .items-pick {
        display: flex;
        flex-direction: column;
        align-items: center;
        h4 {
          font-weight: bold;
          font-size: 23px;
          line-height: 27px;
          text-align: center;
          color: #2F3540;
          margin-bottom: 0;
          margin-top: 25px;
        }
        h6 {
          font-size: 16px;
          line-height: 19px;
          text-align: center;
          color: #828282;
          font-weight: 300;
          margin-bottom: 0px;
        }
        .order-table {
          background: #FFFFFF;
          border: 1px solid #EAEAEB;
          border-radius: 5px;
          margin-top: 30px;
          .total-custom {
            padding: 0 24px 15px;
            .pages {
              display: flex;
              justify-content: flex-end;
              align-items: center;
              span {
                margin-left: 24px;
                p {
                  font-size: 14px;
                  line-height: 16px;
                  margin: 0;
                  color: #ACACAC;
                }
                h5 {
                  font-size: 17px;
                  line-height: 24px;
                  margin: 0;
                  color: #2F3540;
                }
              }
            }
          }
          .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            h5 {
              font-size: 19px;
              line-height: 22px;
              color: #2F3540;
              margin-bottom: 0;
            }
            .purchase-type {
              display: flex;
              align-items: center;
              h6 {
                margin-bottom: 0;
                margin-right: 5px;
                font-size: 14px;
                line-height: 16px;
                color: #2F3540;
              }
              input[type="text"] {
                background: #FFFFFF;
                border: 1px solid #E6E6E6;
                box-sizing: border-box;
                box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
                border-radius: 5px;
                padding-left: 5px;
              }
            }
            .table-date-range {
              display: flex;
              align-items: center;
              h6 {
                margin-bottom: 0;
                margin-right: 5px;
                font-size: 14px;
                line-height: 16px;
                color: #2F3540;
              }
              input[type="date"] {
                background: #FFFFFF;
                border: 1px solid #E6E6E6;
                box-sizing: border-box;
                box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
                border-radius: 5px;
                padding-left: 5px;
              }
              span {
                margin: 0 5px;
              }
            }
          }
          table {
            display: flex;
            flex-direction: column;
            thead {
              tr {
                display: flex;
                width: 100%;
                th {
                  flex: 1;
                  &:nth-of-type(3) {
                    flex: 2;
                  }
                  &:nth-of-type(5) {
                    flex: 2;
                  }
                }
              }
            }
            tbody {
              tr {
                display: flex;
                width: 100%;
                align-items: center;
                td {
                  flex: 1;
                  border: none;
                  &:nth-of-type(3) {
                    flex: 2;
                  }
                  &:nth-of-type(5) {
                    flex: 2;
                  }
                  .email-button {
                    font-size: 14px;
                    line-height: 16px;
                    border-radius: 5px;
                    margin-bottom: 5px;
                    padding: 6px;
                    color: #2F3540;
                    border: 1px solid #E6E6E6;
                    -webkit-box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
                    box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
                  }
                }
              }
            }
          }
          .pagination-custom {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 15px;
            .pages {
              display: flex;
              flex: 0.5;
              align-items: center;
              h6 {
                margin-bottom: 0;
                margin-right: 5px;
                font-size: 14px;
                line-height: 16px;
                color: #2F3540;
              }
              input[type="text"] {
                background: #FFFFFF;
                border: 1px solid #E6E6E6;
                box-sizing: border-box;
                box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
                border-radius: 5px;
                padding-left: 5px;
              }
              span {
                margin: 0 5px;
              }
            }
            .pagination {
              margin: 0;
              flex: 1;
              display: flex;
              justify-content: flex-start !important;
            }
          }
        }
        .flex-end {
          justify-content: flex-end !important;
        }
        .btn-badges {
          display: flex;
          justify-content: space-between;
          padding: 15px 0;
        }
      }
    }
    .wrapper-content {
      ul {
        padding-left: 0;
        li {
          list-style: none;
          margin: 20px 0;
          padding: 0 20px;
          a {
            background: #F6F7F8;
            mix-blend-mode: normal;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px 15px 0;
            position: relative;
            min-height: 105px;
            .round-head {
              background: #2F3540;
              border-radius: 50%;
              width: 35px;
              color: #fff;
              height: 35px;
              padding: 6px 14px;
              margin-left: 20px;
            }
            button {
              color: #000;
              border: 1px solid #E6E6E6;
              box-sizing: border-box;
              box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
              border-radius: 5px;
              background: #fff;
            }
            span {
              display: flex;
              flex-direction: column;
              padding: 0 20px;
              flex: 1;
              h3 {
                font-size: 23px;
                line-height: 27px;
                margin-bottom: 0;
                color: #2F3540;
              }
              p {
                font-size: 16px;
                line-height: 19px;
                margin-bottom: 0;
                color: #828282;
              }
            }
            button {
              flex: 1;
              max-width: 120px;
              white-space: nowrap;
              padding: 2px 0 !important;
              margin: 0 30px;
              img {
                margin-right: 8px;
              }
            }
            .check {
              position: absolute;
              top: 15px;
              right: -5px;
            }
          }
        }
      }
      .error-text {
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 15px auto;
        width: 100%;
        font-size: 14px;
        line-height: 16px;
        color: #4D4D4D;
        img {
          margin-right: 5px;
        }
      }
    }
    .btn-badges {
      display: flex;
      justify-content: space-between;
      padding: 15px;
    }
    .success-box {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      max-width: 330px;
      margin: 0 auto;
      padding: 50px 0 100px;
      .img-suc {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        align-items: center;
        h5 {
          font-size: 23px;
          line-height: 27px;
          text-align: center;
          color: #2F3540;
          margin-top: 20px;
          margin-bottom: 15px;
          font-weight: 600;
        }
        p {
          font-size: 16px;
          line-height: 22px;
          text-align: center;
          color: #2F3540;
          margin-bottom: 24px;
        }
      }
      .btn-primary {
        font-size: 18px;
        line-height: 16px;
        text-align: center;
        color: #FFFFFF;
      }
    }
    .btn-prev {
      display: flex;
      border: 1px solid #E6E6E6;
      box-sizing: border-box;
      box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
      border-radius: 5px;
      font-size: 16px;
      color: #2F3540;
      line-height: 19px;
    }
  }
</style>