<template>
  <div>
    <div class="px-5 d-flex pt-4 pb-3 mb-3 border-bottom justify-content-between align-items-center heading">
      <h1 class="h4 mb-0">Fulfillment Options</h1>
    </div>

    <div class="px-5 pb-5 mt-3 border-bottom border-gray">
      <h5 class="pt-3">Shipping</h5>
      <div class="row mt-4">
        <div class="mb-4 mb-sm-0 col-sm-6 col-lg-4 col-xl-3">
          Shipping
          <div class="custom-control custom-switch">
            <input type="checkbox" v-model="shipping_enabled" class="custom-control-input" id="shipping" @change="saveData('shipping')">
            <label
              class="custom-control-label"
              for="shipping"
              v-html="shipping_enabled ? 'Enabled' : 'Disabled'">
            </label>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 col-xl-3">
          <span :class="{'disabled-label':!shipping_enabled}">Special Order</span>
          <div class="custom-control custom-switch">
            <input type="checkbox" :disabled="!shipping_enabled" v-model="shipping_destination_bool" class="custom-control-input" id="specialOrder" @change="saveData('shipping')">
            <label
              class="custom-control-label always-on"
              for="specialOrder"
              v-html="`Ship to ${shipping_destination}`">
            </label>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 col-xl-3">
          First Item Price
          <div class="input-group" style="width: 150px;">
            <div class="input-group-prepend">
              <span class="input-group-text">$</span>
            </div>
            <input type="number" :disabled="!shipping_enabled" class="form-control" v-model="shipping_base_price" @change="saveData('shipping')">
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 col-xl-3">
          Extra Items Price
          <div class="input-group" style="width: 150px;">
            <div class="input-group-prepend">
              <span class="input-group-text">$</span>
            </div>
            <input type="number" :disabled="!shipping_enabled" class="form-control" v-model="shipping_extra_price" @change="saveData('shipping')">
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 col-xl-3">
          Max Extra Count
          <div class="input-group" style="width: 150px;">
            <input type="number" :disabled="!shipping_enabled" class="form-control" v-model="shipping_extra_max" @change="saveData('shipping')">
          </div>
        </div>
      </div>
    </div>

    <div class="px-5 pb-5 mt-3 border-bottom border-gray">
      <h5 class="pt-3">Delivery</h5>
      <div class="row mt-4">
        <div class="mb-4 mb-sm-0 col-sm-6 col-lg-4 col-xl-3">
          Delivery
          <div class="custom-control custom-switch">
            <input type="checkbox" v-model="delivery_enabled" class="custom-control-input" id="delivery" @change="saveData('delivery')">
            <label
              class="custom-control-label"
              for="delivery"
              v-html="delivery_enabled ? 'Enabled' : 'Disabled'">
            </label>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 col-xl-3">
          Delivery Fee
          <div class="input-group" style="width: 150px;">
            <div class="input-group-prepend">
              <span class="input-group-text">$</span>
            </div>
            <input type="number" :disabled="!delivery_enabled" class="form-control" v-model="delivery_fee" @change="saveData('delivery')">
          </div>
        </div>
      </div>
    </div>

    <div class="px-5 pb-5 mt-3 border-bottom border-gray">
      <h5 class="pt-3">Pick Up</h5>
      <div class="row mt-4">
        <div class="mb-4 mb-sm-0 col-sm-6 col-lg-4 col-xl-3">
          Pick Up
          <div class="custom-control custom-switch">
            <input type="checkbox" v-model="pickup_enabled" class="custom-control-input" id="pickUp" @change="saveData('pickup')">
            <label
              class="custom-control-label"
              for="pickUp"
              v-html="pickup_enabled ? 'Enabled' : 'Disabled'">
            </label>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 col-xl-3">
          <span :class="{'disabled-label':!pickup_enabled}">Payment Processing</span>
          <div class="custom-control custom-switch">
            <input type="checkbox" :disabled="!pickup_enabled" v-model="pickup_payment_bool" class="custom-control-input" id="paymentProcessing" @change="saveData('pickup')">
            <label
              class="custom-control-label always-on"
              for="paymentProcessing"
              v-html="`Pay on ${pickup_payment}`">
            </label>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import AdminService from '@/api-services/admin.service';
  import HomePageService from '@/api-services/homepage.service';

  export default {
    name: 'FulfillmentOptions',
    data() {
      return {
        pickup_enabled: false,
        pickup_payment: false,
        shipping_enabled: false,
        shipping_destination: '',
        shipping_base_price: '',
        shipping_extra_price: '',
        shipping_extra_max: '',
        delivery_enabled: false,
        delivery_fee: '',
        pickUp: false,
        paymentProcessing: false,
      };
    },
    computed: {
      shipping_destination_bool: {
        get() {
          return this.shipping_destination == 'store' ? 0 : 1;
        },
        set(val) {
          if(val == 1) {
            this.shipping_destination = 'house';
          } else {
            this.shipping_destination = 'store';
          }
          return val;
        }
      },
      pickup_payment_bool: {
        get() {
          return this.pickup_payment == 'store' ? 0 : 1;
        },
        set(val) {
          if(val == 1) {
            this.pickup_payment = 'website';
          } else {
            this.pickup_payment = 'store';
          }
          return val;
        }
      }
    },
    async mounted() {
      let response = await HomePageService.getBusinessDetails();
      this.pickup_enabled = response.data.data.pickup_enabled;
      this.pickup_payment = response.data.data.pickup_payment;
      this.shipping_enabled = response.data.data.shipping_enabled;
      this.shipping_destination = response.data.data.shipping_destination;
      this.shipping_base_price = response.data.data.shipping_base_price;
      this.shipping_extra_price = response.data.data.shipping_extra_price;
      this.shipping_extra_max = response.data.data.shipping_extra_max;
      this.delivery_enabled = response.data.data.delivery_enabled;
      this.delivery_fee = response.data.data.delivery_fee;
    },
    methods: {
      saveData(type) {
        switch(type) {
          case 'shipping':
            AdminService.updateFulfillmentShipping({
              'enabled': this.shipping_enabled,
              'destination': this.shipping_destination,
              'base_price': this.shipping_base_price,
              'extra_price': this.shipping_extra_price,
              'extra_max': this.shipping_extra_max
            });
            break;
          case 'delivery':
            AdminService.updateFulfillmentDelivery({
              'enabled': this.delivery_enabled,
              'fee': this.delivery_fee
            });
            break;
          case 'pickup':
            AdminService.updateFulfillmentPickup({
              'enabled': this.pickup_enabled,
              'payment': this.pickup_payment
            });
            break;
        }
      }
    }
  };
</script>
<style lang="scss" scoped>
  $primary: #ED6730;
  .heading {
    height: 80px;
    .h4 {
      color: $primary;
    }
  }
  .disabled-label {
    color: #ccc;
  }
  .custom-control-label.always-on {
    color: $primary !important;
    &::before {
      color: #fff !important;
      border-color: $primary !important;
      background-color: $primary !important;
    }
  }
  .custom-control-input:disabled {
    ~ .custom-control-label {
      color: #ccc !important;
      &::before {
        background-color: #e9ecef !important;
      }
    }
  }
</style>
