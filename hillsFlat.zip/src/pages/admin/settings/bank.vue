<template>
  <div>
    <div class="px-5 d-flex pt-4 pb-3 mb-3 border-bottom justify-content-between align-items-center heading">
      <h1 class="h4 mb-0">Bank Setup</h1>
    </div>
    <div class="px-5 pb-5 mt-3 border-bottom border-gray">

      <button v-if="!account_setup" class="btn btn-primary" @click="startConnection">Connect with Stripe</button>
      <button v-else class="btn btn-primary" @click="dashboard">View Stripe Dashboard</button>

    </div>
  </div>
</template>

<script>
    import Axios from 'axios';

    export default {
        name: 'BankOptions',
        data() {
            return {
                account_setup: false,
                state_key: ''
            };
        },
        async mounted() {
            let response = await Axios.get('admin/bank');
            let data = response.data.data;
            this.account_setup = data.account_setup;
            this.state_key = data.state_key;
        },
        methods: {
            startConnection() {
                const redirectUrl = 'https://api.ezadtv.com/stripe/oauth';

                // these are fine to have public because they literally have to be in a URL.
                // they are global to EZ-AD and will not change on each site.
                const clientId = 'ca_GBAHSnkZFSO4cW2aFRkFPrYpHI3iZ4Te'; // test
                //const clientId = 'ca_GBAH5RL9Gi6y04gzdKJeuSOXaRmUzgvk'; // live

                const st = this.state_key;

                window.location.href = 'https://connect.stripe.com/express/oauth/authorize' +
                    `?redirect_uri=${redirectUrl}&client_id=${clientId}&state=${st}`;
            },
            dashboard() {
                Axios.get('admin/bank/login').then(response => {
                    window.open(response.data.url, '_blank');
                });
            }
        }
    };
</script>

<style type="text/scss" scoped>

</style>
