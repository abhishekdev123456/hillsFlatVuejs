<template>
  <div class="container pt-2">
    <div class="row" v-if="showOfferBanner">
      <div class="col-md-12 mt-3 mb-4">
        <div class="order-tool">
          <span><h6>ORDER SUPPLIES! GET $25 off on your first purchase!</h6></span>
          <div class="close" @click="showOfferBanner = false">&times;</div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="order-details-product" :class="{'mt-4': !showOfferBanner}">
          <div class="details-header">
            <h6>Outstanding Orders</h6>
            <span>
              <p>Filter By</p>
               <ul class="unstyled centered">
                <li>
                  <input class="styled-checkbox green"
                         id="pickup-checkbox"
                         value="pickup"
                         type="checkbox"
                         v-model="outstandingOrdersFilters"
                         @change="updateOutstandingOrders" />
                  <label for="pickup-checkbox">Pickup</label>
                </li>
<!--                <li>-->
<!--                  <input class="styled-checkbox"-->
<!--                         id="delivery-checkbox"-->
<!--                         value="delivery"-->
<!--                         type="checkbox"-->
<!--                         v-model="outstandingOrdersFilters"-->
<!--                         @change="updateOutstandingOrders"  />-->
<!--                  <label for="delivery-checkbox">Delivery</label>-->
<!--                </li>-->
                <li>
                  <input class="styled-checkbox blue"
                         id="shipping-checkbox"
                         value="special"
                         type="checkbox"
                         v-model="outstandingOrdersFilters"
                         @change="updateOutstandingOrders" />
                  <label for="shipping-checkbox">Special</label>
                </li>
              </ul>
            </span>
          </div>
          <div class="row p-3" :class="{'d-flex justify-content-center': !loadingOutstandingOrders && (outstandingOrders && !outstandingOrders.length)}">
            <div v-if="loadingOutstandingOrders" class="d-flex w-100 h-100 align-items-center justify-content-center" style="z-index:2;background:rgba(255,255,255,.7)">
              <b-spinner label="Spinning"></b-spinner>
            </div>
            <template v-else>
              <template v-if="outstandingOrders && outstandingOrders.length">
                <swiper ref="orderSwiper" :options="swiperOption" class="w-100">
                  <swiper-slide v-for="(order, index) in outstandingOrders" class="col-md-4 py-3" :key="index">
                    <div class="product-details">
                      <div :class="`header ${order.parcel_type}`">
                        <img :src="`/icons/${order.parcel_type}.png`"/><h4>{{ order.parcel_type }}</h4>
                      </div>
                      <div class="prepare-order">
                    <span>
                      <div class="order-number">
                        <h6>order</h6><span>#{{ order.order_id }}</span>
                      </div>
                      <div class="order-total">
                        <h6>Total</h6><span>${{ order.total }}</span>
                      </div>
                      <button :class="`btn-${order.parcel_type}`" class="btn" @click="prepareOrder(order)">Prepare Order</button>
                    </span>
                        <div class="client-info">
                          <div class="order-number">
                            <h6>Client</h6><span>{{ order.first_name }} {{ order.last_name }}</span>
                          </div>
                          <div class="special-order">
                            <timeago class="time-text" :datetime="order.date_purchased" :auto-update="60" />
                            <p v-if="order.parcel_type == 'special'">Special Order</p>
                          </div>
                        </div>
                        <div class="details-order">
                          <h6>Details</h6>
                          <div class="row mobile-details">
                            <swiper :ref="`pickupSwiper${order.id}`" :options="swiperOption">
                              <swiper-slide class="ml-3" style="width: 128px;" v-for="(item, index) in order.items" :key="index">
                                <div class="product-img">
                                  <img :src="item.image_url" width="100%" />
                                </div>
                                <p>{{item.title || 'Not available'}}</p>
                              </swiper-slide>
                            </swiper>
                            <div class="swiper-button-prev pre ml-3" style="width: 20px;" slot="button-prev" @click="getSwiper(`pickupSwiper${order.id}`).slidePrev()" />
                            <div class="swiper-button-next nxt mr-3" style="width: 20px;" slot="button-next" @click="getSwiper(`pickupSwiper${order.id}`).slideNext()" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </swiper-slide>
                </swiper>
                <div class="swiper-button-prev pre orders-prev" slot="button-prev" @click="orderSwiper.slidePrev()" />
                <div class="swiper-button-next nxt orders-next" slot="button-next" @click="orderSwiper.slideNext()" />
              </template>
              <template v-else>
                <h5 class="mb-0">No outstanding orders found.</h5>
              </template>
            </template>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="order-table">
          <div class="table-header">
            <h5>Completed Orders</h5>
            <div class="purchase-type">
              <h6>Purchase Type</h6>
              <select v-model="purchaseType" @change="getCompletedOrders">
                <option v-for="opt in purchaseTypes" :key="opt" :value="opt">{{ opt }}</option>
              </select>
            </div>
            <div class="table-date-range">
              <h6>Date Range</h6>
              <input type="date" v-model="dateStart" @change="getCompletedOrders">
              <span>-</span>
              <input type="date" v-model="dateEnd" @change="getCompletedOrders">
            </div>
          </div>
          <div v-if="loadingCompletedOrders" class="d-flex p-4 justify-content-center" style="z-index:2;background:rgba(255,255,255,.7)">
            <b-spinner label="Spinning"></b-spinner>
          </div>
          <template v-else>
            <template v-if="completedOrders && completedOrders.length">
              <b-table responsive striped hover :items="completedOrders" :fields="fields"></b-table>
              <div class="pagination-custom">
                <div class="pages">
                  <h6>
                    Rows per page
                  </h6>
                  <select v-model="perPage" @change="getCompletedOrders">
                    <option v-for="opt in perPages" :key="opt" :value="opt">{{ opt }}</option>
                  </select>
                </div>
                <div class="pagination">
                  <v-pagination
                    v-model="currentPage"
                    :page-count="pages"
                    :classes="bootstrapPaginationClasses"
                    :labels="paginationAnchorTexts"
                  />
                </div>
              </div>
            </template>
            <template v-else>
              <h5 class="d-flex p-4 justify-content-center">No completed orders found.</h5>
            </template>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
    import {paginationConfig} from '@/config/modules';
    import AdminService from '@/api-services/admin.service';

    const currentYear = new Date().getFullYear();

    export default {
        name: 'AdminOrders',
        data() {
            return {
                ...paginationConfig,
                swiperOption: {
                    loop: false,
                    slidesPerView: 'auto',
                    spaceBetween: 0,
                    draggable: true,
                    allowTouchMove: true,
                },
                pages: 0,
                currentPage: 1,
                perPage: 10,
                total: 10,
                dateStart: currentYear + '-01-01',
                dateEnd: currentYear + '-12-31',
                purchaseType: 'All',
                purchaseTypes: ['All', 'Pickup', 'Special'],
                perPages: [5, 10, 15, 20, 25, 30],
                showOfferBanner: false,
                outstandingOrders: ['pickup', 'orders', 'shipping'],
                loadingOutstandingOrders: false,
                loadingCompletedOrders: false,
                outstandingOrdersFilters: [],
                completedOrders: [],
                bootstrapPaginationClasses: {
                    ul: 'pagination justify-content-center',
                    li: 'page-item',
                    liActive: 'active',
                    liDisable: 'disabled',
                    button: 'page-link',
                },
                paginationAnchorTexts: {
                    first: 'Prev',
                    last: 'Next',
                },
                fields: ['Order', 'Customer', 'Date Purchased', 'Purchase Type', 'Total', 'Order Completion Time']
            };
        },
        computed: {
            shippingSwiper() {
                return this.$refs.shippingSwiper.swiper;
            },
            deliverySwiper() {
                return this.$refs.deliverySwiper.swiper;
            },
            orderSwiper() {
                return this.$refs.orderSwiper.swiper;
            },
        },
        mounted() {
            this.updateOutstandingOrders();
            this.getCompletedOrders();
        },
        watch: {
            currentPage() {
                this.getCompletedOrders();
            }
        },
        methods: {
            prepareOrder(order) {
                this.$router.push({
                    name: 'admin-prepare-order',
                    query: {id: order.order_id, type: order.parcel_type, parce_id: order.id},
                    //query: {id: order.id} // for v2
                });
            },
            async updateOutstandingOrders() {
                this.loadingOutstandingOrders = true;
                let resp = await AdminService.getOutstandingOrders(this.outstandingOrdersFilters.join(','));
                this.outstandingOrders = resp.data.parcels;
                //this.outstandingOrders = resp.data.orders; // for v2
                this.loadingOutstandingOrders = false;
            },
            async getCompletedOrders() {
                try {
                    this.loadingCompletedOrders = true;
                    const response = await AdminService.getCompletedOrders({
                        dateStart: this.dateStart,
                        dateEnd: this.dateEnd,
                        page: this.currentPage,
                        perPage: this.perPage,
                        types: this.purchaseType
                    });
                    if ( response.data && response.data.orders ) {
                        this.pages = Math.ceil(response.data.count / this.perPage);
                        this.completedOrders = response.data.orders.map(o => {
                            return {
                                Order: '#' + o.id,
                                Customer: o.first_name + ' ' + o.last_name,
                                'Date Purchased': o.date_purchased,
                                'Purchase Type': o.parcel_types.join(', '),
                                Total: '$' + o.total,
                                'Order Completion Time': o.date_completed
                            };
                        });
                    } else {
                        this.pages = 0;
                        this.completedOrders = [];
                    }
                    this.loadingCompletedOrders = false;
                } catch (e) {
                    this.loadingCompletedOrders = false;
                }
            },
            getSwiper(refName) {
                return this.$refs[refName][0].swiper;
            },
        }
    };
</script>
<style lang="scss" scoped>
  .order-tool {
    width: 100%;
    height: 53px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 5px;
    background: #EDFDED;
    mix-blend-mode: normal;
    position: relative;
    &::before {
      content: '';
      border: 1px dashed #e74930;
      border-radius: 5px;
      position: absolute;
      width: 100%;
      height: 100%;
    }
    h6 {
      font-weight: bold;
      font-size: 16px;
      line-height: 19px;
      text-align: center;
      color: #13B713;
      margin-bottom: 0;
    }
    .close {
      position: absolute;
      top: 2px;
      color: #13B713;
      right: 5px;
      cursor: pointer;
    }
  }
  .order-details-product {
    background: #FFFFFF;
    border: 1px solid #EAEAEB;
    border-radius: 5px;
    .details-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      line-height: 50px;
      padding: 16px;
      border-bottom: 1px solid #EAEAEB;
      h6 {
        margin-bottom: 0;
        font-size: 19px;
        line-height: 22px;
        color: #2F3540;
      }
      span {
        display: flex;
        p {
          margin-bottom: 0;
        }
        .unstyled {
          display: flex;
          margin-bottom: 0;
          li {
            margin-right: 5px;
            list-style: none;
            label {
              margin-bottom: 0;
            }
            .styled-checkbox {
              position: absolute;
              opacity: 0;
              & + label {
                position: relative;
                cursor: pointer;
                padding: 0;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
              }
              & + label:before {
                content: '';
                margin-right: 10px;
                display: inline-block;
                vertical-align: text-top;
                width: 15px;
                height: 15px;
                border: 1px solid #eee;
              }
              // Box hover
              /*&:hover + label:before {*/
              /*  background: #f35429;*/
              /*}*/
              // Box focus
              &:focus + label:before {
                box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.12);
              }
              // Box checked
              &:checked + label:before {
                background: #FD941D;
              }
              &.green {
                &:checked + label:before {
                  background: #e74930;
                }
                /*&:hover + label:before {*/
                /*  background: #e74930;*/
                /*}*/
              }
              &.blue {
                &:checked + label:before {
                  background: #0F84E4;
                }
                /*&:hover + label:before {*/
                /*  background: #0F84E4;*/
                /*}*/
              }
              // Disabled state label.
              &:disabled + label {
                color: #b8b8b8;
                cursor: auto;
              }
              // Disabled box.
              &:disabled + label:before {
                box-shadow: none;
                background: #fff;
              }
              // Checkmark. Could be replaced with an image
              &:checked + label:after {
                content: '';
                position: absolute;
                left: 3px;
                top: 8px;
                background: white;
                width: 2px;
                height: 2px;
                box-shadow: 2px 0 0 white,
                4px 0 0 white,
                4px -2px 0 white,
                4px -4px 0 white,
                4px -6px 0 white,
                4px -8px 0 white;
                transform: rotate(45deg);
              }
            }
          }
        }
      }
    }
    .product-details {
      .header {
        background: #e74930;
        border-radius: 8px 8px 0px 0px;
        display: flex;
        text-transform: uppercase;
        justify-content: center;
        align-items: center;
        h4 {
          margin-bottom: 0;
          font-size: 16px;
          line-height: 34px;
          color: #fff;
          margin-left: 8px;
        }
        &.delivery {
          background: #FD941D;
        }
        &.special {
          background: #0F84E4;
        }
      }
      .prepare-order {
        border: 1px solid #EAEAEB;
        border-radius: 0px 0px 8px 8px;
        span {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 15px;
          .order-number, .order-total {
            h6 {
              font-size: 13px;
              line-height: 15px;
              color: #ACACAC;
              margin-bottom: 0;
            }
            span {
              font-size: 16px;
              line-height: 22px;
              color: #1A212C;
              padding: 0;
            }
          }
          .btn {
            height: 40px;
            line-height: 40px;
            padding: 0 15px 0 15px;
            color: #fff;
            &.btn-pickup {
              background: #e74930 !important;
            }
            &.btn-delivery {
              background: #FD941D !important;
            }
            &.btn-special {
              background: #0F84E4 !important;
            }
          }
        }
        .client-info {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          padding: 0 15px 15px;
          border-bottom: 1px solid #EAEAEB;
          .order-number {
            h6 {
              font-size: 13px;
              line-height: 15px;
              color: #ACACAC;
              margin-bottom: 0;
            }
            span {
              font-size: 16px;
              line-height: 22px;
              color: #1A212C;
              padding: 0;
            }
          }
          .special-order {
            .time-text {
              padding: 0;
              font-size: 14px;
            }
          }
          p {
            font-size: 13px;
            line-height: 15px;
            text-align: right;
            color: red;
            margin-bottom: 0;
          }
        }
        .details-order {
          padding: 15px;
          .row {
            justify-content: center;
            .swiper-button-prev {
              left: 10px;
              top: 50px;
              .swipe-prev {
                border-radius: 0 5px 5px 0 !important;
                background: #fff url("../../../public/icons/icon-left.png")no-repeat 14px 20px !important;
                box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05) !important;
                border: 1px solid #EAEAEB;
                right: 0;
              }
            }
            .swiper-button-next {
              right: 10px;
              top: 50px;
              .swipe-next  {
                border-radius: 5px 0 0 5px !important;
                background: #fff url("../../../public/icons/icon-right.png")no-repeat 14px 20px !important;
                box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05) !important;
                border: 1px solid #EAEAEB;
                right: 5px;
              }
            }
          }
          .product-img {
            border: 1px solid #eaeaea;
            padding: 10px;
            img {
              max-height: 110px;
            }
          }
          h6 {
            font-size: 13px;
            line-height: 15px;
            color: #ACACAC;
          }
          p {
            font-size: 13px;
            line-height: 15px;
            color: #1A212C;
            margin-bottom: 0;
            margin-top: 5px;
            height: 60px;
          }
        }
      }
    }
  }
  .order-table {
    background: #FFFFFF;
    border: 1px solid #EAEAEB;
    border-radius: 5px;
    margin-top: 30px;
    .table-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px;
      h5 {
        font-size: 19px;
        line-height: 22px;
        color: #2F3540;
        margin-bottom: 0;
      }
      .purchase-type {
        display: flex;
        align-items: center;
        h6 {
          margin-bottom: 0;
          margin-right: 5px;
          font-size: 14px;
          line-height: 16px;
          color: #2F3540;
        }
        input[type="text"] {
          background: #FFFFFF;
          border: 1px solid #E6E6E6;
          box-sizing: border-box;
          box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
          border-radius: 5px;
          padding-left: 5px;
        }
      }
      .table-date-range {
        display: flex;
        align-items: center;
        h6 {
          margin-bottom: 0;
          margin-right: 5px;
          font-size: 14px;
          line-height: 16px;
          color: #2F3540;
        }
        input[type="date"] {
          background: #FFFFFF;
          border: 1px solid #E6E6E6;
          box-sizing: border-box;
          box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
          border-radius: 5px;
          padding-left: 5px;
        }
        span {
          margin: 0 5px;
        }
      }
    }
    .pagination-custom {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 15px;
      .pages {
        display: flex;
        flex: 0.5;
        align-items: center;
        h6 {
          margin-bottom: 0;
          margin-right: 5px;
          font-size: 14px;
          line-height: 16px;
          color: #2F3540;
        }
        input[type="text"] {
          background: #FFFFFF;
          border: 1px solid #E6E6E6;
          box-sizing: border-box;
          box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
          border-radius: 5px;
          padding: 5px;
        }
        span {
          margin: 0 5px;
        }
      }
      .pagination {
        margin: 0;
        flex: 1;
        display: flex;
        justify-content: flex-start !important;
      }
    }
  }
  @media screen and (max-width: 767px) {
    .order-table {
      .pagination-custom {
        flex-direction: column;
        .pages {
          margin-bottom: 10px;
        }
      }
      .table-header {
        flex-direction: column;
        h5 {
          margin-bottom: 10px;
        }
        .table-date-range {
          margin-top: 10px;
          input {
            width: 85px;
          }
        }
      }
    }
    .order-details-product {
      .product-details {
        .prepare-order {
          span {
            .btn {
              height: 30px;
              line-height: 30px;
              padding: 0 10px 0 10px;
              max-width: 70px;
            }
          }
        }
      }
      .details-header {
        flex-direction: column;
        span {
          justify-content: space-between;
          width: 100%;
          ul {
            padding-left: 0;
          }
        }

      }
      .orders-prev {
        left: 0 !important;
        .swipe-prev {
          width: 40px !important;
          height: 60px !important;
        }
      }
      .orders-next {
        right: 0 !important;
        .swipe-next {
          width: 40px !important;
          height: 60px !important;
        }
      }
    }
  }
  @media screen and (min-width: 768px) and (max-width: 991px) {
    .order-table {
      .pagination-custom {
        justify-content: space-between;
        .pages {
          flex: 1;
        }
      }
      .table-header {
        flex-direction: column;
        .table-date-range {
          margin-top: 10px;
          input {
            width: 85px;
          }
        }
      }
    }
    .order-details-product {
      .product-details {
        .prepare-order {
          .client-info {
            flex-direction: column;
            align-items: center;
            height: 92px;
            justify-content: center;
            .order-number {
              text-align: center;
              h6 {
                font-size: 14px;
              }
            }
          }
          span {
            flex-direction: column;
            .btn {
              height: 30px;
              line-height: 30px;
              padding: 0 10px 0 10px;
              max-width: 70px;
              margin-top: 10px;
            }
            .order-number {
              text-align: center;
              h6 {
                font-size: 14px;
              }
            }
            .order-total {
              text-align: center;
            }

          }
        }
      }

      .orders-prev {
        left: 0 !important;
        .swipe-prev {
          width: 40px !important;
          height: 60px !important;
        }
      }
      .orders-next {
        right: 0 !important;
        .swipe-next {
          width: 40px !important;
          height: 60px !important;
        }
      }
    }
  }
  @media screen and (max-width: 576px) {
    .order-table {
      .table-header {
        h5 {
          margin-bottom: 10px;
        }
      }
      .pagination-custom {
        .pages {
          input[type="text"] {
            width: 125px;
          }
        }
      }
    }
    .order-details-product {
      .details-header {
        flex-direction: column;
        span {
          flex-direction: column;
          ul {
            padding-left: 0;
          }
        }
      }
    }
  }
</style>
