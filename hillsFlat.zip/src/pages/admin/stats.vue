<template>
  <main>
    <div class="container-fluid mt-3">
      <div class="d-flex numbers justify-content-between">
        <div class="pr-4">
          <div class="d-flex align-items-end">
            <div class="value">
              218
            </div>
            <div class="diff negative">-7.2%</div>
          </div>
          <div class="label">Monthly Active</div>
        </div>
        <div class="pr-4">
          <div class="d-flex align-items-end">
            <div class="value">
              28
            </div>
            <div class="diff negative">-15%</div>
          </div>
          <div class="label">Daily Active</div>
        </div>
        <div class="pr-4">
          <div class="d-flex align-items-end">
            <div class="value">
              0
            </div>
            <div class="diff"></div>
          </div>
          <div class="label">Daily New</div>
        </div>
        <div class="pr-4">
          <div class="d-flex align-items-end">
            <div class="value">
              96.4%
            </div>
            <div class="diff positive">+6.1%</div>
          </div>
          <div class="label">Crash-free Users</div>
        </div>
        <div class="pr-4">
          <div class="d-flex align-items-end">
            <div class="value">
              46
            </div>
            <div class="diff negative">-39%</div>
          </div>
          <div class="label">Total Sessions</div>
        </div>
        <div>
          <div class="d-flex align-items-end">
            <div class="value">
              0:56s
            </div>
            <div class="diff negative">-56%</div>
          </div>
          <div class="label">Time in App per User</div>
        </div>
      </div>
      <div class="info-lists row mt-5">
        <div class="col-md-4">
          <div class="card viewed-items h-100">
            <div class="card-body">
              <div class="card-title">
                <h5>Popularly Viewed Items</h5>
              </div>
              <ul class="list-group list-group-flush">
                <li v-for="item in viewedItems" :key="item.code" class="list-group-item">
                  <div class="d-flex align-items-center">
                    <img :src="item.image" class="pr-3" />
                    <div class="pr-2">
                      <div class="name">{{ item.name }}</div>
                      <div class="code">{{ item.code }}</div>
                    </div>
                    <div class="views-wrapper d-flex justify-content-end">
                      <div class="views">
                        {{ item.views }}
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card viewed-items h-100">
            <div class="card-body">
              <div class="card-title">
                <h5>Items Recently Added to Cart</h5>
              </div>
              <ul class="list-group list-group-flush">
                <li v-for="item in recentlyAdded" :key="item.code" class="list-group-item">
                  <div class="d-flex align-items-center">
                    <img :src="item.image" class="pr-3" />
                    <div class="pr-2">
                      <div class="name">{{ item.name }}</div>
                      <div class="code">{{ item.code }}</div>
                    </div>
                    <div class="views-wrapper d-flex justify-content-end">
                      <div class="views">
                        {{ item.views }}
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card viewed-items h-100">
            <div class="card-body">
              <div class="card-title">
                <h5>Abandoned Carts</h5>
              </div>
              <ul class="list-group list-group-flush">
                <li v-for="item in abandonedCarts" :key="item.code" class="list-group-item">
                  <div class="d-flex align-items-center">
                    <img :src="item.image" class="pr-3" />
                    <div class="pr-2">
                      <div class="name">{{ item.name }}</div>
                      <div class="code">{{ item.code }}</div>
                    </div>
                    <div class="views-wrapper d-flex justify-content-end">
                      <div class="views">
                        {{ item.views }}
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="row my-4">
        <div class="col-md-8">
          <div class="card h-100">
            <div class="card-body">
              <div class="card-title">
                <h5>Customer Logins</h5>
              </div>
              <table class="table customerLogins">
                <thead>
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Date Last Visited</th>
                    <th scope="col">Date Registered</th>
                    <th scope="col">Orders Placed</th>
                    <th scope="col">Location</th>
                  </tr>
                </thead>
                <tbody style="font-size:.85rem;">
                  <tr v-for="customer in customerLogins" :key="customer.name">
                    <td scope="row">{{customer.name}}</td>
                    <td>{{ customer.dateVisited }}</td>
                    <td>{{ customer.dateRegistered }}</td>
                    <td>{{ customer.orders }}</td>
                    <td>{{ customer.city }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card h-100">
            <div class="card-body">
              <div class="card-title">
                <h5>Traffic Source Types</h5>
              </div>
              <div id="socialChart" class="mt-3"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="row my-4">
        <div class="col-md-12">
          <div class="card">
            <div class="card-body">
              <div class="card-title">
                <h5>Pos Items Recently Synced</h5>
              </div>
              <table class="table customerLogins">
                <thead>
                  <tr>
                    <th scope="col" width="1"></th>
                    <th scope="col">Name</th>
                    <th scope="col">Inventory</th>
                    <th scope="col">Price</th>
                    <th scope="col">Promo Price</th>
                    <th scope="col">Location</th>
                    <th scope="col">Last Synced</th>
                  </tr>
                </thead>
                <tbody style="font-size:.85rem;">
                  <tr v-for="item in recentlySynced" :key="item.code">
                    <td scope="row">
                      <img :src="item.image" alt="">
                    </td>
                    <td>
                      <div class="lead font-weight-normal">{{ item.name }}</div>
                      <div>{{ item.code }}</div>
                    </td>
                    <td>{{ item.inventory }}</td>
                    <td>{{ item.price }}</td>
                    <td>{{ item.promoPrice }}</td>
                    <td>{{ item.location }}</td>
                    <td>{{ item.lastSynced }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
import ApexCharts from 'apexcharts';

  export default {
    name: 'AdminStats',
    data() {
      return {
        viewedItems: [
          {
            name: 'Horsehoe',
            code: '728429',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          },
          {
            name: 'Horseshoe',
            code: '728428',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          },
          {
            name: 'Horsehoe',
            code: '728427',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          },
          {
            name: 'Horsehoe',
            code: '728426',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          },
          {
            name: 'Horsehoe',
            code: '728425',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          },
          {
            name: 'Horsehoe',
            code: '728424',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          }
        ],
        recentlyAdded: [
          {
            name: 'Horsehoe',
            code: '728439',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          },
          {
            name: 'Horseshoe',
            code: '728438',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          },
          {
            name: 'Horsehoe',
            code: '728437',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          }
        ],
        abandonedCarts: [
          {
            name: 'Horsehoe',
            code: '228439',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          },
          {
            name: 'Horseshoe',
            code: '228438',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          },
          {
            name: 'Horsehoe',
            code: '228437',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          },
          {
            name: 'Horsehoe',
            code: '228436',
            views: 19,
            image: `https://picsum.photos/seed/${Math.random()}/64`
          }
        ],
        socialChartOptions: {
          chart: {
            height: 300,
            type: 'bar'
          },
          colors: ['#4267B2', '#DD4C3A', '#00ABF0'],
          series: [{
            data: [20,50,30]
          }],
          plotOptions: {
            bar: {
              distributed: true
            }
          },
          dataLabels: {
            formatter: val => `${val}%`
          },
          tooltip: {
            enabled: false
          },
          states: {
            hover: { filter: () => {} },
            active: { filter: () => {} },
          },
          xaxis: {
            categories: ['Facebook','Google','Twitter'],
            labels: {
              style: {
                colors: ['#4267B2', '#DD4C3A', '#00ABF0'],
                fontSize: '14px'
              }
            }
          }
        },
        customerLogins: [
          {
            name: 'Lawrence Mansour',
            dateVisited: '01/01/01',
            dateRegistered: '01/01/01',
            orders: 6,
            city: 'City'
          },
          {
            name: 'Lawrence Mansour 2',
            dateVisited: '01/01/01',
            dateRegistered: '01/01/01',
            orders: 6,
            city: 'City'
          },
          {
            name: 'Lawrence Mansour 3',
            dateVisited: '01/01/01',
            dateRegistered: '01/01/01',
            orders: 6,
            city: 'City'
          },
          {
            name: 'Lawrence Mansour 4',
            dateVisited: '01/01/01',
            dateRegistered: '01/01/01',
            orders: 6,
            city: 'City'
          },
          {
            name: 'Lawrence Mansour 5',
            dateVisited: '01/01/01',
            dateRegistered: '01/01/01',
            orders: 6,
            city: 'City'
          },
          {
            name: 'Lawrence Mansour 6',
            dateVisited: '01/01/01',
            dateRegistered: '01/01/01',
            orders: 6,
            city: 'City'
          }
        ],
        recentlySynced: [
          {
            name: 'Horsehoe',
            code: '728429',
            image: `https://picsum.photos/seed/${Math.random()}/64`,
            inventory: 5,
            price: '$10.20',
            promoPrice: '$9.99',
            location: '',
            lastSynced: ''
          },
          {
            name: 'Horsehoe',
            code: '728428',
            image: `https://picsum.photos/seed/${Math.random()}/64`,
            inventory: 5,
            price: '$10.20',
            promoPrice: '$9.99',
            location: '',
            lastSynced: ''
          },
          {
            name: 'Horsehoe',
            code: '728427',
            image: `https://picsum.photos/seed/${Math.random()}/64`,
            inventory: 5,
            price: '$10.20',
            promoPrice: '$9.99',
            location: '',
            lastSynced: ''
          },
          {
            name: 'Horsehoe',
            code: '728426',
            image: `https://picsum.photos/seed/${Math.random()}/64`,
            inventory: 5,
            price: '$10.20',
            promoPrice: '$9.99',
            location: '',
            lastSynced: ''
          }
        ]
      };
    },
    mounted() {
      let chart = new ApexCharts(document.querySelector("#socialChart"), this.socialChartOptions);
      chart.render();
    }
  };
</script>

<style lang="scss" scoped>
  $primary: #ED6730;
  .numbers {
    .value {
      font-size: 36px;
      line-height: 36px;
      font-weight: 500;
    }
    .diff {
      font-weight: bold;
      font-size: 17px;
      margin-left: 10px;
      &.positive {
        color: #04ad38;
      }
      &.negative {
        color: #ff4a4f;
      }
    }
    .label {
      font-weight: 500;
      font-size: 17px;
      color: #697680;
    }
  }
  .card {
    .card-title {
      padding-bottom: 8px;
      margin-bottom: -1px;
      position: relative;
      z-index: 1;
      border-bottom: 1px solid #e3e3e3;
    }
  }
  .info-lists {
    .list-group {
      max-height: 400px;
      overflow-y: auto;
      .list-group-item {
        padding-left: 0;
        padding-right: 0;
      }
    }
  }
  .viewed-items {
    .name {
      font-size: 18px;
      font-weight: 500;
      line-height: 20px;
      max-height: 40px;
      overflow: hidden;
    }
    .code {
      font-size: 13px;
      color: #7e8695;
      font-weight: 500;
    }
    .views-wrapper {
      flex: 1;
      color: $primary;
      font-weight: bold;
      font-size: 13px;
      letter-spacing: -1px;
      .views {
        background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTlweCIgaGVpZ2h0PSIxMnB4IiB2aWV3Qm94PSIwIDAgMTkgMTIiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8ZyBpZD0iU3ltYm9scyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9InZpZXdlZC1pdGVtIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjgxLjAwMDAwMCwgLTM2LjAwMDAwMCkiIGZpbGw9IiNFRDY3MkYiIGZpbGwtcnVsZT0ibm9uemVybyI+CiAgICAgICAgICAgIDxnIGlkPSJHcm91cC0xOSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjgxLjAwMDAwMCwgMzYuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICA8ZyBpZD0iZXllIj4KICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNOS41LDAgQzUuODY5ODQ3NiwwIDIuNTc3ODM1NzQsMi4wNTAzNjY5MyAwLjE0ODY2NTIzNSw1LjM4MDcwODUyIEMtMC4wNDk1NTUwNzgyLDUuNjUzNTU1NzggLTAuMDQ5NTU1MDc4Miw2LjAzNDczOTQ1IDAuMTQ4NjY1MjM1LDYuMzA3NTg2NzIgQzIuNTc3ODM1NzQsOS42NDE5NDA3NiA1Ljg2OTg0NzYsMTEuNjkyMzA3NyA5LjUsMTEuNjkyMzA3NyBDMTMuMTMwMTUyNCwxMS42OTIzMDc3IDE2LjQyMjE2NDMsOS42NDE5NDA3NiAxOC44NTEzMzQ4LDYuMzExNTk5MTggQzE5LjA0OTU1NTEsNi4wMzg3NTE5MSAxOS4wNDk1NTUxLDUuNjU3NTY4MjQgMTguODUxMzM0OCw1LjM4NDcyMDk4IEMxNi40MjIxNjQzLDIuMDUwMzY2OTMgMTMuMTMwMTUyNCwwIDkuNSwwIFogTTkuNzYwNDA3MDgsOS45NjI5Mzc1NCBDNy4zNTA2Njk5NCwxMC4xMTk0MjM1IDUuMzYwNjkzNDYsOC4wNjkwNTY1NCA1LjUxMjI3MzcsNS41NzczMTkwNCBDNS42MzY2NDcyMywzLjUyMjkzOTY1IDcuMjQ5NjE2NDUsMS44NTc3Njg4NiA5LjIzOTU5MjkyLDEuNzI5MzcwMTUgQzExLjY0OTMzMDEsMS41NzI4ODQyMiAxMy42MzkzMDY1LDMuNjIzMjUxMTUgMTMuNDg3NzI2Myw2LjExNDk4ODY1IEMxMy4zNTk0NjYxLDguMTY1MzU1NTggMTEuNzQ2NDk2OSw5LjgzMDUyNjM3IDkuNzYwNDA3MDgsOS45NjI5Mzc1NCBaIE05LjYzOTkyMDIyLDguMDYxMDMxNjIgQzguMzQxNzcxNSw4LjE0NTI5MzI4IDcuMjY5MDQ5ODEsNy4wNDE4NjY4NSA3LjM1NDU1NjYxLDUuNzAxNzA1MyBDNy40MjA2MzAwNSw0LjU5NDI2NjQxIDguMjkxMjQ0NzYsMy42OTk0ODc4OCA5LjM2Mzk2NjQ1LDMuNjI3MjYzNjEgQzEwLjY2MjExNTIsMy41NDMwMDE5NSAxMS43MzQ4MzY5LDQuNjQ2NDI4MzggMTEuNjQ5MzMwMSw1Ljk4NjU4OTk0IEMxMS41NzkzNjk5LDcuMDk4MDQxMjkgMTAuNzA4NzU1Miw3Ljk5MjgxOTgxIDkuNjM5OTIwMjIsOC4wNjEwMzE2MiBaIiBpZD0iU2hhcGUiPjwvcGF0aD4KICAgICAgICAgICAgICAgIDwvZz4KICAgICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+') center 0 no-repeat;
        text-align: center;
        padding-top: 16px;
        min-width: 19px;
      }
    }
  }
  .table.customerLogins > tbody > tr > td,
  .table.customerLogins > thead > tr > th {
    vertical-align: middle;
  }
</style>
