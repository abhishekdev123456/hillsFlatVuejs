<template>
  <main>
    <div class="container" v-for="section in homepageSections" :key="'section-' + section.id">
      <favourite-products-section v-if="section.widget_type == 2"/>
      <subscribe-section v-if="section.widget_type == 3"/>
      <carousel-section v-if="section.widget_type == 4"/>
      <!-- <departments-section v-if="section.widget_type == 6"/> -->
    </div>
    <choose-store ref="storeModal" />
  </main>
</template>

<script>
import HomePageApiService from '@/api-services/homepage.service';
import ChooseStore from '@/components/modals/choose-store.vue';
import ProductApiService from '@/api-services/product.service';

export default {
  name: 'LandingPage',
  components: {
    ChooseStore
  },
  data() {
    return {
      r: {}
    };
  },
  computed: {
    homepageSections() {
      return this.$store.state.homepage;
    }
  },
  async mounted() {
    let response;
    if (!this.homepageSections) {
      let resp = await HomePageApiService.getSections();
      response = resp.data.data;
    } else {
      response = this.homepageSections;
    }

    let coupons = response.find(elem => elem.widget_type === '1');
    let productSections1 = response.filter(elem => elem.widget_type === '2');
    let productSections2 = response.filter(elem => elem.widget_type === '7');
    let productSections = [...productSections1, ...productSections2];

    let allSKUs = [];
    let allProducts = [];
    productSections.forEach((section) => {
      section.data.forEach((item) => {
        item.competitors = null;
        item.similars = null;
        item.videos = null;

        allProducts.push(item);
        allSKUs.push(item.sku);
      });
    });

    this.$store.commit('addProductsRange', allProducts);
    this.$store.commit('setCoupons', coupons.data);
    this.$store.commit('setHomepageSection', response);
    localStorage.setItem('homepage', JSON.stringify(response));

    if (allSKUs.length) {
      ProductApiService.getCompetitorsForSKUList(allSKUs)
        .then((response) => {
          let competitors = response.data.data;

          this.$store.commit('setMultiCompetitors', competitors);
        });
    }

    this.$store.commit('setHomepageSection', response);
    localStorage.setItem('homepage', JSON.stringify(response));

    if(this.$store.state.activeUser && !this.$store.state.activeUser.store && !localStorage.getItem('store')) {
      // this.$refs.storeModal.showModal();
    }
  }
};
</script>

<style lang="scss" scoped>
@import '@/assets/scss/home.scss';
main {
  padding-bottom: 0;
}
</style>
