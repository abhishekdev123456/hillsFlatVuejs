<template>
  <main>
    <div class="container search-container">
      <div class="row">
        <div class="col-md-12 col-xs-12 pl-2 search-results" v-if="searchResults">
          <div class="row mb-3 search-result-page">
            <div class="col-md-3 col-sm-12 col-xs-12 search-result-content">
              <span>{{ searchResults.total }} Results for "<b>{{ deptName }}</b>"</span>
            </div>
            <div class="col-md-6 col-sm-12 col-xs-12">
              <v-pagination
                v-if="searchResults.last_page > 1"
                v-model="currentPage"
                :page-count="searchResults.last_page"
                :classes="bootstrapPaginationClasses"
                :labels="paginationAnchorTexts"
                @input="gotoPage"
                style="margin: 0;"
              />
            </div>

            <div class="col-md-3 col-sm-12 col-xs-12 d-flex justify-content-end search-result-content">
              <v-select
                :options="sortOptions"
                v-model="sortby"
                @input="doSort"
                style="width: 150px; float: right;"
              ></v-select>
            </div>

          </div>
          <div class="row" style="text-align: center; justify-content: center;" v-if="!searchResults.data">
            <spinner size="large" message="Waiting for the data..." />
          </div>
          <div class="row" v-if="searchResults.total > 0">
          <div class="search-product">
            <div
              v-for="item in searchResults.data"
              :key="item.upc_id"
              class="col-md-3 search-product-item mb-3 p-0 ">
              <product-item :item="item" />
            </div>
          </div>
          </div>
          <div class="row" style="justify-content: center" v-if="searchResults.total === 0">
            <span class="text-center">
              No products were found in this department
            </span>
          </div>
          <div class="row">
            <v-pagination
              v-if="searchResults.last_page > 1"
              v-model="currentPage"
              :page-count="searchResults.last_page"
              :classes="bootstrapPaginationClasses"
              :labels="paginationAnchorTexts"
              @input="gotoPage"
            />
          </div>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
import Spinner from 'vue-simple-spinner';
import { paginationConfig } from '@/config/modules';
import VSelect from '@alfsnd/vue-bootstrap-select';

export default {
  name: 'search',
  components: {
    Spinner,
    VSelect
  },
  data() {
    return {
      ...paginationConfig,
      pages: 0,
      currentPage: 1,
      perPage: 48,
      deptId: '',
      deptName: '',
      searchFilters: {
        search: "''",
        dept_id: this.deptId ? this.deptId : '',
        limit: 48,
        sort: 'price-desc',
        page: 1
      },
      sortOptions: [
        {value: "price-desc", text: "Price High to Low"},
        {value: "price-asc", text: "Price Low to High"},
        {value: "relevancy", text: "Relevancy"},
        {value: "latest", text: "New Arrivals"},
        {value: "title-asc", text: "Alphabetical"},
      ],
      sortby: { text: 'Price High to Low', value: 'price-desc'},
      ignoreFirstDoSort: true
    };
  },
  computed: {
      searchResults() {
          if (this.$store.state.searchResults) {
              //if (this.$store.state.searchResults.products.search !== this.keyword) {
              //    this.$forceUpdate();
              //}
              return this.$store.state.searchResults.products;
          } else {
              return null;
          }
      }
  },
  async mounted() {
    this.deptName = this.$route.params.title;
    this.searchFilters.dept_id = this.$route.params.id;
    if(!this.results) {
      await this.$store.dispatch("clearSearch");
      await this.getSearch();
    }
  },
  updated() {

  },
  methods: {
    gotoPage() {
      this.searchFilters.page = this.currentPage;
      this.getSearch();
    },
    doSort() {
      if ( this.ignoreFirstDoSort ) {
          //this.ignoreFirstDoSort = false;
          //return;
      }
      if ( this.searchFilters.sort !== this.sortby.value ) {
          this.searchFilters.sort = this.sortby.value;
          this.getSearch();
      }
    },
    async getSearch() {
      // if using a deptId with no keyword, make the server search all items in department
      await this.$store.dispatch('search', this.searchFilters);
      this.$forceUpdate();
    }
  },
};
</script>

<style scoped lang="scss">

  .discounted-item {
    width: auto !important;
    margin: 0 5px !important;
  }

  .promo-check {
    font-size: 16px;
  }

  .none-style-list {
    list-style: none;
  }

  li {
    font-size: 12px;
  }

  .tree-view {
    font-size: 12px;
  }

  .item-counts {
    font-size: 11px;
    color: grey;
  }

  .item-counts::before {
    content: '(';
  }
  .item-counts::after {
    content: ')';
  }

  .price-select-btn {
    padding: 0px 8px;
    margin-left: 10px;
    height: 25px;
  }

  .departments-list.active {
    color: #48ce3d;
  }

  li.indent-2 {
    margin-left: 10px !important;
  }

  li.indent-2::before, li.indent-3::before {
    content: '↳';
    /* content: '\2713'; */
    margin-right: 5px;
  }

  li.indent-3 {
    margin-left: 20px !important;
  }

  .v-select {
    width: 150px;
  }
  .search-product {
    display: flex;
    flex-wrap: wrap;
    width: 100%;
  }
  @media screen and (max-width: 767px) {
    .search-product-item {
      width: 50%;
    }
    .card {
      margin-top: 20px;
    }
    .search-result-page {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
    }
    .search-result-content {
      text-align: center;
      justify-content: center !important;
      display: flex;
      margin-top: 10px;
      margin-bottom: 10px;
    }
  }
  @media screen and (max-width: 576px) {
    .search-product-item {
      width: 100%;
      padding: 0 15px;
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1024px) {
    .search-container .search-product-item {
      max-width: 33.33%;
      flex: unset;
    }
    .search-container .search-product .search-product-item .product h6 {
      font-size: 12px;
    }
    .product .info > div {
      font-size: 12px !important;
    }
    .search-container {
      margin-top: 30px;
    }
    .none-style-list {
      display: flex;
      justify-content: space-between;
      align-items: center;
      input {
        min-width: 30px;
        max-width: 50px;
      }
    }
  }
</style>


