import Vue from 'vue';
import App from '@/App.vue';
import router from '@/router/index';
import store from '@/store';
import Vuelidate from 'vuelidate';
import VueTimeago from 'vue-timeago';
import VueSweetalert2 from 'vue-sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';

Vue.prototype.router = router;
Vue.config.productionTip = false;
Vue.use(Vuelidate);
Vue.use(VueTimeago, {
  name: 'Timeago', // Component name, `Timeago` by default
  locale: 'en'
});
Vue.use(VueSweetalert2);

require('@/plugins');

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app');

