<template>
  <div>
    <!-- Main EZ-AD Header -->
    <main-header></main-header>

    <!-- Visitor's site header -->
    <!--<site-header></site-header>-->
    <slot />

    <!-- Admin footer -->
    <main-footer :business="business" />
  </div>
</template>

<script>
  import HomePageApiService from '@/api-services/homepage.service';

  export default {
    name: 'AdminLayout',
    data() {
      return {
        business: {
          facebook_link: '',
          twitter_link: '',
          instagram_link: '',
          youtube_link: '',
        },
        banner: {
          message: 'Limited Time Offer: Free Delivery to your Home',
          button_title: 'Shop Now',
          custom_uri: ''
        }
      };
    },
    computed: {
      socialMedia() {
        return this.business.facebook_link || this.business.twitter_link || this.business.instagram_link || this.business.pinterest_link || this.business.youtube_link || this.business.linkedin_link;
      }
    },
    async mounted() {
      let resp = await HomePageApiService.getBusinessDetails();
      this.business = resp.data.data;
      this.$store.commit('setBusinessDetails', this.business);
    }
  };
</script>

<style lang="scss" scoped>
  .banner {
    background-color: #4A90E2;
    font-weight: 500;
    display: flex;
    justify-content: center;
    align-items: center;
    .banner-container {
      display: flex;
      a {
        .btn {
          font-weight: 500;
        }
      }

      .edit {
        margin-left: 8px;

        a {
          margin: 0 3px;
          cursor: pointer;
        }
      }
    }
  }

  @media (max-width: 991px) {
    .banner {
      padding: 10px 0;
      font-size: 12px;
      flex-direction: row;

      a {
        margin-left: 10px;
      }
    }
  }

  @media (max-width: 576px) {
    .banner {
      flex-direction: column;
    }
    .banner-container {
      .btn-outline-white {
        font-size: 12px;
        line-height: 12px;
      }

      .edit {
        margin-top: 5px;

        img {
          width: 24px;
        }
      }
    }
  }
</style>
