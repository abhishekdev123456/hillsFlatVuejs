<template>
  <div>
    <div class="sticky-header">
      <b-alert v-if="banner" show dismissible class="banner">
        {{ banner.message }}
        <a class="btn btn-outline-white" :href="banner.custom_uri">{{ banner.button_title }}</a>
      </b-alert>
      <header class="d-none d-md-block" ref="mainHeader">
        <div class="container">
          <router-link to="/" class="brand text-white">
            <img class="brand-logo-image" src="/icons/logo.png" alt="Logo">
          </router-link>
          <div class="search">
            <vue-autosuggest
              ref="autocomplete"
              :suggestions="searchSuggestions"
              :inputProps="inputProps"
              :sectionConfigs="sectionConfigs"
              :renderSuggestion="renderSuggestion"
              :getSuggestionValue="getSuggestionValue"
            >
              <template slot="footer">
                <div class="search-suggestion-footer">
                  None of the results match?
                  <span class="search-link" @mouseup="toSearchPage">Click here</span>
                </div>
              </template>
            </vue-autosuggest>
            <b-button class="search-btn" @click="toSearchPage">Search</b-button>
          </div>
          <div v-if="activeUser" id="logged-user" v-click-outside="hideDropdown">
            Welcome, <strong>{{ activeUser.first_name }}</strong>
            <!-- <router-link to="/settings"> -->
              <img src="/icons/gear.png" @click="showDropDown = !showDropDown">
            <!-- </router-link> -->
            <transition name="slide">
              <div class="account-setting-dropdown" v-if="showDropDown">
                <li @click="hideDropdown">
                  <router-link to="/account">
                    <div class="dropdown-item mb-2 mr-4">
                      Account Info
                    </div>
                  </router-link>
                </li>
                <li @click="hideDropdown">
                  <router-link to="/orders">
                    <div class="dropdown-item mb-2 mt-2 mr-4">
                      Orders
                    </div>
                  </router-link>
                </li>
                <!-- <li @click="hideDropdown">
                  <router-link to="/payment">
                    <div class="dropdown-item mb-2 mt-2 mr-4">
                      Payment methods
                    </div>
                  </router-link>
                </li> -->
                <li @click="hideDropdown">
                  <div class="dropdown-item mb-2 mr-4" @click="logout">
                    Logout
                  </div>
                </li>
              </div>
            </transition>
          </div>
          <div v-else id="authorization">
            <router-link to="/login">Sign In</router-link>or<router-link to="/register">Sign Up</router-link>
          </div>
          <router-link to="/cart" class="btn btn-primary cart">
            <img src="/icons/cart.svg" alt="Cart" class="mr-2">
            Cart
            <span v-if="cart" class="badge badge-pill badge-dark" :class="whileAdding?'badge-stroke':''">{{ cartAmount }}</span>
          </router-link>
        </div>
      </header>
      <b-navbar toggleable="md" type="light" variant="light"  ref="mainMobileHeader">
        <b-container>
          <b-navbar-toggle target="navContent" class="bg-light"/>
          <div class="quick-links d-flex d-md-none">
            <div class="search d-inline-block w-100 px-4">
              <vue-autosuggest
                ref="autocomplete"
                :suggestions="searchSuggestions"
                :inputProps="inputProps"
                :sectionConfigs="sectionConfigs"
                :renderSuggestion="renderSuggestion"
                :getSuggestionValue="getSuggestionValue"
              >
                <template slot="footer">
                  <div class="search-suggestion-footer">
                    None of the results match?
                    <span class="search-link" @mouseup="toSearchPage">Click here</span>
                  </div>
                </template>
              </vue-autosuggest>
            </div>
            <router-link to="/cart" class="btn btn-primary cart">
              <img src="/icons/cart.svg" alt="Cart">
              <span v-if="cart" class="badge badge-pill badge-dark ml-1">{{ cartAmount }}</span>
            </router-link>
          </div>
          <b-collapse id="navContent" is-nav>
            <a class="navbar-brand d-block d-md-none my-2" href="/">
              <img class="brand-logo-image mr-2" src="/icons/logo.png" alt="Logo">
              <!--<h1 class="d-inline-block text-white">AAA Hardware</h1>-->
            </a>
            <b-navbar-nav class="mr-auto">
              <li class="nav-item">
                <router-link to="/" class="nav-link">Home</router-link>
              </li>
              <li class="nav-item" v-if="preferences.departments">

              </li>
              <li class="nav-item" v-if="preferences.brands">
                <router-link to="/brands" class="nav-link">Brands</router-link>
              </li>
              <li v-if="!activeUser" class="nav-item d-list-item d-md-none">
                <router-link to="/login" class="nav-link">Login</router-link>
              </li>
            </b-navbar-nav>

            <b-navbar-nav class="ml-auto">
              <li class="nav-item">
                <a href="tel:(530) 273-6171" class="nav-link phone">
                  <div class="phone-text"></div>
                  <span>(530) 273-6171</span>
                </a>
              </li>
              <li class="nav-item">
                <router-link to="/aboutus" class="nav-link alt-link">About Us</router-link>
              </li>
            </b-navbar-nav>
          </b-collapse>
        </b-container>
      </b-navbar>
    </div>

    <slot/>

    <main-footer :business="business" />
  </div>
</template>

<script>
import { debounce } from "debounce";
import HomePageApiService from '@/api-services/homepage.service';

export default {
  name: "SecondaryLayout",
  data() {
    return {
      business: {
        facebook_link: '',
        twitter_link: '',
        instagram_link: '',
        pinterest_link: '',
        youtube_link: '',
        linkedin_link: '',
      },
      searchKey: null,
      showDropDown: false,
      inputProps: {
        id: "autosuggest__input",
        onInputChange: this.getSuggestions,
        placeholder: "Enter what you are looking for",
        class: "form-control",
        name: "searchKey"
      },
      sectionConfigs: {
        products: {
          limit: 10,
          label: "Products",
          onSelected: selected => {
            this.searchKey = selected.item.title;
            this.$router.push({
              name: "products-id",
              params: {
                id: selected.item.sku,
                title: selected.item.title.replace(/[ /]/g, "+")
              }
            });
          }
        },
        departments: {
          limit: 3,
          label: "Departments",
          onSelected: selected => {
            this.searchKey = selected.item.name;
            this.toSearchPage();
          }
        },
        default: {
          onSelected: () => {
            this.toSearchPage();
          }
        }
      }
    };
  },
  computed: {
    cart() {
      return this.$store.state.cart;
    },
    cartAmount() {
      return this.$store.getters.cartTotal;
    },
    banner() {
      return this.$store.state.banner;
    },
    activeUser() {
      return this.$store.state.activeUser;
    },
    searchSuggestions() {
      if(this.$store.state.searchSuggestions) {
        let arr = this.$store.state.searchSuggestions;
        let temp = [];
        const products = arr.products && arr.products.items;
        const departments = arr.departments && arr.departments.items;
        products.length && temp.push({ name: 'products', data: products });
        departments.length && temp.push({ name: 'departments', data: departments });
        return temp;
      }
      else
        return [];
    },
    preferences() {
      return this.$store.state.preferences;
    },
    whileAdding() {
      return this.$store.state.addingToCart;
    },
    socialMedia() {
      return this.business.facebook_link || this.business.twitter_link || this.business.instagram_link || this.business.pinterest_link || this.business.youtube_link || this.business.linkedin_link;
    }
  },
  async mounted() {
    let resp = await HomePageApiService.getBusinessDetails();
    this.business = resp.data.data;
    this.$store.commit('setBusinessDetails', this.business);
  },
  methods: {
    toSearchPage() {
      if (this.searchKey) {
        this.$store.dispatch("clearSearch");
        this.$store.dispatch("search", {
          search: this.searchKey,
        });
        if (this.$route.name === "search") {
          let query = Object.assign({}, this.$route.query, {
            keyword: this.searchKey,
            limit: 48
          });
          this.$router.push({ query: query });
        } else {
          this.$router.push({
            name: "search",
            query: {
              keyword: this.searchKey,
              limit: 48
            }
          });
        }
      }
    },
    hideDropdown() {
      this.showDropDown = false;
    },

    getSuggestions(text) {
      if (text == "" || text == undefined) return;
      this.searchKey = text;
      this.$store.dispatch("searchSuggestion", this.searchKey);
    },

    renderSuggestion(suggestion) {
      const item = suggestion.item;
      if (suggestion.name == 'products') {
        return (
          <div>
            <img class={{ avatar: true }} src={ item.image_url } />
            { item.title }
          </div>
        );
      } else if (suggestion.name == 'departments') {
        if(item.parent) {
          return (
            <div style="font-size: 12px;">
              <span>{ item.name }</span>
              <span style="color: grey;"> in </span>
              <span style="color: grey; font-size: 11px;">{ item.parent.name }</span>
            </div>
          );
        } else
          return (
            <div style="font-size: 12px;">
              <span>{ item.name }</span>
            </div>
          );
      }
    },

    getSuggestionValue(suggestion) {
      let { name, item } = suggestion;
      return name == "products" ? item.title : item.name;
    },
  },
  watch: {
    searchKey: debounce(function(newQuery) {
      this.getSuggestions(newQuery);
    }, 250)
  }
};
</script>

<style>
  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 10px;
    width: 100%;
  }

  nav.navbar .quick-links li {
    display: inline-table;
    height: auto;
    line-height: 16px;
  }

  .autosuggest__results .autosuggest__results_title {
    width: 100%;
  }

  .phone-text > .fa-icon {
    fill: #ed6730;
  }
</style>
