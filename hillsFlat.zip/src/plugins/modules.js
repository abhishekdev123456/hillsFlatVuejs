import Vue from 'vue';
import Axios from 'axios';
import 'vue-awesome/icons';
import AuthController from '@/controllers/auth.controller';
import BootstrapVue from 'bootstrap-vue';
import VueSelect, {CoolSelect} from 'vue-cool-select';
import VueAwesomeSwiper from 'vue-awesome-swiper';
import VueVideoPlayer from 'vue-video-player';
import VueClazyLoad from 'vue-clazy-load';
import vPagination from 'vue-plain-pagination';
import Icon from 'vue-awesome/components/Icon';
import VueBootstrapTypeahead from 'vue-bootstrap-typeahead';
import VueYoutube from 'vue-youtube';
import VueAutosuggest from 'vue-autosuggest';
import ProductZoomer from 'vue-product-zoomer';
import * as VueGoogleMaps from 'vue2-google-maps';
import store from '@/store';

Axios.defaults.baseURL = 'https://api.ezadtv.com';

Axios.defaults.headers.Accept = 'application/json';
Axios.defaults.headers['Access-Control-Allow-Origin'] = '*';
Axios.defaults.headers['Business-Slug'] = store.state.business_slug;

Axios.interceptors.request.use(
  request => {
    // not sure why this was commented out. for showing other stores' inventories we need to
    // be able to send a Store-Id header corresponding to the store they picked in the popup.
    const storeId = localStorage.getItem('selectedStore');
    if ( storeId ) {
      request.headers['Store-Id'] = storeId;
    }

    return request;
  }
);

Axios.interceptors.response.use (
  response => {
    return response;
  },
  error => {
    if (error.response.status === 401 && AuthController.checkAuthStatus ()) {
      AuthController.logout (false);
    }
    throw error;
  }
);

Vue.component ('cool-input', CoolSelect);
Vue.component ('v-pagination', vPagination);
Vue.component ('icon', Icon);
Vue.component ('vue-bootstrap-typeahead', VueBootstrapTypeahead);

Vue.use (VueAwesomeSwiper);
Vue.use (VueVideoPlayer);
Vue.use (BootstrapVue);
Vue.use (VueYoutube);
Vue.use (VueAutosuggest);
Vue.use (ProductZoomer);

Vue.use (VueSelect, {
  theme: 'bootstrap',
});
Vue.use (VueClazyLoad);

Vue.use(VueGoogleMaps, {
  load: {
    key: 'AIzaSyBTKZfC1-HI_ow5v-zPO9vVm7dFjpZCpWs',
    libraries: 'places',
  }
});

AuthController.initStoreAuth ();
