<template>
  <div class="change-quantity">
    <button type="button" class="btn-qty btn btn-primary" @click="updateQty(qty - 1)">-</button>
    <input v-model="quantity" type="number" class="form-control" min="0" disabled>
    <button type="button" class="btn-qty btn btn-primary" :disabled="outOfStock" @click="updateQty(qty + 1)">+</button>
  </div>
</template>

<script>
import CartApiService from '@/api-services/cart.service';

export default {
  name: 'ChangeQuantity',
  props: {
    qty: {
      type: Number,
      default: 0
    },
    cartItem: {
      type: Object,
      default: null
    },
    limit: {
      type: Number,
      default: 1
    },
    special: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      quantity: this.qty
    };
  },
  computed: {
    outOfStock() {
      return !(this.cartItem.num_inventory - this.qty);
    }
  },
  methods: {
    updateQty(value) {
      if (!this.cartItem || value < 0) return;
      if (value === 0) {
        this.overlayActive = false;
        this.$store.state.addingToCart = true;
        CartApiService.removeItem(this.cartItem.store_product_id  || this.cartItem.id)
        .then(() => {
          this.quantity = 0;
          this.$store.dispatch("fetchCartItemsDetails");
          this.$store.state.addingToCart = false;
        });
      } else {
        this.quantity = value;
        this.$store.state.addingToCart = true;
        CartApiService.addItem(this.cartItem.store_product_id || this.cartItem.id, value)
        .then(resp => {
          switch(resp.data.status) {
            case 'error':
              this.$swal(resp.data.message, '', 'error');
              break;
            case 'success':
              this.quantity = value;
              this.$store.dispatch("fetchCartItemsDetails");
              this.$store.state.addingToCart = false;
              break;
          }
        })
        .catch(err => {
          console.log(err);
          this.$swal(err.response.message, '', 'error');
        });
      }
    }
  }
};
</script>

