<template>
  <div class="card card-primary discounted-item" @click="goToDetailsPage(item)">
    <div class="card-body p-0">
      <div class="product">
        <div v-if="!editable " class="add-to-card" @click.stop="openQtyModal">
          <div v-if="!outOfStock">
            <span class="q" v-if="quantity > 0">
              {{ quantity }}
            </span>
            <img class="q" v-else src="/icons/add-to-cart.svg">
          </div>
        </div>
        <div class="edit-product" v-else>
          <a><img src="/images/edit.png"></a>
          <a><img src="/images/remove.png"></a>
        </div>
        <span v-if="item.promo_price" class="badge badge-danger">
          <span>SPECIAL</span>${{ item.promo_price }}
        </span>
        <div v-if="!loaded" class="loader-wrapper">
          <img src="/icons/loader.gif" class="loader">
        </div>
        <img
          :src="internalApi ? (item.image || '/images/default-img.svg') : (item.image_url || '/images/default-img.svg')"
          :alt="item.title | lowerCase"
          @load="loaded = true"
          :class="{ 'd-none': !loaded }"
          class="product-image img-fluid">
        <h6>{{ item.title | lowerCase }}</h6>
        <div class="info">
          <div class="standard-price">
            <div class="small">reg.</div>&nbsp;${{ item.price | removeDecimals }}
          </div>
          <div v-if="businessDetails.show_stock_level" class="items-left text-danger">
            <template v-if="item.num_inventory >= 1 && item.num_inventory <= 5">
              <span v-if="!outOfStock">Only {{ item.num_inventory }} Left</span>
              <span v-else>Out of Stock</span>
            </template>
            <template v-else>
              <template v-if="item.num_inventory <= 0">
                <span class="out-of-stock" v-if="outOfStock">Out of Stock</span>
                <span v-else>Special Order</span>
              </template>
            </template>

          </div>
        </div>
      </div>
    </div>
    <div v-if="businessDetails.show_competitors"
         class="bg-white" :class="{ 'd-none': item.competitors && !item.competitors.length }">
      <img v-if="!item.competitors || !item.competitors.length" src="/icons/loader.gif" class="loader">
      <div v-if="item.competitors && item.competitors.length" class="compare">
        <div>
          <span>Compare <br/>Price To</span>
        </div>
        <div v-for="(competitor, index) in item.competitors" :key="`competitors-item-${item.id}-${index}`">
          <span>${{ competitor.price | removeDecimals }}</span>
          <img style="max-width:100%;" :src="competitor.logo">
        </div>
      </div>
    </div>
    <div v-if="overlayActive" class="overlay" @click="closeQtyModal">
      <div ref="qty" v-click-outside="closeQtyModal" class="btn-group" role="group">
        <button type="button" class="btn btn-white qty-minus" :disabled="quantity === 0" @click="updateQty(quantity - 1)"></button>
        <div class="input-group">
          <input v-model="quantity" type="text" class="form-control" min="1" readonly>
        </div>
        <button type="button" class="btn btn-white qty-plus" :disabled="!canAddMore()" @click="updateQty(quantity + 1)"></button>
      </div>
    </div>
  </div>
</template>

<script>
  import CartApiService from '@/api-services/cart.service';

  export default {
    name: 'ProductItem',
    props: {
      item: {
        type: Object,
        default: null
      },
      internalApi: {
        type: Boolean,
        default: false
      },
      editable: {
        type: Boolean,
        default: false
      }
    },
    data: () => ({
      loaded: false,
      overlayActive: false,
      quantity: 0,
    }),
    mounted(){
      if(this.$store.state.cart.parcels){
        if(this.$store.state.cart.parcels[0]) {
          let items = this.$store.state.cart.parcels[0].items;
          [...items].forEach(item => {
            if(item.sku == this.item.sku) {
              this.quantity = item.quantity;
            }
          });
        }
      }

      // HACK BECAUSE THE ITEM RESPONSE IS DIFFERENT IN SOME APIS (i.e. addons)
      if(this.item.num_inventory === undefined) {
        //console.log('item inv hack', this.item.num_inventory, this.item.inventory);
        this.item.num_inventory = this.item.inventory;
      }
    },
    computed: {
      cart() {
        return this.$store.state.cart;
      },
      preferences() {
        return this.$store.state.preferences;
      },
      businessDetails() {
        return this.$store.state.businessDetails;
      },
      outOfStock() {
        //console.log('outOfStock', this.item);
        return parseInt(this.item.num_inventory) <= 0 && (!this.businessDetails.show_oos_special || !this.item.vendor_id);
      }
    },
    watch: {
      'cart': {
        handler() {
          const cartParcels = this.cart.parcels;
          if (cartParcels && cartParcels.length) {
              const pickupParcel = cartParcels.find(item => {
                  return item.type === 'pickup';
              });
              const specialParcels = cartParcels.filter(item => {
                  return item.type === 'special';
              });
              let specialItems = [];
              if (specialParcels && specialParcels.length) {
                  specialParcels.forEach(parcel => {
                      if (parcel.items && parcel.items.length) {
                          specialItems = [...specialItems, ...parcel.items];
                      }
                  });
              }
              let items;
              if ( pickupParcel ) {
                  items = [...specialItems, ...pickupParcel.items];
              } else {
                  items = specialItems;
              }
              let cartItem = items.find(x => x.store_product_id === this.item.id);
              if (cartItem && cartItem.quantity) {
              }
          }
        },
        deep: true
      }
    },
    methods: {
      urlFriendly(value) {
        return value.replace(/[ /]/g, '+');
      },
      goToDetailsPage(item) {
        this.$router.push({
          name: 'products-id',
          params: {
            id: item.sku,
            title: this.urlFriendly(item.title)
          }
        });
      },
      openQtyModal() {
        this.overlayActive = true;
      },
      closeQtyModal(event) {
        const path = event.path;
        event.stopPropagation();
        if (path.includes(this.$refs.qty)) return;
        this.overlayActive = false;
      },
      canAddMore() {
          if ( this.quantity < this.item.num_inventory ) {
              return true;
          }

          // if we are showing out of stock as special order and we have a vendor id, let them add
          return !!(this.businessDetails.show_oos_special && this.item.vendor_id);
      },
      updateQty(value) {
        this.$store.state.addingToCart = true;
        this.quantity = value;
        if (value === 0) {
          this.overlayActive = false;
          this.removeFromCart(this.item.store_product_id || this.item.id);
        } else {
          this.addToCart(this.item.store_product_id  || this.item.id, value);
        }
      },
      addToCart(item, quantity) {
        CartApiService.addItem(item, quantity)
        .then((res) => {
          if (res.status === 200) {
            this.$store.dispatch("fetchCartItemsDetails");
          } else {
            this.$swal(res.data.message, '', 'error');
          }
          this.$store.state.addingToCart = false;
        })
        .catch(() => {
          this.$swal('Add to Cart Error', '', 'error');
        });
      },
      removeFromCart(item) {
        CartApiService.removeItem(item)
        .then(() => {
          this.$store.dispatch("fetchCartItemsDetails");
          this.$store.state.addingToCart = false;
        });
      }
    },
    filters: {
      removeDecimals: function (value) {
        return Number(value).toString();
      },
      lowerCase: function(value) {
        value = value || '';
        return value.toLowerCase();
      }
    }
  };
</script>
<style lang="scss" scoped>
  .card {
    .card-body {
      .product {
        .edit-product {
          position: relative;
          top: -10px;
          left: 0;
          margin-left: 5px !important;

          a {
            margin: 0 3px;

            img {
              width: 25px;
              height: 25px;
            }
          }
        }
      }
    }
  }
</style>
