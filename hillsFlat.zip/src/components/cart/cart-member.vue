<template>
  <div>
    <div class="card-title" v-if="userInfo">Update Contact Info</div>
    <div class="card-title" v-else="">Create New Account</div>
    <div class="row">
      <div class="col-md-6 mb-3">
        <input :disabled="isDisabled" v-model="memberInfo.first_name" type="text" class="form-control p-2" placeholder="First Name" :class="{'is-invalid':errors.first_name}">
        <div v-if="errors.first_name" class="invalid-feedback">
          {{errors['first_name'][0] | parseResponse}}
        </div>
      </div>
      <div class="col-md-6 mb-3">
        <input :disabled="isDisabled" v-model="memberInfo.last_name" type="text" class="form-control p-2" placeholder="Last Name"
        :class="{'is-invalid':errors.last_name}">
        <div v-if="errors.last_name" class="invalid-feedback">
          {{errors.last_name[0] | parseResponse}}
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 mb-3">
        <input :disabled="isDisabled" v-model="memberInfo.telephone" type="tel" class="form-control p-2" placeholder="Phone number"
        :class="{'is-invalid':errors.telephone}">
        <div v-if="errors.telephone" class="invalid-feedback">
          {{errors.telephone[0] | parseResponse}}
        </div>
      </div>
      <div class="col-md-6 mb-3">
        <input :disabled="isDisabled" v-model="memberInfo.email" type="text" class="form-control p-2" placeholder="Email"
        :class="{'is-invalid':errors.email}">
        <div v-if="errors.email" class="invalid-feedback">
          {{errors.email[0] | parseResponse}}
        </div>
      </div>
    </div>
    <template v-if="!userInfo">
      <div class="row">
        <div class="col-md-6 mb-3">
          <input :disabled="isDisabled"
            v-model="memberInfo.password"
            ref="password"
            type="password"
            class="form-control p-2"
            placeholder="Password"
            :onchange="validatePassword()"
            :class="{'is-invalid':errors.password}">
          <div v-if="errors.password" class="invalid-feedback">
            {{errors.password[0] | parseResponse}}
          </div>
        </div>
        <div class="col-md-6 mb-3">
          <input :disabled="isDisabled"
            ref="c_password"
            type="password"
            class="form-control p-2"
            placeholder="Confirm Password"
            v-on:keyup="validatePassword()">
        </div>
      </div>
      <div class="success-msg mt-3" v-if="registerSuccess">
        <img src="/images/check.png" class="img-fluid mr-2" />Success! Your account has been created. You can now enter your Member Contact Info.
      </div>
      <b-alert
        class="mt-2"
        :show="alert.show"
        :variant="alert.variant"
        dismissible
        @dismissed="alert.show = false">
        {{ alert.message }}
      </b-alert>
      <div>
        Already have an account? <router-link class="ml-2" to="/login">Sign In</router-link>
      </div>
      <div class="d-flex align-items-center">
        <button :disabled="isDisabled" @click="createAccount" class="btn btn-secondary mx-auto mt-3" v-if="!userInfo" type="button">
          Create a New Account
        </button>
      </div>
    </template>
  </div>
</template>

<script>
  import UserApiService from '../../api-services/user.service';
  import AuthApiService from '@/api-services/auth.service';
  import AuthController from '@/controllers/auth.controller';

  export default {
    name: 'cartMember',
    data() {
      return {
        displayNewAccountSection: false,
        registerSuccess: false,
        memberInfo: {
          first_name: '',
          last_name: '',
          telephone: '',
          email: '',
          password: ''
        },
        alert: {
          show: false,
          variant: 'success',
          message: 'Successfully registered! Please login.'
        },
        userInfo: AuthController.checkAuthStatus(),
        errors: {}
      };
    },
    props: {
      isDisabled: {
        type: Boolean,
        default: false
      }
    },
    filters: {
      parseResponse(val) {
        return val.replace('member.', '');
      }
    },
    mounted() {
      if (this.userInfo) {
        this.memberInfo.first_name = this.userInfo.data.customer.first_name;
        this.memberInfo.last_name = this.userInfo.data.customer.last_name;
        this.memberInfo.telephone = this.userInfo.data.customer.telephone;
        this.memberInfo.email = this.userInfo.data.customer.email;
      }
    },
    watch: {
      memberInfo: {
        deep: true,
        handler(value) {
          // sync member info with checkout page
          this.$emit('memberInfoChanged', value);
        }
      }
    },
    methods: {
      async createAccount() {
        this.memberInfo.device_id = this.$store.state.device_id;
        UserApiService.register(this.memberInfo)
        .then(() => {
          AuthApiService.login(this.memberInfo.email, this.memberInfo.password, this.$store.state.device_id)
          .then(response => {
            if (response.data.status == "success") {
              let data = response.data;
              data.access_token = response.data.access_token;
              this.$swal({
                toast: true,
                position: 'top',
                showConfirmButton: false,
                timer: 3000,
                type: 'success',
                title: 'Congratulations for registering!'
              });
              AuthController.login(data);
              this.userInfo = AuthController.checkAuthStatus();
              this.$emit('loggedIn', this.userInfo);
            }
          });
        }, err => {
          this.showErrors(err.response.data.errors);
        });
      },
      validatePassword() {
        if (this.$refs.password && this.$refs.c_password) {
          if (this.$refs.password.value !== this.$refs.c_password.value) {
            this.$refs.c_password.setCustomValidity('Password doesn\'t match');
          } else {
            this.$refs.c_password.setCustomValidity('');
          }
        }
      },
      clearFields() {
        this.memberInfo = {
            first_name: '',
            last_name: '',
            telephone: '',
            email: '',
            password: ''
        };
      },
      showErrors(fields) {
        this.errors = fields;
      }
    }
  };

</script>