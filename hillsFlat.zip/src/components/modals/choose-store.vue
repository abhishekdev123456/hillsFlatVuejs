<template>
  <b-modal class="modal-box" id="choose-store" size="xl" ref="storeModal">  
    <div slot="modal-header">
      <span class="close-button" @click="hideModal">&times;</span>
      <div class="row title-row">
        <div class="title col-md-12">
          <h3 class="main-title">Choose Your Store</h3>
          <div class="sub-title">Select a store location to receive your orders from.</div>
        </div>
      </div>
    </div>
    <div class="d-block" slot="default">
      <div class="row search-row">
        <label class="search-label">Enter your zipcode to find your nearest store</label>
        <b-input class="mt-0 mb-3" placeholder="Enter the zipcode to find your nearest store"
          @keyup.enter="searchStore"
          v-model="zipcode" />

        <img src="/icons/search.svg" @click="searchStore" alt="Cart" class="mr-2">
      </div>

      <div class="row search-results mb-2">
        <b-list-group style="width: 100%;" v-if="storeLocations.length">
          <b-list-group-item button 
            v-for="store in storeLocations" 
            :key="store.address"
            @click="selectLocation(store, $event)"
            :class="store.selected ? 'active' : ''">
            {{ store.address }}
            <span style="float: right;">{{store.dist | trim}} miles away</span>
          </b-list-group-item>
        </b-list-group>
        <span style="margin: auto;" v-else>{{errorMsg}}</span>
      </div>
      <div class="row mb-4">
        Showing {{storeLocations.length}} locations
      </div>

      
    </div>
    <div slot="modal-footer">
      <div class="row search-result">
        <div class="col-lg-2" style="padding: 0;">Selected Location: </div>
        <span class="search-result--item active col-lg-8 col-md-12">
          <!-- <div v-if="selectedStore.address"> -->
            {{ selectedStore.address}}
            <span v-if="selectedStore.address" class="search-result--distance">
              {{selectedStore.dist | trim}} miles away
            </span>
          <!-- </div> -->
        </span>
        <div class="save-btn col-lg-2">
          <button @click="saveStore" class="btn btn-primary">Save</button>
        </div>
      </div>
    </div>
  </b-modal>
</template>

<script>
import SearchApiService from '@/api-services/search.service';
import UserApiService from '@/api-services/user.service';

export default {
  name: 'ChooseStore',
  data() {
    return {
      selectedStore: '',
      zipcode: '',
      // storeLocations: []
      errorMsg: "Type in your zipcode to see the nearby stores"
    };
  },
  watch: {
    // storeKeyword: function(val) {
    //   const temp = this.$store.state.storeLocations;
    //   this.storeLocations = temp.filter(item => item.address.includes(this.storeKeyword))
    // }
  },
  filters: {
    trim(value) {
      return value.toFixed(2);
    }
  },
  computed: {
    storeLocations() {
      return this.$store.state.storeLocations;
    }
  },
  methods: {
    hideModal() {
      this.$refs.storeModal.hide();
    },
    showModal() {
      this.$refs.storeModal.show();
    },
    selectLocation(store) {
      this.selectedStore = store;
      this.storeLocations.forEach(store => {
        store.selected = false;
      });
      store.selected = true;
    },
    saveStore() {
      if(!this.selectedStore) { // when store is not selected
        this.$swal('Please select a store location to receive your orders from', '', 'error');
      } else {
        // send axios request to save custom store location
        // store location will be saved in the backend
        // 
        this.$store.state.activeUser.store = this.selectedStore.id;
        localStorage.setItem('store', JSON.stringify(this.selectedStore));
        UserApiService.saveStore({store: this.selectedStore.id});
        this.$refs.storeModal.hide();
      }
    },
    searchStore() {
      const token = this.$store.state.activeUser.access_token;
      if(!token)
        return;
      if(!this.zipcode) {
        this.$swal('Please type in your zipcode', '', 'error');
        return;
      }
      SearchApiService.nearbyStore({
        access_token: this.$store.state.activeUser.access_token,
        zipcode: this.zipcode,
      }).then(response => {
        const status = response.data.status, data = response.data.data;
        if(status === 'success') {
          this.$store.dispatch('storeLocations', data);
          if(!data.length)
            this.errorMsg = 'No store is found for the input zipcode';
        } else {
          this.errorMsg = data;
        }
      }).catch(error => {
        console.log('error', error);
        console.log('error response', error.response);
        this.errorMsg = error.response.data.message;
      });
      // this.storeLocations = temp.filter(item => item.address.includes(this.storeKeyword))
    },
  }
};
</script>

<style lang="scss">
  // @import '@/assets/scss/modal-common.scss';
  #choose-store {
    .row {
      margin: 0 2rem;
    }
    .modal-header {
      div {
        width: 100%;
        .title-row {
          display: flex;
          align-content: space-between;
          color: black;

          .title {
            text-align: center;
          }
        }

        .close-button {
          width: 20px;
          height: 20px;
          background: #ed6730;
          border-radius: 50%;
          display: flex;
          justify-content: center;
          align-items: center;
          color: #fff;
          cursor: pointer;
          float: right;
        }
      }

    }

    .modal-body {
       
      .search-row {

        .search-label {
          font-size: 12px;
          display: block;
          width: 100%;
        }

        img {
          position: absolute;
          top: 55px;
          right: 55px;
          cursor: pointer;
        }
      }

      .search-results {
        height: 350px;
        border: 1px solid grey;
        overflow-y: scroll;

        .list-group {
          width: 100%;
          color: red;

          &-item {
            &.active {
              background-color: #aaa;
            }
          }
        }
      }
    }

    .modal-footer {
      display: block;
      
      .search-result {
        display: flex;
        align-items: center;

        &--item {
          width: 100%;
          background-color: rgb(180, 180, 180);
          color: white;
          border-radius: 2px;
          border-top: 1px solid rgb(128, 128, 128);
          line-height: 1.5;
          height: 2.5rem;
          display: flex;
          align-items: center;

          &.active {
            border: 1px solid lightgreen;
          }

          span {
            margin-left: auto;
          }
        }
        &--distance {
          float: right;
        }

        .save-btn {
          padding: 0;
          
          button {
            float: right;
          }
        }
      }
    }
  }
  
</style>
