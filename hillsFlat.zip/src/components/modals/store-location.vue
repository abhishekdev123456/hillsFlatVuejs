<template>
  <b-modal no-close-on-backdrop size="lg" class="modal-box" ref="storeSelectionModal">
    <h5 slot="modal-header">Choose your store</h5>
    <div class="store-select-modal">
      <div v-for="store in stores" :key="store.id" class="store-block d-flex w-100 align-items-center" :class="{'active': selectedStore == store.id}" @click="selectedStore = store.id">
        <div class="checkmark"></div>
        <div class="info">
          <span class="store-name">{{ store.name }}</span>
          <div class="store-content">
            <div class="store-address">
              {{ `${store.address}, ${store.city}, ${store.state}, ${store.zip}` }}
            </div>
            <a :href="`tel:+1${store.phone}`" class="store-bt store-contact">{{ store.phone }}</a>
            <div class="store-bt store-hours mt-1">
              Store Hours
              <div class="hours-tooltip">
                <ul>
                  <li v-for="hour in parseHours(store.hours)" :key="hour.day">
                    <div class="day">{{hour.day}}</div>
                    <div class="hours" v-html="`${hour.open} - ${hour.close}`"></div>
                  </li>
                  </ul>
              </div>

            </div>
          </div>
        </div>
        <div class="map-container">
          <GmapMap
            :ref="`map_${store.id}`"
            :options="{mapTypeControl: false}"
            style="flex: 1;"
            :center="getCenter(store)"
            :zoom="16"></GmapMap>
        </div>
      </div>
    </div>
    <div slot="modal-footer">
      <button type="button" class="btn btn-primary" @click="saveStore()">Continue</button>
    </div>
  </b-modal>
</template>


<script>
    import UserApiService from '@/api-services/user.service';
    import HomePageService from '@/api-services/homepage.service';

    export default {
      name: 'StoreLocation',
      data() {
        return {
          stores: [],
          storeNames: {},
          selectedStore: null,
          centerPoints: {}
        };
      },
      computed: {
        maps() {
          let maps = [];
            this.stores.forEach(store => {
              if(this.$refs[`map_${store.id}`]) {
                maps.push({
                  storeId: store.id,
                  map: this.$refs[`map_${store.id}`][0],
                  address: `${store.address}, ${store.city}, ${store.state}, ${store.zip}`
                });
              }
            });
          return maps;
        }
      },
      async mounted() {
        let resp = await HomePageService.getBusinessDetails();
        this.stores = resp.data.data.about_us.locations;
        this.selectedStore = localStorage.getItem('selectedStore') || null;
        this.stores.forEach((s, index) => {
          this.storeNames[s.id] = s.name;
          this.centerPoints[s.id] = {lat: 0, lng: 0};
          if(!s.id) {
            s.id = index;
          }
        });
        setTimeout(() => {
          this.$gmapApiPromiseLazy().then(() => {
            setTimeout(() => {
              this.maps.forEach(map => {
                  this.addMarker(map.map.$mapObject, map.address, map.storeId);
              });
            }, 10);
          });
        }, 200);
      },
      methods: {
        async addMarker(map, address, storeId) {
          let geocoder = new google.maps.Geocoder();
          geocoder.geocode({'address': address}, (results, status) => {
            if (status === 'OK') {
              this.centerPoints[storeId] = results[0].geometry.location;
              map.setCenter(results[0].geometry.location);
            } else {
              console.log('Geocode was not successful for the following reason: ' + status);
            }
          });
        },
        getCenter(store) {
          return this.centerPoints[store.id] || {lng:0,lat:0};
        },
        showModal() {
          this.$refs.storeSelectionModal.show();
        },
        hideModal() {
          this.$refs.storeSelectionModal.hide();
        },
        saveStore() {
          // just set the top one by default if they didn't click
          if ( !this.selectedStore ) {
            this.selectedStore = this.stores[0].id;
          }
          localStorage.setItem('selectedStore', this.selectedStore);
          this.$store.dispatch("fetchBusinessInfo");
          UserApiService.saveStore({store: this.selectedStore}).then(resp => {
            if(resp.status == 200) {
              this.$swal({
                toast: true,
                position: 'top',
                showConfirmButton: false,
                timer: 3000,
                type: 'success',
                title: 'Location changed'
              });
            }
          });
          this.$emit('changed', {id: this.selectedStore, name: this.storeNames[this.selectedStore]});
          this.hideModal();
        },
        parseHours(obj) {
          let arr = [];
          let days = {mon:'Monday',tue:'Tuesday',wed:'Wednesday',thu:'Thursday',fri:'Friday',sat:'Saturday',sun:'Sunday'};
          let temp = ['<span style="font-size: 10px; font-weight: 500">', '</span>'];
          Object.keys(obj).forEach(e => {
            if(obj[e].closed) {
              arr.push(false);
            } else {
              let open = obj[e].open.replace(/AM|PM/gi, m => { 
                  return temp[0] + m + temp[1];
                  //return {AM:`${temp[0]}AM${temp[1]}`, PM: `${temp[0]}PM${temp[1]}`}[m]; 
              });
              let close = obj[e].close.replace(/AM|PM/gi, m => { 
                  return temp[0] + m + temp[1];
                  //return {AM:`${temp[0]}AM${temp[1]}`, PM: `${temp[0]}PM${temp[1]}`}[m]; 
              });
              arr.push({
                day: days[e],
                open: open,
                close: close
              });
            };
          });
          return arr;
        }
      }
  };
</script>

<style scoped lang="scss">
  .store-select-modal .store-block {
    width: 100%;
    margin-bottom: 20px;
    padding-left: 30px;
    border-radius: 5px;
    border: 1px solid #e2e2e7;
    background: #fafafa;
    position: relative;
    cursor: pointer;
    .checkmark {
      border: 1px solid #e2e2e7;
      border-radius: 18px;
      width: 18px;
      height: 18px;
      background: #fff;
      position: relative;
    }
    .info {
      flex: 1;
      margin-left:30px;
    }
    .map-container {
      display: flex;
      height: 133px;
      width: 250px;
      overflow: hidden;
      border-top-right-radius: 5px;
      border-bottom-right-radius: 5px;
    }
  }
  .store-select-modal .store-block.active {
    border-color: #ed6730;
    box-shadow: 0 0 0 1px #ed6730, 0 20px 39px rgba(47, 53, 64, .1);
    background: #fff;
    cursor: auto;
    .checkmark {
      border: 2px solid #ed6730;
      &::after {
        content: '';
        left: 2px;
        top: 2px;
        position: absolute;
        width: 10px;
        height: 10px;
        border-radius: 10px;
        background: #ed6730;
      }
    }
  }
  .store-select-modal .store-block:last-child{
    margin-bottom: 0;
  }
  .store-select-modal .store-name {
    font-size: 18px;
    font-weight: bold;
  }
  .store-select-modal .store-content {
    font-size: 12px;
  }
  .store-select-modal .store-content .store-address {
    flex:1;
    padding-right: 50px;
  }
  .store-bt {
    background-repeat: no-repeat;
    padding-left: 20px;
    background-position: 0 center;
    display: inline-block;
    color: #ed6730;
    font-size: 11px;
    font-weight: 500;
    &.store-contact {
      background-image: url('data:image/svg+xml;base64,Cjxzdmcgd2lkdGg9IjE2cHgiIGhlaWdodD0iMTVweCIgdmlld0JveD0iMCAwIDE2IDE1IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPGcgaWQ9IkhpbGxzLUZsYXQtTHVtYmVyLVZlcnNpb24tMSIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICAgICAgICA8ZyBpZD0iSGlsbHMtRmxhdC1MdW1iZXItSG9tZS1QYWdlLURlc2lnbiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTk5OC4wMDAwMDAsIC0xNjMuMDAwMDAwKSIgc3Ryb2tlPSIjRUQ2NzMwIj4KICAgICAgICAgICAgPGcgaWQ9Ik5hdmJhci0vLUJhbm5lciIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMC4wMDAwMDAsIDYwLjAwMDAwMCkiPgogICAgICAgICAgICAgICAgPGcgaWQ9IkJvdHRvbS1OYXYtTGFiZWwiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAuMDAwMDAwLCA4NS4wMDAwMDApIj4KICAgICAgICAgICAgICAgICAgICA8ZyBpZD0iR3JvdXAtMyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoOTk5LjAwMDAwMCwgMTcuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik0xMSwxMCBMOSwxMiBMMyw2IEw1LDQgTDIsMSBMMCwzIEMwLDkuNjI3IDUuMzczLDE1IDEyLDE1IEwxNCwxMyBMMTEsMTAgWiIgaWQ9IlBhdGgiPjwvcGF0aD4KICAgICAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==');
    }
    &.store-hours {
      background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4IiB2aWV3Qm94PSIwIDAgMTYgMTYiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8ZyBpZD0iQWRtaW4tU2V0dGluZ3MtIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iQWRtaW4tVmlld0AyeC1Db3B5LTQiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00OTkuMDAwMDAwLCAtMTg0LjAwMDAwMCkiIHN0cm9rZT0iI0VENjcyRiI+CiAgICAgICAgICAgIDxnIGlkPSJ0aW1lLWNsb2NrIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MDAuMDAwMDAwLCAxODUuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNNywwIEw3LDIuNTQ1NDU0NTUiIGlkPSJQYXRoIj48L3BhdGg+CiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMTQsNyBMMTEuNDU0NTQ1NSw3IiBpZD0iUGF0aCI+PC9wYXRoPgogICAgICAgICAgICAgICAgPHBhdGggZD0iTTcsMTQgTDcsMTEuNDU0NTQ1NSIgaWQ9IlBhdGgiPjwvcGF0aD4KICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik0wLDcgTDIuNTQ1NDU0NTUsNyIgaWQ9IlBhdGgiPjwvcGF0aD4KICAgICAgICAgICAgICAgIDxjaXJjbGUgaWQ9Ik92YWwiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIGN4PSI3IiBjeT0iNyIgcj0iNyI+PC9jaXJjbGU+CiAgICAgICAgICAgICAgICA8cG9seWxpbmUgaWQ9IlBhdGgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHBvaW50cz0iNC40NTQ1NDU0NSAzLjE4MTgxODE4IDcgNyA5LjU0NTQ1NDU1IDciPjwvcG9seWxpbmU+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==');
      margin-left: 10px;
      cursor: pointer;
      &:hover {
        .hours-tooltip {
          display: block;
        }
      }
    }
  }
  .hours-tooltip {
    color: #2f3540;
    display: none;
    font-size: 11px;
    line-height: 13px;
    background: #fff;
    border: 1px solid #e2e2e7;
    padding: 10px;
    border-radius: 2px;
    position: absolute;
    top: 50%;
    margin-top: -38px;
    left: 50%;
    margin-left: -90px;
    z-index: 1;
    &::after, &::before {
      right: 100%;
      top: 50%;
      border: solid transparent;
      content: " ";
      height: 0;
      width: 0;
      position: absolute;
      pointer-events: none;
    }
    &::after {
      border-color: rgba(255, 255, 255, 0);
      border-right-color: #ffffff;
      border-width: 4px;
      margin-top: -54px;
    }
    &::before {
      border-color: rgba(226, 226, 231, 0);
      border-right-color: #E2E2E7;
      border-width: 5px;
      margin-top: -55px;
    }
    ul {
      list-style: none;
      margin: 0;
      padding: 0;
      li {
        margin-bottom: 3px;
      }
    }
    .day {
      font-weight: 600;
    }
  }
  @media (max-width: 991px) {
    .store-select-modal .store-block {
      .map-container {
        width: auto;
      }
    }
  }
</style>
