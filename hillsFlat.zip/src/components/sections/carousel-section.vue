<template>
  <section class="carousel-slider">
    <div class="container">
      <div v-if="slides" class="carousel-slider-wrapper">
        <swiper ref="carouselSlider" :options="carouselOptions">
          <swiper-slide
            v-for="(slide, index) in slides"
            :key="'carousel-' + index">
            <img :src="slide.image" class="img-fluid">
          </swiper-slide>
          <div slot="pagination" class="swiper-pagination" />
        </swiper>
        <div class="swiper-button-prev" slot="button-prev" @click="swiper.slidePrev()" />
        <div class="swiper-button-next" slot="button-next" @click="swiper.slideNext()" />
        </div>
      </div>
  </section>
</template>

<script>
export default {
  name: 'CarouselSection',
  data: () => ({
    carouselOptions: {
      loop: true,
      autoplay: { delay: 5000 },
      slidesPerView: 1,
      draggable: true,
      allowTouchMove: true,
      pagination: {
        el: '.swiper-pagination',
        clickable: true
      }
    }
  }),
  computed: {
    slides() {
      let carouselSection = this.$store.state.homepage.find(x => x.widget_type === '4');
      return carouselSection.data.images;
    },
    swiper() {
      return this.$refs.carouselSlider.swiper;
    },
  }
};
</script>

