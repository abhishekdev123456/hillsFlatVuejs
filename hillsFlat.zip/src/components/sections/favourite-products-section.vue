<template>
  <section>
    <div class="container">
      <div class="mb-0">
        <h4>Favorite Products</h4>
        <div class="position-relative">
          <swiper ref="productsSlider" :options="swiperOptions" class="products-slider">
            <swiper-slide
              v-for="(item, index) in favouriteProducts"
              :key="'favourite-products-' + index">
              <product-item :item="item" :internal-api="false"/>
            </swiper-slide>
          </swiper>
          <div class="swiper-button-prev product-swiper-prev" slot="button-prev" />
          <div class="swiper-button-next product-swiper-next" slot="button-next" />
        </div>
      </div>
    </div>
  </section>
</template>


<script>

import ProductApiService from '@/api-services/product.service';

export default {
  name: 'FacouriteProductsSection',
  props: ['type'],
  data: () => ({
    swiperOptions: {
      spaceBetween: 20,
      slidesPerView: 'auto',
      draggable: true,
      autoplay: { delay: 3500 },
      allowTouchMove: true,
      navigation: {
        nextEl: '.product-swiper-next',
        prevEl: '.product-swiper-prev'
      },
      breakpoints: {
        320: {
          centeredSlides: true,
          spaceBetween: 0,
        }
      }
    }
  }),
  computed: {
    options() {
      return this.$store.state.homepage.find(x => x.widget_type === this.type);
    },
    swiper() {
      return this.$refs.productsSlider.swiper;
    },
    favouriteProducts() {
      return this.$store.state.favouriteProducts;
    }
  },
  async mounted() {
    if (!this.favouriteProducts) {
      ProductApiService.getFavouriteProducts().then(response => {
        let allProducts = [];

        response.data.data.forEach(item => {
          item.competitors = null;
          item.similars = null;
          item.videos = null;

          allProducts.push(item);
        });

        this.$store.commit('addProductsRange', allProducts);
        this.$store.commit('setFavouriteProducts', allProducts);

        let allSKUs = [];
        allProducts.forEach(item => {
          allSKUs.push(item.sku);
        });

        if (allSKUs.length) {
          ProductApiService.getCompetitorsForSKUList(allSKUs).then(
            response => {
              this.$store.commit('setMultiCompetitors', response.data.data);
            }
          );
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
  .swiper-slide {
    width: auto !important;
    height: 340px;
     > .discounted-item {
       margin: 0 !important;
     }
  }
  .swiper-button-disabled {
    opacity: 0;
  }
  @media (max-width: 766px) {
    .products-slider.swiper-container {
      margin: 0 !important;
    }
  }
  @media (max-width: 400px) {
    .swiper-slide {
      width: 100% !important;
      > .card {
      width: 100% !important;
      }
    }
  }
</style>
