<template>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-6" v-if="false">
          <h5>Payment</h5>
          <div id="payment-methods">
            <a href="https://www.mastercard.us/en-us.html" target="_blank">
              <img src="/icons/mastercard.png" alt="Master Card" class="img-fluid">
            </a>
            <a href="https://visa.com" target="_blank">
              <img src="/icons/visa.png" alt="Visa" class="img-fluid">
            </a>
            <a href="https://paypal.com" target="_blank">
              <img src="/icons/paypal.png" alt="PayPal" class="img-fluid">
            </a>
            <a href="https://www.americanexpress.com" target="_blank" class="mr-0">
              <img src="/icons/express.png" alt="American Express" class="img-fluid">
            </a>
          </div>
          <div class="privacy-link">
            <router-link to="/terms">Terms and Policies</router-link>
          </div>
        </div>

        <div class="col-md-6 mt-4 mt-md-0" v-if="socialMedia">
          <h5>Connect</h5>
          <div id="social">
            <a :href="business.facebook_link" target="_blank" v-if="business.facebook_link">
              <img src="/icons/facebook.svg" alt="Facebook" class="img-fluid">
            </a>
            <a :href="business.twitter_link" target="_blank" v-if="business.twitter_link">
              <img src="/icons/twitter.svg" alt="Twitter" class="img-fluid">
            </a>
            <a :href="business.instagram_link" target="_blank" v-if="business.instagram_link">
              <img src="/icons/instagram.svg" alt="Instagram" class="img-fluid">
            </a>
            <a :href="business.youtube_link" target="_blank" class="mr-0" v-if="business.youtube_link">
              <img src="/icons/youtube.svg" alt="Youtube" class="img-fluid">
            </a>
          </div>
        </div>
      </div>
    </div>
    <hr>
    <div class="container">
      <p>All product and company names are trademarks™ or registered® trademarks of their respective holders. Use of
        them does not imply any affiliation with or endorsement by them.</p>
    </div>
  </footer>
</template>

<script>

export default {
  name: "mainFooter",
  props: ['business'],
  computed: {
    socialMedia() {
      return this.business.facebook_link || this.business.twitter_link || this.business.instagram_link || this.business.pinterest_link || this.business.youtube_link || this.business.linkedin_link;
    }
  }
};

</script>
