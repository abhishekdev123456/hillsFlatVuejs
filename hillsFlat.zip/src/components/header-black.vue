<template>
  <header class="d-none d-lg-block sticky-top" ref="mainHeader">
    <div class="container">
      <router-link to="/" class="brand text-white">
        <img class="brand-logo-image" src="/icons/logo.png" alt="Logo">
      </router-link>
      <div class="search">
        <vue-autosuggest
          ref="autocomplete"
          :suggestions="searchSuggestions"
          :inputProps="inputProps"
          :sectionConfigs="sectionConfigs"
          :renderSuggestion="renderSuggestion"
          :getSuggestionValue="getSuggestionValue"
        >
          <template slot="footer">
            <div class="search-suggestion-footer">
              None of the results match?
              <span class="search-link" @mouseup="toSearchPage">Click here</span>
            </div>
          </template>
        </vue-autosuggest>
        <button type="button" @click="toSearchPage" class="btn btn-primary btn-search-custom">Search</button>
      </div>
      <div id="logged-user" v-if="activeUser" v-click-outside="hideDropdown" @click="showDropDown = !showDropDown">
        <div class="btn">{{ activeUser.data.customer.first_name || 'Admin' }}</div>
        <template v-if="activeUser && activeUser.is_admin">
          <ul class="account-setting-dropdown" v-if="showDropDown">
            <li @click="hideDropdown">
              <router-link class="dropdown-item" to="/admin/orders">
                Orders
              </router-link>
            </li>
            <li @click="hideDropdown">
              <router-link class="dropdown-item" to="/admin/settings">
                  Settings
              </router-link>
            </li>
            <li @click="hideDropdown">
              <a href="#" class="dropdown-item mb-2 mr-4" @click="logout">
                Logout
              </a>
            </li>
          </ul>
        </template>
        <template v-else>
          <ul class="account-setting-dropdown" v-if="showDropDown">
            <li class="name">{{ userFullName }}</li>
            <li @click="hideDropdown">
              <router-link class="dropdown-item" to="/account">
                  Account Info
              </router-link>
            </li>
            <li @click="hideDropdown">
              <router-link class="dropdown-item" to="/orders">
                Orders
              </router-link>
            </li>
            <!-- <li @click="hideDropdown">
              <router-link class="dropdown-item" to="/payment">
                  Payment methods
              </router-link>
            </li> -->
            <li @click="hideDropdown">
              <a href="#" class="dropdown-item mb-2 mr-4" @click="logout">
                Logout
              </a>
            </li>
          </ul>
        </template>
      </div>
      <div v-else id="authorization">
        <router-link to="/login">Sign In</router-link>or<router-link to="/register">Sign Up</router-link>
      </div>

      <router-link v-if="activeUser && activeUser.is_admin" to="/admin" class="btn-view">Admin side</router-link>
      <router-link v-else to="/cart" class="btn btn-primary cart" :class="whileAdding?'adding':''">
        <img src="/icons/cart.svg" alt="Cart" class="mr-2">
        Cart
        <span v-if="cart" class="badge badge-pill badge-dark" :class="whileAdding?'badge-stroke':''">{{ cartAmount }}</span>
      </router-link>
    </div>
  </header>
</template>

<script>
import { debounce } from 'debounce';
import AuthApiService from '@/api-services/auth.service';
import AuthController from '@/controllers/auth.controller';


export default {
  name: "HeaderBlack",
  data() {
    return {
      searchKey: null,
      showDropDown: false,
      addSticky: false,
      inputProps: {
        id: 'autosuggest__input',
        onInputChange: this.getSuggestions,
        placeholder: 'Enter what you are looking for',
        class: 'form-control',
        name: 'searchKey'
      },
      sectionConfigs: {
        products: {
          limit: 10,
          label: 'Products',
          onSelected: selected => {
            this.searchKey = selected.item.title;
            this.$router.push({
              name: 'products-id',
              params: {
                id: selected.item.sku,
                title: selected.item.title.replace(/[ /]/g, '+')
              }
            });
          }
        },
        departments: {
          limit: 3,
          label: "Departments",
          onSelected: selected => {
            this.$router.push({
              name: 'department-products',
              params: {id: selected.item.dept_id, title: selected.item.name }
            });
          }
        },
        default: {
          onSelected: () => {
            this.toSearchPage();
          }
        }
      },
    };
  },
  created() {
    window.addEventListener('scroll', this.handleScroll);
  },
  destroyed() {
    window.removeEventListener('scroll', this.handleScroll);
  },
  computed: {
    cart() {
      return this.$store.state.cart;
    },
    headerOffsetTop() {
      return this.$refs.mainHeader.offsetTop;
    },
    cartAmount() {
      return this.$store.state.cartItemCount;
    },
    activeUser() {
      return this.$store.state.activeUser;
    },
    searchSuggestions() {
      if(this.$store.state.searchSuggestions) {
        let arr = this.$store.state.searchSuggestions;
        let temp = [];
        const products = arr.products && arr.products.items;
        const departments = arr.departments && arr.departments.items;
        products.length && temp.push({ name: 'products', data: products });
        departments.length && temp.push({ name: 'departments', data: departments });
        return temp;
      }
      else
        return [];
    },
    whileAdding() {
      return this.$store.state.addingToCart;
    },
    userFullName() {
      return this.activeUser.data.customer.first_name + ' ' + this.activeUser.data.customer.last_name;
    }
  },
  methods: {
    toSearchPage() {
      this.searchKey = this.searchKey || undefined;
      if (this.$route.name === "search") {
        // If user is on search page
        let query = Object.assign({}, this.$route.query, {keyword: this.searchKey});
        this.$router.push({ query: query });
      } else {
        // Otherwise
        this.$router.push({ name: "search", query: { keyword: this.searchKey }});
      }
    },

    getSuggestions(text) {
      this.searchKey = text;
      if(this.searchKey == '' || this.searchKey == undefined) return;
      this.$store.dispatch('searchSuggestion', this.searchKey);
    },

    renderSuggestion(suggestion) {
      const item = suggestion.item;
      if (suggestion.name == 'products') {
        return (
          <div>
            <img class={{ avatar: true }} src={ item.image_url } />
            { item.title }
          </div>
        );
      } else if (suggestion.name == 'departments') {
        if(item.parent) {
          return (
            <div style="font-size: 12px;">
              <span>{ item.name }</span>
              <span style="color: grey;"> in </span>
              <span style="color: grey; font-size: 11px;">{ item.parent.name }</span>
            </div>
          );
        } else
          return (
            <div style="font-size: 12px;">
              <span>{ item.name }</span>
            </div>
          );
      }
    },

    getSuggestionValue(suggestion) {
      let { name, item } = suggestion;
      return name == 'products' ? item.title : item.name;
    },

    hideDropdown() {
      this.showDropDown = false;
    },

    logout() {
      AuthApiService.logout()
      .then(res => {
        if (res.data.status == "success") {
          this.$swal({
            toast: true,
            position: 'top',
            showConfirmButton: false,
            timer: 3000,
            type: 'success',
            title: 'signed out'
          });
        } else {
          this.$swal(res.data.message, '', 'error');
        }
      })
      .catch(() => {
        this.$swal('Unknown error while logging out', '', 'error');
      });
      AuthController.logout();
      this.$store.dispatch('logout');
      this.$router.push({ name: 'index' });
    },

    handleScroll() {
      this.addSticky = window.pageYOffset > this.headerOffsetTop;
      this.addSticky = window.pageYOffset > 0;
    }
  },
  watch: {
    searchKey: debounce(function(newQuery) {
      this.getSuggestions(newQuery);
    }, 250)
  }
};
</script>

<style lang="scss" scoped>
  $primary: #ed6730;
  .sticky-header a {
    color: #fff;
  }
  .search-link {
    color: $primary;
    cursor: pointer;
    &:hover {
      color: rgb(100, 156, 77);
    }
  }

  .search-suggestion-footer {
    padding: 12px 18px;
    font-size: 14px;
    border-top: solid 1px rgb(211, 211, 211);
  }
  .cart {
    transition: all .2s;
    &.adding {
      transform: scale(1.05);
      transition: none;
      transition: all .1s;
      background: #f15313;
    }
  }

  #logged-user {
    position: relative;
    .btn {
      color: #fff;
      cursor: pointer;
      font-size: 14px;
      display: flex;
      align-items: center;
      &::before {
        content: '';
        background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTdweCIgaGVpZ2h0PSIxN3B4IiB2aWV3Qm94PSIwIDAgMTcgMTciIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8ZyBpZD0iU3ltYm9scyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICAgICAgICA8ZyBpZD0iR3JvdXAtNCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMS4wMDAwMDAsIDEuMDAwMDAwKSIgc3Ryb2tlPSIjRkZGRkZGIj4KICAgICAgICAgICAgPGNpcmNsZSBpZD0iT3ZhbCIgY3g9IjcuNSIgY3k9IjUuNSIgcj0iMi41Ij48L2NpcmNsZT4KICAgICAgICAgICAgPHBhdGggZD0iTTEyLjQ1MywxMy4xMjEgQzExLjU0MDM3ODMsMTEuMjE0MDcwOCA5LjYxNDA2MTg1LDEwLjAwMDQxNiA3LjUsMTAuMDAwNDE2IEM1LjM4NTkzODE1LDEwLjAwMDQxNiAzLjQ1OTYyMTc1LDExLjIxNDA3MDggMi41NDcsMTMuMTIxIiBpZD0iUGF0aCI+PC9wYXRoPgogICAgICAgICAgICA8Y2lyY2xlIGlkPSJPdmFsIiBjeD0iNy41IiBjeT0iNy41IiByPSI3LjUiPjwvY2lyY2xlPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+');
        width: 17px;
        height: 17px;
        margin-left: 7px;
        margin-right: 10px;
      }
      &::after {
        content: '';
        background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSI2cHgiIHZpZXdCb3g9IjAgMCAxMCA2IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPGcgaWQ9IlN5bWJvbHMiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+CiAgICAgICAgPGcgaWQ9Ik5hdmlnYXRpb24tTGFiZWwtLy1XaGl0ZS0tLUxvZ2dlZCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTExMDkuMDAwMDAwLCAtNDEuMDAwMDAwKSIgc3Ryb2tlPSIjRkZGRkZGIiBzdHJva2Utd2lkdGg9IjEuNSI+CiAgICAgICAgICAgIDxnIGlkPSJOYXZpZ2F0aW9uLUxhYmVsIj4KICAgICAgICAgICAgICAgIDxnIGlkPSJHcm91cC01IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg5NjcuMDAwMDAwLCAzNS4wMDAwMDApIj4KICAgICAgICAgICAgICAgICAgICA8ZyBpZD0iR3JvdXAtMiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjMuNTAwMDAwLCAwLjAwMDAwMCkiPgogICAgICAgICAgICAgICAgICAgICAgICA8cG9seWxpbmUgaWQ9IlBhdGgiIHBvaW50cz0iMTIwIDcgMTIzLjUgMTEgMTI3IDciPjwvcG9seWxpbmU+CiAgICAgICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8L2c+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4=');
        width: 10px;
        height: 6px;
        margin-left: 7px;
      }
    }
    .account-setting-dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      z-index: 1000;
      min-width: 10rem;
      padding: 0.5rem 0;
      margin-top: .125rem;
      list-style: none;
      background-color: #fff;
      background-clip: padding-box;
      border: 1px solid rgba(0, 0, 0, 0.15);
      border-radius: 0.25rem;
      color: #000;
      .dropdown-item {
        font-size: 14px;
        padding: .5rem 1rem;
        color: #212529;
        &:hover {
          background: $primary;
          color: #fff !important;
        }
      }
      .name {
        padding: 5px 15px;
        font-size: 14px;
        font-weight: bold;
        text-transform: capitalize;
      }
    }

  }

  .dropdown-item {
    cursor: pointer;
    padding: 10px;
    color: $primary;
    &:hover {
      background-color: rgb(31, 137, 208);
      color: $primary;
    }
    > a {
      text-decoration: none;
      color: $primary;
    }
  }

  .slide-enter-active,
  .slide-leave-active,
  .slide-move {
    transition: 1s cubic-bezier(0, 1, 0.5, 1);
    transition-property: opacity, transform;
  }

  .slide-enter {
    opacity: 0;
    transform: scaleY(0);
  }

  .slide-enter-to {
    opacity: 1;
    transform: scaleY(1);
    transform-origin: center top;
  }

  .slide-leave-to {
    opacity: 0;
    transform: scaleY(0.8);
    transform-origin: center top;
  }

  .btn-search-custom {
    border-radius: 0 0.25rem 0.25rem 0;
    padding: 0 15px 0 15px !important;
  }


  .btn-view {
    border-radius: 5px;
    background: #fff;
    color: #6F747B !important;
    font-size: 12px;
    align-items: center;
    min-width: 130px;
    display: flex;
    height: 40px;
    justify-content: center;
    padding: 0 8px;

    &:hover {
      color: #333 !important;
      text-decoration: none !important;
    }
  }
</style>

