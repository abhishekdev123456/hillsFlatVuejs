<template>
  <div class="coupon-t3">
    <div class="background" :style="{ backgroundColor: options.background_color }">
      <div class="row justify-content-between">
        <h2>{{ options.coupon_title }}</h2>
        <div>
          <button class="btn btn-white">
            {{ options.button_title }}
          </button>
        </div>
      </div>
      <div class="row">
        <h5>{{ options.highlighted_text }}</h5>
        <br>
        <h6>{{ options.disclaimer }}</h6>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CouponType3',
  props: {
    options: {
      type: Object,
      default: null
    }
  }
};
</script>
