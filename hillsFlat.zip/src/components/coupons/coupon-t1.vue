<template>
  <div class="coupon-t1">
    <div class="row">
      <div class="col-6">
        <img :src="options.background_image" :style="{ backgroundColor: options.background_color }">
        <button class="btn btn-white">
          {{ options.button_title }}
        </button>
      </div>
      <div class="col-6">
        <div class="background">
          <div class="info">
            <h2>{{ options.coupon_title }}</h2>
            <h6>{{ options.highlighted_text }}</h6>
            <span>{{ options.disclaimer }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CouponType1',
  props: {
    options: {
      type: Object,
      default: null
    }
  }
};
</script>
