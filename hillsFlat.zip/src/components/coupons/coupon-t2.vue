<template>
  <div class="coupon-t2">
    <img :src="options.background_image">
    <div class="info">
      <h5>{{ options.coupon_title }}</h5>
      <button class="btn btn-white">
        {{ options.button_title }}
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CouponType2',
  props: {
    options: {
      type: Object,
      default: null
    }
  }
};
</script>
