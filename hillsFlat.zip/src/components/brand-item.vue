<template>
  <div class="brand-item">
    <div class="image-wrapper">
      <img :src="brand.image">
    </div>
    <h5>{{ brand.brand_name }}</h5>
    <table class="info">
      <tr>
        <td>
          <h4>{{ brand.products_count }}</h4>
          <span>Products</span>
        </td>
        <td>
          <h4>{{ brand.videos_count }}</h4>
          <span>Videos</span>
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
export default {
  name: 'BrandItem',
  props: {
    brand: {
      type: Object,
      default: null
    }
  }
};
</script>