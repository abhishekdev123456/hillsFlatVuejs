<template>
  <div class="change-quantity">
    <button type="button" class="btn-qty btn btn-primary" :disabled="quantity === 0" @click="updateQty(quantity - 1)">-</button>
    <input v-model="quantity" type="text" class="form-control" min="0" disabled>
    <button type="button" class="btn-qty btn btn-primary" :disabled="!canAddMore" @click="updateQty(quantity + 1)">+</button>
  </div>
</template>

<script>
import CartApiService from '@/api-services/cart.service';

export default {
  name: 'ChangeQuantity',
  props: {
    qty: {
      type: Number,
      default: 0
    },
    cartItem: {
      type: Object,
      default: null
    },
    max: {
      type: Number,
      default: 0
    },
    limit: {
      type: Number,
      default: 1
    },
    // the number in the UI can NEVER go above this
    uiLimit: {
      type: Number,
      default: -1
    },
    special: {
      type: Boolean,
      default: false
    },
    // determines if it's modified from pickup parcel (0), special (1), or from all (-1)
    specialModify: {
      type: Number,
      default: -1
    },
  },
  data() {
    return {
      quantity: this.qty
    };
  },
  computed: {
    businessDetails() {
      return this.$store.state.businessDetails;
    },
    outOfStock() {
      return parseInt(this.cartItem.num_inventory) <= 0
          && (!this.businessDetails.show_oos_special || !this.cartItem.vendor_id);
    },
    canAddMore() {
      if ( this.quantity < this.cartItem.num_inventory ) {
        return true;
      }
      // if we are showing out of stock as special order and we have a vendor id, let them add
      return !!(this.businessDetails.show_oos_special && this.cartItem.vendor_id);
    }
  },
  methods: {
    updateQty(value) {
      this.quantity = value;
      // still allow value to be sent, but limit the number in the UI
      if ( this.uiLimit >= 0 ) {
        this.quantity = Math.min(this.uiLimit, this.quantity);
      }

      if (value === 0) {
        this.$store.state.addingToCart = true;
        CartApiService.removeItem(this.cartItem.store_product_id  || this.cartItem.id, this.specialModify)
        .then(() => {
          this.$store.dispatch("fetchCartItemsDetails");
          this.$store.state.addingToCart = false;
        });
      } else {
        this.$store.state.addingToCart = true;
        CartApiService.addItem(this.cartItem.store_product_id || this.cartItem.id, this.quantity, this.specialModify)
        .then(res => {
          if (res.status === 200) {
            this.$store.dispatch("fetchCartItemsDetails");
          } else {
            this.$swal(res.data.message, '', 'error');
          }
          this.$store.state.addingToCart = false;
        })
        .catch(err => {
          console.log(err);
          this.$swal(err.response.message, '', 'error');
        });
      }
    }
  },
  watch: {
    qty: function (val) {
      this.quantity = val;
    }
  }
};
</script>

