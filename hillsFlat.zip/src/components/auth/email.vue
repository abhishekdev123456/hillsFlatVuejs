<template>
  <div>
    <div class="form-group">
      <label for="email">Email Address Entered</label>
      <input
        id="email"
        type="email"
        :value="email"
        @input="$emit('update:email', $event.target.value)"
        class="form-control">
    </div>
    <div class="form-group">
      <label for="password">
        Password
        <router-link to="/forgot-password" class="text-dark float-right">
          Forgot your password?
        </router-link>
      </label>
      <input
        id="password"
        type="password"
        :value="password"
        @input="$emit('update:password', $event.target.value)"
        class="form-control"
        placeholder="Enter your password">
    </div>
  </div>
</template>

<script>
export default {
  name: 'AuthWithEmail',
  props: {
    email: {
      type: String,
      required: true
    },
    password: {
      type: String,
      required: true
    }
  }
};
</script>

<style lang="scss" scoped>
@import '@/assets/scss/auth.scss';
</style>
