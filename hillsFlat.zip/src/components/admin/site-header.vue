<template>
  <div>
    <section class="header-bar">
      <div class="container">
        <div class="row mobile-row">
          <div class=" top-bar col-md-3 col-sm-12 col-xs-12">
            <img src="/images/logo_hard.png"/>
            <a href="#/cart" class=" ml-2 btn btn-primary cart"><img src="/icons/cart.svg" alt="Cart" class="mr-2">
              <span class="badge badge-pill badge-dark">0</span></a>
          </div>
          <div class="col-md-5 col-sm-12 col-xs-12 text-xs-right">
            <div class="search-bar">
              <b-form-input size="sm" class="mr-sm-2" placeholder="Search"></b-form-input>
              <span><img src="/icons/search.svg"/></span>
            </div>
          </div>
          <div class="mobile-hide text-right col-md-4 col-xs-12 pr-0">
            <div class="cart">
              <span class="mr-2">Welcome <strong>{{ activeUser.data.customer.business_username }}</strong></span>
              <img src="/icons/gear.png" @click="showDropDown = !showDropDown"/>

              <transition name="slide">
                <div class="account-setting-dropdown" v-if="showDropDown">
                  <li @click="showDropDown = false">
                    <div class="dropdown-item mb-2 mr-4" @click="logout">
                      Logout
                    </div>
                  </li>
                </div>
              </transition>

              <a href="#/cart" class="ml-2 btn btn-primary cart cart-badge">
                <img src="/icons/cart.svg" alt="Cart" class="mr-2">Cart
                <span class="badge badge-pill badge-dark">0</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="menu-item-nav">
      <div class="container">
        <div class="row">
          <b-navbar toggleable="lg" type="dark">
            <b-navbar-brand class="d-xs-none d-sm-none d-block" href="#"><img src="/images/logo_hard.png"/>
            </b-navbar-brand>

            <b-navbar-toggle target="visitor-site-menu"></b-navbar-toggle>

            <b-collapse id="visitor-site-menu" is-nav>
              <b-navbar-nav>
                <b-nav-item href="#">Home</b-nav-item>
                <b-nav-item href="#">Departments</b-nav-item>
                <b-nav-item href="#">Brands</b-nav-item>
              </b-navbar-nav>

              <!-- Right aligned nav items -->
              <b-navbar-nav class="link">
                <b-nav-item href="#"><img src="/images/telephone.png"/> (530) 273-6171</b-nav-item>
                <b-nav-item href="#"><img src="/images/time-clock.png"/> Store Hours & Info</b-nav-item>
              </b-navbar-nav>
            </b-collapse>
          </b-navbar>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
  import AuthApiService from '@/api-services/auth.service';
  import AuthController from '@/controllers/auth.controller';

  export default {
    name: 'AdminSiteHeader',
    data() {
      return {
        showDropDown: false
      };
    },
    computed: {
      activeUser() {
        return this.$store.state.activeUser;
      },
    },
    methods: {
      logout() {
        AuthApiService.logout()
        .then(res => {
          if (res.data.status == "success") {
            this.$swal({
              toast: true,
              position: 'top',
              showConfirmButton: false,
              timer: 3000,
              type: 'success',
              title: 'signed out'
            });
          } else {
            this.$swal(res.data.message, '', 'error');
          }
        })
        .catch(err => {
          console.log(err);
          this.$swal('Unknown error while loggin out', '', 'error');
        });
        AuthController.logout();
        this.$store.dispatch('logout');
        this.$router.push({name: 'index'});
      },
    }
  };
</script>

<style lang="scss" scoped>

  .search-bar {
    input {
      position: relative;
    }

    span {
      position: absolute;
      top: 7px;
      right: 25px;

    }
  }

  .header-bar {
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;

      a {
        display: none;
      }
    }

    .mobile-hide {
      display: block;

      .cart {
        color: #2F3540;
        font-size: 14px;

        b {
          margin-left: 3px;
          color: #2F3540;
        }

        .cart-badge {
          .badge {
            background: #36813E;
            line-height: 16px;
            padding: 2px 7px;
          }
        }
      }
    }
  }

  .menu-item-nav {
    border-top: 1px solid #EAEAEB;
    border-bottom: 1px solid #EAEAEB;
    padding: 0 !important;

    .navbar {
      width: 100%;
      border-bottom: none !important;

      .navbar-collapse {
        ul {
          li {
            a {
              border: 2px solid transparent;

              &:hover {
                border-bottom: 2px solid #ed6730;
              }
            }
          }
        }

        .link {
          li {
            a {
              color: #ed6730;
              text-transform: capitalize;

              &:hover {
                border-bottom: none;
              }
            }
          }
        }
      }

      #visitor-site-menu {
        width: 100%;
        justify-content: space-between;
      }
    }

  }

  @media (max-width: 991px) {
    .menu-item-nav {
      background: #2f3540;
      position: relative;
      height: 50px;

      .navbar {
        width: 100% !important;
        padding: 0px 15px;
        background: #2f3540;
        position: relative;
        z-index: 9999;

        .navbar-toggler {
          position: absolute;
          top: 5px;
          right: 15px;

        }
      }
    }
    .header-bar {
      .mobile-row {
        display: flex;
        justify-content: space-between;
        align-items: center;

        .top-bar {
          .btn {
            display: flex;
          }
        }
      }

      .top-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;

        a {
          display: block;
        }

        .cart {
          .badge {
            background: #36813E;
          }
        }
      }

      .mobile-hide {
        display: none;
      }
    }
  }

</style>
