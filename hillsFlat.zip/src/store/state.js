export default {
  business_slug: 'G6Z9cAQv4qtm2300',
  businessInfo: null,
  stripe_publishable: 'pk_test_SoQebsTMOLR2iExxLINSedwP',
  device_id: null,
  activeUser: null,
  products: [],
  popularProducts: null,
  favouriteProducts: null,
  cart: [],
  cartItemCount: 0,
  coupons: [],
  banner: null,
  homepage: null,
  searchSuggestions: null,
  searchResults: null,
  addingToCart: false,
  departmentResults: null,
  brands: null,
  preferences: {},
  businessDetails: {},
  storeLocations: [
  //   {
  //     "location": "588-9610 Mattis. Av.",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "2128 Nascetur Rd.",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "247-5841 Pellentesque Rd.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "4782 Interdum. Rd.",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "Ap #234-1361 Dis Avenue",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "2706 Ultrices Av.",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "P.O. Box 743, 9264 Ullamcorper, Street",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "P.O. Box 885, 5026 Tortor Avenue",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "Ap #659-9783 Aliquam St.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "856-603 Pellentesque Rd.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "P.O. Box 101, 6368 Dui St.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "Ap #943-6173 Mauris St.",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "2984 Mi Ave",
  //     "distance": "6"
  //   },
  //   {
  //     "location": "Ap #775-3898 Mollis Av.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "5037 Id, Street",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "632-8056 Id St.",
  //     "distance": "12"
  //   },
  //   {
  //     "location": "445-919 Posuere St.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "644-6856 Risus. Street",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "Ap #412-7132 Donec Ave",
  //     "distance": "7"
  //   },
  //   {
  //     "location": "Ap #366-696 Ornare, Road",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "279-2905 Ridiculus Ave",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "P.O. Box 637, 4453 Vel Rd.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "649-1629 Metus Rd.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "3907 Lectus Avenue",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "Ap #294-995 Ac St.",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "983-3036 Mauris Av.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "Ap #331-5520 Ac St.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "P.O. Box 733, 9147 In Rd.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "P.O. Box 771, 1508 Nec, Av.",
  //     "distance": "7"
  //   },
  //   {
  //     "location": "840-8034 Vehicula Rd.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "Ap #762-2149 Quisque Road",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "935 Eu Road",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "920-6661 Sociosqu Rd.",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "Ap #557-6586 Mauris Rd.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "4914 Placerat. St.",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "P.O. Box 404, 526 Magna St.",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "Ap #804-2405 Sollicitudin Road",
  //     "distance": "12"
  //   },
  //   {
  //     "location": "567-1718 Netus Rd.",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "8455 Eu, Street",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "388-9630 Sociis St.",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "Ap #399-6133 Non St.",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "771-2335 Proin Road",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "P.O. Box 284, 1688 Arcu. Rd.",
  //     "distance": "12"
  //   },
  //   {
  //     "location": "Ap #622-7952 Cras St.",
  //     "distance": "5"
  //   },
  //   {
  //     "location": "P.O. Box 346, 2306 Quisque Road",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "P.O. Box 345, 8768 Sit Street",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "Ap #517-6446 Ultrices Av.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "Ap #851-3495 Mauris. Rd.",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "3765 Est. St.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "P.O. Box 372, 3998 Ridiculus Rd.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "4600 Mauris Rd.",
  //     "distance": "12"
  //   },
  //   {
  //     "location": "Ap #872-9559 Nam St.",
  //     "distance": "12"
  //   },
  //   {
  //     "location": "7556 Auctor Road",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "Ap #806-9402 Aenean Road",
  //     "distance": "16"
  //   },
  //   {
  //     "location": "P.O. Box 616, 3818 Risus. St.",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "Ap #783-7189 Tristique Road",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "6765 Metus Avenue",
  //     "distance": "12"
  //   },
  //   {
  //     "location": "Ap #700-2693 Ante St.",
  //     "distance": "5"
  //   },
  //   {
  //     "location": "Ap #982-5996 Sem Avenue",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "P.O. Box 954, 7771 Dictum Street",
  //     "distance": "12"
  //   },
  //   {
  //     "location": "209-1130 Nulla Rd.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "618-6823 Sagittis. Avenue",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "P.O. Box 260, 8519 Morbi Road",
  //     "distance": "4"
  //   },
  //   {
  //     "location": "798-9424 Eleifend, Av.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "139-5139 Ultricies Avenue",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "P.O. Box 226, 5672 Mi Rd.",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "Ap #358-9499 Fringilla Av.",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "P.O. Box 490, 4339 Pellentesque Street",
  //     "distance": "7"
  //   },
  //   {
  //     "location": "P.O. Box 548, 727 Pretium Avenue",
  //     "distance": "7"
  //   },
  //   {
  //     "location": "Ap #716-5447 Mauris. Rd.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "P.O. Box 422, 2698 Euismod St.",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "166-8196 Egestas Road",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "P.O. Box 128, 2497 Vivamus St.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "P.O. Box 616, 5796 Non Street",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "4271 Est. Avenue",
  //     "distance": "12"
  //   },
  //   {
  //     "location": "Ap #506-4635 Nascetur Road",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "167-2613 Sed, St.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "291-4488 Et Road",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "Ap #663-8275 Ultricies St.",
  //     "distance": "15"
  //   },
  //   {
  //     "location": "Ap #463-4403 Vehicula Rd.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "P.O. Box 996, 6294 Aliquet Street",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "Ap #465-8100 Metus. Avenue",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "P.O. Box 192, 8251 Consequat Av.",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "Ap #304-1674 A, Street",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "Ap #466-2236 Proin Road",
  //     "distance": "13"
  //   },
  //   {
  //     "location": "Ap #842-3111 Magna. Rd.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "Ap #436-2693 Congue. Rd.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "8053 Mauris Rd.",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "712-6335 Tortor. St.",
  //     "distance": "14"
  //   },
  //   {
  //     "location": "Ap #541-5745 In Ave",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "Ap #534-1722 Metus. Rd.",
  //     "distance": "12"
  //   },
  //   {
  //     "location": "Ap #689-3554 Sed St.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "P.O. Box 819, 4116 Fringilla. Avenue",
  //     "distance": "11"
  //   },
  //   {
  //     "location": "442-4199 Dis Street",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "P.O. Box 779, 7682 Facilisis Av.",
  //     "distance": "10"
  //   },
  //   {
  //     "location": "P.O. Box 400, 5165 Aenean Rd.",
  //     "distance": "9"
  //   },
  //   {
  //     "location": "P.O. Box 229, 2339 Odio Ave",
  //     "distance": "8"
  //   },
  //   {
  //     "location": "Ap #483-8937 Eget St.",
  //     "distance": "6"
  //   },
  //   {
  //     "location": "Ap #795-9137 Montes, Avenue",
  //     "distance": "12"
  //   },
  //   {
  //     "location": "4490 Metus Rd.",
  //     "distance": "10"
  //   }
  ]
};
