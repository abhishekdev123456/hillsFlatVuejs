function refreshCartItemCount(state) {
  const cartItems = state.cart.parcels;
  let count = 0;
  if (cartItems && cartItems.length) {
      const pickupItems = cartItems.find(item => {
          return item.type === 'pickup';
      });
      const specialParcels = cartItems.filter(item => {
        return item.type === 'special';
      });
      let specialItems = [];
      if (specialParcels && specialParcels.length) {
        specialParcels.forEach(parcel => {
          if (parcel.items && parcel.items.length) {
            specialItems = [...specialItems, ...parcel.items];
          }
        });
      }
      let items = [];
      if (specialItems && specialItems.length) {
        items = [...items, ...specialItems];
      }
      if (pickupItems && pickupItems.items) {
        items = [...items, ...pickupItems.items];
      }
      items.forEach(item => {
        count += item.quantity;
      });
  }
  state.cartItemCount = count;
}

export default {
  setPopularProducts(state, value) {
    state.popularProducts = value;
  },
  setFavouriteProducts(state, value) {
    state.favouriteProducts = value;
  },
  addProduct(state, item) {
    let found = state.products.find(x => x.id === item.id);

    if (!found) {
      state.products.push(item);
    }
  },
  addCartItem(state, value) {
    state.cart.push(value);
    refreshCartItemCount(state);
  },
  setCompetitors(state, { productId, data }) {
    let product = state.products.find(item => item.id === productId);

    product.competitors = data;
  },
  setSimilarProducts(state, { productId, data }) {
    let product = state.products.find(item => item.id === productId);

    product.similars = data;
  },
  setMultiCompetitors(state, competitorsList) {
    for (let sku in competitorsList) {
      let competitors = competitorsList[sku];
      let product = state.products.find(item => item.sku === sku);
      if(product)
        product.competitors = competitors;
    }
  },
  addProductsRange(state, products) {
    products.forEach((item) => {
      let found = state.products.find(x => x.id === item.id);

      if (!found) {
        state.products.push(item);
      }
    });
  },
  setProductVideos(state, { productId, data }) {
    let product = state.products.find(item => item.id === productId);

    product.videos = data;
  },
  removeCartItem(state, productId) {
    let index = state.cart.findIndex(item => item.id === productId);

    state.cart.splice(index, 1);
    refreshCartItemCount(state);
  },
  updateQty(state, { item, value }) {
    let product = state.cart.find(x => x.id === item.id);

    if (!product) {
      item.quantity = value;
      state.cart.push(item);
    } else {
      product.quantity = value;
    }
    refreshCartItemCount(state);
  },
  setCartItems(state, value) {
    state.cart = value;
    refreshCartItemCount(state);
  },
  setBusinessInfo(state, value) {
    state.businessInfo = value;
  },
  setBanner(state, value) {
    state.banner = value;
  },
  setHomepageSection(state, value) {
    state.homepage = value;
  },
  setBusinessDetails(state, value) {
    state.businessDetails = value;

    // Some values Hardcoded (idk the usage of these three)
  },
  setCoupons(state, value) {
    state.coupons = value;
  },
  setActiveUser(state, activeUser) {
    state.activeUser = activeUser;
  },
  setDeviceId(state, id) {
    state.device_id = id;
  },
  saveSearchSuggestions(state, data) {
    state.searchSuggestions = data;
  },
  saveSearchResults(state, data) {
    state.searchResults = data;
  },
  saveFilterSearchResults(state, data) {
    if(state.searchResults) {
      state.searchResults.products = null;
      state.searchResults.products = data.products;
    }
  },
  saveDepartments(state, data) {
    for(let key of Object.keys(data.parent_departments)) {
      let formattedName = data.parent_departments[key].name.charAt(0) + data.parent_departments[key].name.toLowerCase().slice(1);
      data.parent_departments[key].name = formattedName;
    }
    state.departmentResults = data;
  },
  saveBrands(state, data) {
    state.brands = data;
  }
};
