import CartApiService from '@/api-services/cart.service';
import BannerApiService from '@/api-services/banner.service';
import SearchApiService from '@/api-services/search.service';
import ProductApiService from '@/api-services/product.service';
import HomePageApiService from '@/api-services/homepage.service';

export default {
  fetchBanner({ commit }) {
    BannerApiService.getBanner().then((res) => {
      commit('setBanner', res.data.data);
    });
  },

  fetchCartItemsDetails({ state, commit }) {
    const activeUser = state.activeUser;
    if (activeUser && activeUser.is_admin) {
      return;
    }
    CartApiService.cartDetails().then((res) => {
      commit('setCartItems', res.data.data);
    });
  },

  fetchBusinessInfo({ commit}) {
    HomePageApiService.getBusinessDetails().then(res => {
      const business = res.data.data;
      commit('setBusinessInfo', business.about_us);
    });
  },

  searchSuggestion(context, key) {
    SearchApiService.searchSuggestions(key).then((res) => {
      context.commit('saveSearchSuggestions', res.data.data);
    });
  },

  search(context, params) {
    return SearchApiService.searchResults(params).then((res) => {
      let products = res.data.data;
      let allSkus = [];
      products.data.forEach((product) => {
        product.competitors = null;
        allSkus.push(product.sku);
      });
      //context.commit('saveFilterSearchResults', {
      context.commit('saveSearchResults', {
        products: products,
        departments_hierarchy: res.data.departments_hierarchy,
        departments: res.data.departments,
        brands: res.data.brands,
        priceRanges: res.data.price_ranges
      });
      context.dispatch('getCompetitorsForSearch', allSkus);
    });
  },

  clearSearch(context) {
    context.state.searchResults = null;
  },

  getCompetitorsForSearch(context, allSkus) {
    if (allSkus.length == 0) {
      return;
    }
    let competitorsList = [];
    let products = context.state.searchResults.products;
    ProductApiService.getCompetitorsForSKUList(allSkus)
      .then(res => {
        competitorsList = res.data.data;
        for (let sku in competitorsList) {
          let competitors = competitorsList[sku];
          let product = products.data.find(item => item.sku === sku);
          if(product)
            product.competitors = competitors;
        }
      });
  },

  logout(context) {
    context.state.activeUser = null;
  },

  setPreferences(context) {
    HomePageApiService.getPreferences()
      .then(data => {
        context.state.preferences = data;
      });
  },

  storeLocations(context, stores) {
    context.state.storeLocations = stores;
  },

};
