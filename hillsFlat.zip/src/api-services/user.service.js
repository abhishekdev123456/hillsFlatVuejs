import Axios from 'axios';

const ENDPOINTS = {
  REGISTER: 'signup',
  VERIFY: 'verify-password',
  SAVESTORE: 'save-customer-stores',
  GET_DETAILS: 'get-customer-details',
  SAVE_NAME: 'customer/name',
  SAVE_EMAIL: 'customer/email',
  CHANGE_PASSWORD: 'customer/password'
};

export default {
  register(data) {
    return Axios.post(ENDPOINTS.REGISTER, data);
  },
  verifyPassword(data) {
    data.access_token = sessionStorage.getItem('token');
    return Axios.post(ENDPOINTS.VERIFY, data);
  },
  saveStore(data) {
    data.access_token = sessionStorage.getItem('token');
    return Axios.post(ENDPOINTS.SAVESTORE, data);
  },
  getDetails() {
    const token = sessionStorage.getItem('token');
    return Axios.get(ENDPOINTS.GET_DETAILS + '?access_token=' + token);
  },
  saveName(data) {
    const token = sessionStorage.getItem('token');
    return Axios.post(ENDPOINTS.SAVE_NAME + '?access_token=' + token, data);
  },
  saveEmail(data) {
    const token = sessionStorage.getItem('token');
    return Axios.post(ENDPOINTS.SAVE_EMAIL + '?access_token=' + token, data);
  },
  changePassword(data) {
    const token = sessionStorage.getItem('token');
    return Axios.post(ENDPOINTS.CHANGE_PASSWORD + '?access_token=' + token, data);
  }
};
