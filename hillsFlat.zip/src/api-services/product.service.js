import Axios from 'axios';

const PREFIX = '/products';
const ENDPOINTS = {
  SINGLE: 'product',
  COMPETITORS: 'competitors',
  SIMILARS: 'addons',
  MULTI_COMPETITORS: 'multi-competitors',
  POPULAR_PRODUCTS: 'popular-products',
  VIDEOS: 'videos',
  FAVOURITE: 'favourite-products'
};

export default {
  getProduct(param) {
    return Axios.get(`${PREFIX}/${ENDPOINTS.SINGLE}?param=${param}`);
  },
  searchProducts(keyword) {
    return Axios.get(`${PREFIX}?search=${keyword}`);
  },
  getCompetitors(identificator) {
    return Axios.get(`${PREFIX}/${identificator}/${ENDPOINTS.COMPETITORS}`);
  },
  getCompetitorsForSKUList(skuList) {
    let data = { param: skuList };

    return Axios.post(ENDPOINTS.MULTI_COMPETITORS, data);
  },
  getSimiliarProducts(identificator) {
    return Axios.get(`${PREFIX}/${identificator}/${ENDPOINTS.SIMILARS}`);
  },
  getPopularProducts() {
    return Axios.get(`${ENDPOINTS.POPULAR_PRODUCTS}?date=2019-02-04`); // delete this, temporaly (API not working properly)
  },
  getVideos(identificator) {
    return Axios.get(`${PREFIX}/${identificator}/${ENDPOINTS.VIDEOS}`);
  },
  getFavouriteProducts() {
    return Axios.get(`${ENDPOINTS.FAVOURITE}`);
  }
};
