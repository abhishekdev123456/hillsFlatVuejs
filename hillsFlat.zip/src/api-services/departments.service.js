import Axios from 'axios';

const ENDPOINTS = {
  MAIN: '/departments',
};

const pages = {
    car_hartt: {
      "brands_bottom": [
        {
          "image": "Carhartt-Logo-Small.jpg",
          "title": "Nevada City Outdoor Recreation, Carhartt Logo Image"
        },
      ],
      "bannerImage": {
        "image": "Carhartt_header_image-3pix.jpg",
        "title": "Nevada City Outdoor Recreation, Carhartt Clothing Header Image"
      },
      "description": "<div class=\"textDiv\">\n" +
        "  <h2>\n" +
        "    Nevada County's Largest Carhartt Stocking Dealer\n" +
        "  </h2>Designed for the perfect combination of comfort and durability,<strong class=\"seo\">&nbsp;</strong>Carhartt&nbsp;manufactures premium fabrics using their own textile mills for the utmost quality control. Functional fit and unsurpassed construction meet advanced technology for the warmest and driest garments, presented with&nbsp;Carhartt's&nbsp;classic style.&nbsp; <p>\n" +
        "    &nbsp;\n" +
        "  </p><ul>\n" +
        "    <li>\n" +
        "      Hills Flat Lumber carries popular pant sizes in 30 throuh 58 waist\n" +
        "    </li><li>\n" +
        "      We can handle your Carhartt special orders no problem\n" +
        "    </li><li>\n" +
        "      We carry Carhartt in women's, men's, and children's\n" +
        "    </li><li>\n" +
        "      Including Carhartt accessories, belts, wallets, socks, etc.\n" +
        "    </li><li>\n" +
        "      We stock all shirt sizes up to 4x\n" +
        "    </li><li>\n" +
        "      And jacket sizes up to 3x\n" +
        "    </li>\n" +
        "  </ul><p>\n" +
        "    &nbsp;\n" +
        "  </p>\n" +
        "</div>"
    },
    hand_tools : {
      "brands_bottom": [
        {
          "image": "Stanley-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Do-It-Best-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Lenox-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Irwin-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Crescent-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Johnson-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Vaughn-Logo-Small.jpg",
          "title": ""
        },
      ],
      "bannerImage": {
        "image": "Handtools-Header-Photo.webp",
        "title": ""
      },
      "description": "<div class=\"textDiv\">\n" +
        "    <h1>\n" +
        "     Hand Tools At Hills Flat Lumber \n" +
        "    </h1>\n" +
        "     <h3>\n" +
        "      Hand Tools\n" +
        "    </h3>\n" +
        "    <span>At Hills Flat Lumber, our selection of handtools is almost limitless. From US made tools, to imports, you’ll find something for every project and every price range.</span>\n" +
        "    <p>Come check out or wide selection of: Hammers, screwdrivers, saws, shovels, concrete tools, clamps, drills, hole saws, sawsall blades, wrenches, chisels, and tool bags. You name it, we have it!</p>\n" +
        "     <h3>\n" +
        "      Levels\n" +
        "    </h3>\n" +
        "    <span> At Hills Flat, we stock a wide range of quality levels to make your building project as straight as our quality lumber.</span>\n" +
        "    <p>One of the choices we offer are Stabila levels. Contractors buy Stabila because their levels enable them to make fast and accurate installations. Our Stabila levels are the most accurate, durable and reliable levels in the construction industry, and they are guaranteed for life.</p>\n" +
        "    <p>We offer many options in levels, including: Metal levels, electronic levels, laser levels, rotary levels, and many other measuring tools.</p>\n" +
        "  </div>"
    },
    power_tools : {
      "brands_bottom": [
        {
          "image": "Makita-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "DeWalt-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Senco-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Porter-Cable-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Bosch-Header-Logo1-e1424283604398.jpg",
          "title": ""
        },
        {
          "image": "Black-Decker-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Skil-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Rockwell-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Bostitch-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Campbell-Hausfeld-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Hitachi-Logo-Small.jpg",
          "title": ""
        },
      ],
      "bannerImage": {
        "image": "Power-Tools2_header_image-3pix.webp",
        "title": ""
      },
      "description": "<div class=\"textDiv\">\n" +
        "    <h1>\n" +
        "    Power Tools At Hills Flat Lumber \n" +
        "    </h1>\n" +
        "     <h3>\n" +
        "      Pneumatic Tools\n" +
        "    </h3>\n" +
        "    <span>At Hills Flat Lumber, we offer a wonderful selection of pneumatic tools. Senco makes a wide variety of pneumatic air tools. From finish to framing and everything in between, Senco has been making quality, professional tools since the 1950s. In addition to Senco, we carry numerous other names brands, including DeWalt and Hitachi. Come on in and see what works best for you!</span>\n" +
        "  </div>"
    },
    garden_tools: {
      "brands_bottom": [
        {
          "image": "Jeld-Wen-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Milgard-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "OrePac-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "El-El-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Mi-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Plastpro-Logo-Small.jpg",
          "title": ""
        },
      ],
      "bannerImage": {
        "image": "Doors-Windows_header_image-4pix.webp",
        "title": ""
      },
      "description": "<div class=\"textDiv\">\n" +
        "  <h1>\n" +
        "    Garden Tools for Grass Valley, CA Area Gardeners\n" +
        "  </h1>Whether you are an experienced gardener or a novice, every gardening project requires a variety of tools to get the job done right. At Hills Flat Lumber, we have all the tools you need to complete your project like a pro!<h3>\n" +
        "    &nbsp;\n" +
        "  </h3><h3>\n" +
        "    Gardening Must-Haves\n" +
        "  </h3><p>\n" +
        "    If you are just getting started, here are a few must-have gardening tools to help you achieve a professional result in your yard or <a href=\"/#/departments/nursery\">nursery</a>.\n" +
        "  </p><p class=\"Apple-style-span\">\n" +
        "    <strong>Gloves - </strong> Keep your hands protected from splinters and thorns with a quality pair of gardening gloves. You want to select a sturdy pair of gloves that fit you well and aren't too bulky. When not in use, store your gardening gloves somewhere out of the sun.\n" +
        "  </p><p class=\"Apple-style-span\">\n" +
        "    <strong>Hand Trowel - </strong>A hand trowel will help you efficiently dig around corners and remove weeds from your flower beds. Choose a stainless steel hand trowel for added durability.\n" +
        "  </p><p class=\"Apple-style-span\">\n" +
        "    <strong>Spade -</strong> A quality spade allows you to easily dig holes for planting and to move small mounds of soil from one area to another. Select a spade with a stainless steel head and a sturdy fiberglass handle.\n" +
        "  </p><p class=\"Apple-style-span\">\n" +
        "    <strong>Hoe - </strong>A quality hoe will help you loosen the soil to prepare for planting, and your choice of hoes depends on the type of garden you are planting. If you are planting a vegetable garden, a hoe with a wide head is a good choice, while a flower garden will require a smaller head.\n" +
        "  </p><p class=\"Apple-style-span\">\n" +
        "    <strong>Garden Hoses - </strong>A long garden hose with a good spray nozzle will help you deliver the right amount of water to each section of your garden. Select an adjustable nozzle to allow you to control the water pressure around delicate plants.\n" +
        "  </p><h3>\n" +
        "    Caring for Your Gardening Tools\n" +
        "  </h3><p class=\"Apple-style-span\">\n" +
        "    Keep your gardening tools in great shape with a few simple maintenance steps. After use, clean dirt and debris off the tools with a bucket of warm water and a bristle brush. Let them air dry and store them in a clean, dry location.\n" +
        "  </p><p class=\"Apple-style-span\">\n" +
        "    At Hills Flat Lumber, you can count on our knowledgeable staff members to help you find the <a href=\"/#/departments/outdoor_power_equipment\">right tools for your backyard</a> and gardening projects. Browse our great selection or come <a href=\"/#/aboutus\">visit us</a> in Grass Valley or Colfax today.\n" +
        "  </p>\n" +
        "</div>"
    },
    doors: {
      "brands_bottom": [
        {
          "image": "Jeld-Wen-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Milgard-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "OrePac-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "El-El-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Mi-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Plastpro-Logo-Small.jpg",
          "title": ""
        },
      ],
      "bannerImage": {
        "image": "Doors-Windows_header_image-4pix.webp",
        "title": ""
      },
      "description": "<div class=\"textDiv\">\n" +
        "\t\t<h1><span class=\"Apple-style-span\" style=\"color: #ed6715;\">\n" +
        "\t\t\tDoors and Windows in Colfax, CA\n" +
        "\t\t</span>\n" +
        "\t\t</h1>\t\n" +
        "\n" +
        "\t\t<span class=\"Apple-style-span\">The right windows and doors can really make a house pop. At Hills Flat Lumber, we'll help you find the right combination to perfectly accentuate your home. We can even design and build custom windows and doors to your exact specifications.\n" +
        "\t\t</span>\t\n" +
        "\n" +
        "\t\t<h3>\n" +
        "\t\t\tChoosing a Type of Door\n" +
        "\t\t</h3>\n" +
        "\n" +
        "\t\t<span class=\"Apple-style-span\">At Hills Flat Lumber, we carry traditional windows in many styles and materials, as well as skylights and solar tubes. Skylights and solar tubes are great for letting more natural light into dark spots in your home or anywhere you would like to have increased light.\n" +
        "\t\t</span>\n" +
        "\n" +
        "\t\t<h3>\n" +
        "\t\t\tTypes of Windows\n" +
        "\t\t</h3>\n" +
        "\n" +
        "\t\t<span class=\"Apple-style-span\">At Hills Flat Lumber, we carry traditional windows in many styles and materials, as well as skylights and solar tubes. Skylights and solar tubes are great for letting more natural light into dark spots in your home or anywhere you would like to have increased light.\n" +
        "\t\t</span>\n" +
        "\n" +
        "\t\t<span class=\"Apple-style-span\">Our wood windows come in both hardwood and softwood with hardwood being the more expensive and durable choice. Vinyl windows are a popular option for replacement windows as they provide excellent heat and sound insulation. Whatever the material, it is important to select windows made by a manufacturer known for quality, as many windows today are built for low cost, not for value.\n" +
        "\t\t</span>\t\n" +
        "\n" +
        "\t\t<h3>\n" +
        "\t\t\tWhy Choose Custom Doors and Windows?\n" +
        "\t\t</h3>\n" +
        "\n" +
        "\t\t<span class=\"Apple-style-span\">Custom doors and windows can provide the perfect complement to your home because they are specifically designed with your residence in mind. They can be tailored to make the best use of the available space, and at Hills Flat Lumber, we can work with you to create any design you can imagine.\n" +
        "\t\t</span>\n" +
        "\n" +
        "\t\t<span class=\"Apple-style-span\">\n" +
        "\t\t\tVisit one of our <a href=\"/#/aboutus\">locations</a> today!\n" +
        "\t\t</span>\t\t\t\t\n" +
        "\t</div>"
    },
    recreation: {
      "brands_bottom": [
        {
          "image": "Hobie-Logo-small.jpg",
          "title": ""
        },
        {
          "image": "Yeti-Logo-Small.jpg",
          "title": ""
        },
      ],
      "bannerImage": {
        "image": "Recreation-Header-Photo2.jpg",
        "title": ""
      },
      "description": "<div class=\"textDiv\">\n<h1>\n" +
        "Outdoor Recreation Products and Rentals near Nevada City, CA\n" +
        "</h1><p>\n" +
        "  The <a href=\"/#/aboutus\">Hills Flat Lumber Co.</a> is proud to include outdoor recreation equipment and supplies at both locations. To help our customers enjoy all that the great outdoors has to offer, we provide a great selection of outdoor recreation products like fishing rods and tackle, camping equipment, mining equipment and supplies and even hunting and fishing permits. We are confident that anyone who leaves our stores will be well equipped for their next outdoor adventure!\n" +
        "</p><h3>\n" +
        "  Kayaking and Stand-Up Paddle Boarding\n" +
        "</h3><p>\n" +
        "  Adhering to the Pardini family philosophy of providing superior brands and materials, Hills Flat Lumber Co. is proud to offer Hobie brand kayaks, paddle boards and accessories. With its handcrafted stand-up paddleboards and kayaks, Hobie is a trusted name in outdoor recreation.\n" +
        "</p><h3>\n" +
        "  Rental\n" +
        "</h3><p>\n" +
        "  Hills Flat Lumber believes in the idea of \"Try Before You Buy.\" Whether you are visiting the area and simply need equipment for the day, or you want the opportunity to test drive a particular product, our hourly and daily <a href=\"/#/departments/rental\">rental service</a> allows you to find the equipment that is right for your needs.\n" +
        "</p><h3>\n" +
        "  Outdoor Gear and Accessories\n" +
        "</h3><p>\n" +
        "  At Hills Flat Lumber, we carry all the outdoor tools and accessories to get the job done. With our premium brands, you can find the perfect fishing supplies, kayaking equipment, and boating accessories to serve all of your outdoor interests. To learn more about our products and services, contact us today.\n" +
        "</p>"
    },
    ponds: {
      "description": "<div class=\"textDiv\" style=\"padding-top: 50px;\"><h1>\n" +
        "  Your Source for Ponds and Water Features in Grass Valley, CA\n" +
        "</h1><p>\n" +
        "  Your backyard is a great place to welcome family and friends for barbeques, parties, and other get-togethers, and creating an outdoor space that is relaxing and inviting encourages your guests to stay longer and enjoy their visit. A pond or water feature can help you create the soothing atmosphere you desire, and the team at Hills Flat Lumber can help you make it a reality.\n" +
        "</p><h3>\n" +
        "  Benefits of a Backyard Pond\n" +
        "</h3><p>\n" +
        "  A bubbling backyard garden pond is both picturesque and environmentally friendly. You can dress up a pond anyway you like with flowering water plants, greenery, tropical fish, and decorative items – you are limited only by your imagination. Water features will increase the value of your home because homebuyers are attracted to properties with attractive and innovative outdoor features. Also, water is naturally calming, so an outdoor pond creates a relaxing oasis for you and your family. A pond provides a perfect spot to nap, read a book, or enjoy a candlelight dinner.\n" +
        "</p><h3>\n" +
        "  Building Your Backyard Pond\n" +
        "</h3><p>\n" +
        "  Installing a backyard pond isn’t as difficult or expensive as it might seem, and with the right equipment and supplies, you can have your own backyard water feature in no time. Some of the main components you will need include the liner and underlayment, pump, a filter, and a water agitator to keep the water from becoming stagnant. For ponds smaller than 6 feet on a side and no deeper than 18 inches, you can easily do the digging yourself, but you may want to hire a professional to hook up the plumbing and electrical work.\n" +
        "</p><p>\n" +
        "  We have two convenient locations in Grass Valley and Colfax, CA, and our family-owned and -operated home centers carry a huge selection of tools and supplies to help you create a beautiful, relaxing water feature. <a href=\"/en/contactus\">Come talk to our friendly experts</a> and browse our store today.\n" +
        "</p></div>"
    },
    siding_and_trim: {
      "brands_bottom": [
        {
          "image": "James-Hardie-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "LP-Smart-Side-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Shakertown-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Nichiha-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Advantage-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Real-Trim-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "kelleher.png",
          "title": ""
        },
      ],
      "bannerImage": {
        "image": "Siding_header_image-3pix.jpg",
        "title": ""
      },
      "description": "<div class=\"textDiv\"><h1>\n" +
        "  Siding At Hills Flat Lumber\n" +
        "</h1><h3>\n" +
        "  NATURAL\n" +
        "</h3><p>\n" +
        "  At Hills Flat Lumber, our 80 years of experience in selecting the premium quality suppliers of natural lumber gives you the look of your mountain dream home. From clear cedar, to select tight knot cedar and our clear redwoods, we carry many items and have over twelve different profiles in stock. Come in and check out our great selection of natural sidings.\n" +
        "</p><h3>\n" +
        "  COMPOSITE\n" +
        "</h3><p>\n" +
        "  Composite sidings offer extreme durability, weather-resistance, long lengths, and consistently straight pieces that resist warping and splitting. This, in our opinion, is your best choice for exterior siding. At Hills Flat, we offer composite siding from the leading manufacturers.\n" +
        "</p><h3>\n" +
        "  TRIM\n" +
        "</h3><p>\n" +
        "  Decorative and functional trim can make all of the difference between a ho-hum house and a stunning, custom residence. At Hills Flat, we offer a wide variety of exterior trim options. You can find molding for Victorian homes, fascias, railings, window trims, turned posts, shutters, soffits, decorative pillars, post caps and more.\n" +
        "</p><p>\n" +
        "  At Hills Flat we've been offering products from the leading suppliers of natural lumber and quality composite trims for over 80 years. Our selection of quality siding products allows you to more easily create a custom look for your Victorian home or mountain retreat.\n" +
        "</p></div>"
    },
    roofing: {
      "brands_bottom": [
        {
          "image": "MS-Metal-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Malarkey-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "ASC-Building-Products-Logo.jpg",
          "title": ""
        },
      ],
      "bannerImage": {
        "image": "roofing_header2_image.jpg",
        "title": ""
      },
      "description": "<div class=\"textDiv\"><h1>\n" +
        "  Metal &amp; Composite Roofing At Hills Flat Lumber\n" +
        "</h1><p>\n" +
        "  When it comes to roofing - we've got you covered. Come in and take a look at our wide selection of composition roofing products. And, of course, we deliver roofing supplies, including our convenient roof load service and plate line delivery.\n" +
        "</p><h3>\n" +
        "  METAL ROOFING\n" +
        "</h3><p>\n" +
        "  Metal roofing gives you a wide selection of profiles and colors to accent your home or mountain estate. Some of the main benefits of metal roofing are fire resistance, low maintenance, and durability. At Hills Flat, we stock corrugated galv-alum roofing in 8, 10, 12, 14 and 16 foot lengths, from leading manufacturers like Metal Sales.\n" +
        "</p><h3>\n" +
        "  COMPOSITION ROOFING\n" +
        "</h3><p>\n" +
        "  Composite roofing offers an affordable and highly functional roofing option. Today's choices in composite roofing are impressive. Many products now offer a dimensional appearance that can improve the visual appeal of your home.\n" +
        "</p></div>"
    },
    lumber: {
      "brands_bottom": [
        {
          "image": "Roseburg-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Pacific-Wood-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Tyvek-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Humboldt-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Trus-Joist-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Redwood-Empire-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Allweather-Logo-Small.jpg",
          "title": ""
        },
      ],
      "description": "<div class=\"textDiv\" style=\"padding-top: 50px;\"><h1>\n" +
        "  Top-Quality Lumber Supplies in Northern California\n" +
        "</h1><p>\n" +
        "  <img src=\"/images/info_pages/Lumber_header_image-3pix-copy.jpg\">\n" +
        "</p><h3>\n" +
        "  Pressure Treated Lumber\n" +
        "</h3><p>\n" +
        "  Hills Flat Lumber is the largest pressure treated lumber dealer in Northern CA. While other yards need to special order the material you need…we have it IN STOCK! All pressure treated materials are kept in covered storage, protected from the sun &amp; rain with EASY drive thru access. We do not sell twisted, checked boards.\n" +
        "</p><p>\n" +
        "  Naturally strong and durable, Allweather Wood pressure treated lumber is a proven building material for a wide range of commercial, industrial, and residential applications. No matter what you're building, it's going to have to face the natural elements – air, fire, earth, and water, insects, mold, and decay. Allweather Wood pressure treated lumber is ready for whatever nature brings your way.\n" +
        "</p><p style=\"text-align: center;\">\n" +
        "  <strong>For more information please contact our Pro Sales Department:</strong>\n" +
        "</p><p style=\"text-align: center;\">\n" +
        "  Grass Valley Store: (530) 273-6171 ext. 123\n" +
        "</p><p style=\"text-align: center;\">\n" +
        "  Colfax Store: (530) 346-8685 ext. 220\n" +
        "</p><p style=\"text-align: center;\">\n" +
        "  &nbsp;\n" +
        "</p><h3>\n" +
        "  Pressure Treated Douglas Fir In Stock\n" +
        "</h3><div class=\"logosDiv\">\n" +
        "  <div class=\"cpimageadjust\">\n" +
        "    <img src=\"/images/info_pages/pressure-treated-2x-graph.jpg\" style=\"min-width: 250px; width: 30%;\"> <img src=\"/images/info_pages/pressure-treated-4x-graph.jpg\" style=\"min-width: 250px; width: 30%;\"> <img src=\"/images/info_pages/pressure-treated-6x1.jpg\" style=\"min-width: 170px; width: 17%;\">\n" +
        "  </div><h3>\n" +
        "    Other Pressure Treated Inventory In Stock\n" +
        "  </h3><div class=\"logosDiv\">\n" +
        "    <div class=\"cpimageadjust\">\n" +
        "      <img src=\"/images/info_pages/Pressure-Treated-Spruce-Grid.webp\" style=\"width: 32%; min-width:250px;\"> <img src=\"/images/info_pages/doweled-lodge-poles.jpg\" style=\"width: 19%; min-width:190px;\">\n" +
        "    </div>\n" +
        "  </div><div class=\"cp-borders\">\n" +
        "    <h3>\n" +
        "      Always In Stock and Ready for Pickup or Delivery\n" +
        "    </h3><ul>\n" +
        "      <li>\n" +
        "        25' Class 5 Power Poles\n" +
        "      </li><li>\n" +
        "        Temporary job site power poles with or without service panels. In stock and ready for pickup or delivery.\n" +
        "      </li><li>\n" +
        "        6'x 8' Landscape Timbers\n" +
        "      </li><li>\n" +
        "        2\" x 8' Tree Stakes\n" +
        "      </li>\n" +
        "    </ul>\n" +
        "  </div><div class=\"cp-borders\">\n" +
        "    <h3>\n" +
        "      Engineered Wood\n" +
        "    </h3><p>\n" +
        "      Engineered wood products provide outstanding excellent performance for a reasonable cost, reduces the use of natural resources and minimizes waste on the job site. With engineered wood you will know the precise strength of every piece, taking all of the guesswork out of building a stronger, silent floor. It's that simple.\n" +
        "    </p><p>\n" +
        "      Find out everything you ever wanted to know about engineered lumber (but were afraid to ask) by talking with one of our knowledgeable, trained staff.\n" +
        "    </p>\n" +
        "  </div><div class=\"cp-borders\">\n" +
        "    <h3>\n" +
        "      Flashing\n" +
        "    </h3><p>\n" +
        "      The primary cause of moisture damage in a commercial or residential building is water intrusion through the interface details around windows, doors, and other exterior penetrations. Water intrusion also represents the number-one reason for warranty callbacks and customer dissatisfaction in new home construction.\n" +
        "    </p><p>\n" +
        "      Flashing, properly installed and integrated with a weather-resistive barrier, is one of the most important factors in the successful performance of exterior walls.\n" +
        "    </p>\n" +
        "  </div><div class=\"cp-borders\">\n" +
        "    <h3>\n" +
        "      Framing Lumber\n" +
        "    </h3><p>\n" +
        "      At Hills Flat Lumber, we take pride in offering a choice of high quality lumber. Our framing lumber is the best available.\n" +
        "    </p><p>\n" +
        "      Our timbers are #1 &amp; Better FOHC (Free Of Heart Center) anti-stain treated. This means straighter walls, doors and windows.\n" +
        "    </p><p>\n" +
        "      Truss joist MacMillan is our manufacturer of high-quality, engineered lumber. Our pressure treated material is Naturewood - 40 ground contact in everything from 2x4 through 2x12, and 4x4 through 4x12.\n" +
        "    </p>\n" +
        "  </div>\n" +
        "</div><p>\n" +
        "  &nbsp;\n" +
        "</p></div>"
    },
    paint: {
      "brands_bottom": [
        {
          "image": "Pratt-Lambert-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Sherwin-Williams-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Do-It-Best-Logo-Small (1).jpg",
          "title": ""
        },
        {
          "image": "Penofin-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Zinsser-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Superdeck-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Preserva-Wood-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Rustoleum-Logo-Small.jpg",
          "title": ""
        }
      ],
      "description": "<div class=\"textDiv\" style=\"padding-top: 50px;\"><h1>\n" +
        "  All Your Paint, Stain, and Equipment Needs in Grass Valley and Colfax, CA\n" +
        "</h1><p>\n" +
        "  <img src=\"/images/info_pages/paint_header_image-4pix.jpg\">\n" +
        "</p><p>\n" +
        "  Need a quick coat of color to brighten up your home? How about power sprayers, scaffolding, and tarps to knock out the big jobs? Hills Flat Lumber has the supplies, tools, and how-to knowledge you need to get the job done right.\n" +
        "</p><h3>\n" +
        "  Paint and Stain\n" +
        "</h3><p>\n" +
        "  We carry interior and exterior paints and stains from the top manufacturers like Best Look, Pratt &amp; Lambert, Purdy brushes and much more. When choosing a product from our extensive selection, our paint consultants can help you find the best products for your specific project. From wall prep materials to primer, plus a huge selection of paint in all sheens and colors, Hills Flat Lumber has everything you’ll need. When choosing paint, you need to consider the lighting, color flow, and texture of the area. With paints and stains from our selection, you can create the color transition and contrast you desire.\n" +
        "</p><h3>\n" +
        "  Paint Supplies\n" +
        "</h3><p>\n" +
        "  Picking out the paint is the easy part; now you’ve got to get it on the wall. The right tools make all the difference, and devoting effort to the prep work saves time in the long run. We have a selection of painting supplies and accessories including brushes, tarps, buckets, rollers, poles, sanding equipment, caulk, and high-quality painter’s tape to pull off professional looking jobs every time.\n" +
        "</p><h3>\n" +
        "  Rentals\n" +
        "</h3><p>\n" +
        "  If you have a big project that requires the right equipment, be sure to visit our Rental Department. We rent all the equipment you’ll need to tackle the toughest jobs, including scaffolding, sprayer guns, power rollers, ladders, tarps, and more. Renting painting equipment just makes sense…you are free from costs associated with equipment ownership, like maintenance and storage fees. Plus, you will always have access to the latest equipment that is best suited to your project.\n" +
        "</p><p>\n" +
        "  With decades of experience, Hills Flat Lumber is your destination for all your painting needs. Visit us in Colfax or Grass Valley, CA today.\n" +
        "</p><p>\n" +
        "  &nbsp;\n" +
        "</p></div>"
    },
    outdoor_power_equipment: {
      "description": "<div class=\"textDiv\" style=\"padding-top: 50px;\" ><div class=\"topDiv\">\n" +
        "  <a><img alt=\"\" src=\"/images/info_pages/tractor.jpg\" style=\"width: 28%; padding-right:1%;\"></a><a><img alt=\"\" src=\"/images/info_pages/chainsaw.jpg\" style=\"padding-right: 1%; width: 46.5%;\"></a><a><img alt=\"\" src=\"/images/info_pages/person.jpg\" style=\"width: 22%;\"></a>\n" +
        "</div><h2>\n" +
        "  Outdoor Power Equipment Sales near Auburn, CA\n" +
        "</h2><p>\n" +
        "  Hills Flat Lumber provides outdoor power equipment and tools to homeowners and contractors in Auburn, CA. We strive to provide our customers with only the highest quality products from top brands.\n" +
        "</p><h3>\n" +
        "  Power Products and Tools\n" +
        "</h3><p>\n" +
        "  We're proud to carry products from the industry's leading manufacturers. Some of our best-selling tools include STIHL's gas-powered outdoor power equipment. No job is too big or too small for STIHL's line of reliable chainsaws, trimmers, leaf blowers, pole saws and more. Our Husqvarna outdoor power products are also very popular among buyers. Our inventory includes garden tractors, trimmers, chainsaws, robotic lawn mowers and other more.\n" +
        "</p><p>\n" +
        "  We keep up with the latest in industry developments in order to provide our customers with quality products that can tackle any type of job. View our online inventory of products or talk to a sales associate to locate the tool or power equipment you need.\n" +
        "</p><h3>\n" +
        "  Power Equipment Rentals\n" +
        "</h3><p>\n" +
        "  Many of our outdoor power equipment and tools are <a href=\"/#/departments/rental\">available for rent</a> by the hour, half-day, full day, and week. From large excavation equipment like tractors, backhoes, and bobcats, to smaller power tools like drills and chainsaws, our top-quality items are available for rent and delivery seven days a week.\n" +
        "</p><h3>\n" +
        "  Our Service Department\n" +
        "</h3><p>\n" +
        "  We do more than sell tools and power equipment. Our team of experienced, factory-trained service technicians is highly qualified to repair not just the equipment we sell, but most major makes and models. We also carry a huge selection of the repair parts you need to get your tools back up and running.\n" +
        "</p><p>\n" +
        "  <a href=\"/#/aboutus\">Hills Flat Lumber</a> offers a huge inventory of outdoor power equipment and tools available for purchase or rent. Contact us today or visit our store to view our inventory!\n" +
        "</p></div>",
      "brands_bottom": [
        {
          "image": "Husqvarna-Logo-Small-White.jpg",
          "title": ""
        },
        {
          "image": "Stihl-Logo-Small-White.jpg",
          "title": ""
        }
      ],
    },
    rental: {
      "brands_bottom": [
        {
          "image": "Bobcat-Logo-Small.png",
          "title": ""
        },
        {
          "image": "Kubota-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Barreto-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Rental-Delivery.jpg",
          "title": ""
        },
        {
          "image": "Stihl-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "DeWalt-Logo-Small (1).jpg",
          "title": ""
        },
        {
          "image": "Senco-Logo-Small (1).jpg",
          "title": ""
        },
        {
          "image": "Milwaukee-Logo-Small.jpg",
          "title": ""
        }
      ],
      "description": "<div class=\"textDiv\" style=\"padding-top: 50px;\"><h1>\n" +
        "  Equipment Rental in Grass Valley and Colfax, CA\n" +
        "</h1><p>\n" +
        "  <img src=\"/images/info_pages/Rental_header_image2.jpg\">\n" +
        "</p><h3>\n" +
        "  Rentals Are Available by Hour, Half Day, Full Day, or Week\n" +
        "</h3><p>\n" +
        "  Whether you are a contractor or a do-it-yourselfer, Hills Flat Lumber has a full line of rental tools and equipment to help you get the job done. When it's time for excavation, you can rent <strong>tractors, backhoes, trenchers and bobcats.</strong> There's no need to buy it and store it - just arrange for a rental from Hills Flat!\n" +
        "</p><p>\n" +
        "  Any home repair or building project requires a wide range of tools, and you can purchase the tools you need from Hills Flat, or you can rent the right tool for the job. We also rent scaffolding.\n" +
        "</p><p>\n" +
        "  Our Yard &amp; Garden center makes landscape projects a breeze with a wide assortment of tools for rent, including trenchers, post hole diggers, cultivators, rototillers, sod lane tools, and so much more.\n" +
        "</p><p>\n" +
        "  We're unlike other rental centers, because we sell our rentals frequently, and replace them with new tools. It's just one more way that Hills Flat Lumber ensures we pass on top quality, reliable tools at reasonable prices to our customers.\n" +
        "</p></div>"
    },
    nursery: {
      "brands_bottom": [
        {
          "image": "Scotts-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Raindrip-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "Neverkink-Logo-Small.jpg",
          "title": ""
        },
        {
          "image": "foxfarm (2).jpg",
          "title": ""
        },
      ],
      "description": "<div class=\"textDiv\" style=\"display: flex; padding-top: 50px;\"><div class=\"cpleftblock\" style=\"padding-top: 20px;\">\n" +
        "  <img src=\"/images/info_pages/Nursery-Wagon-Med1.webp\">\n" +
        "</div><div class=\"cpblockright\">\n" +
        "  <h1 style=\"font-size: 1.8em;\">\n" +
        "    Grass Valley and Colfax, CA's Favorite Nursery\n" +
        "  </h1><p>\n" +
        "    Hills Flat Lumber is your source in the Grass Valley area for everything you need to keep your yard looking beautiful all year long. Our diverse selection of products includes a wide variety of plants, potting supplies, and yard decorations, and our <a href=\"/#/aboutus\">friendly and knowledgeable staff</a> are happy to help you select just the right items for your needs.\n" +
        "  </p><h3>\n" +
        "    Indoor Plant Options\n" +
        "  </h3><p>\n" +
        "    Indoor plants are not only great for decorating, but they also help keep the indoor air fresh and clean. And growing plants indoors is easier than you might think - we have a number of options that are both beautiful and easy to care for, whether you are a new to gardening or a seasoned pro. Add a touch of elegance to any room with English Ivy or bring the tropics home with an Areca Palm. Whatever the look you are trying to create, you will find great options at Hills Flat Lumber.\n" +
        "  </p><h3>\n" +
        "    Outdoor Plant Options\n" +
        "  </h3><p>\n" +
        "    Our outdoor plant selection includes perennials and annuals, ornamental trees and shrubs, fruit trees, evergreens, bulbs and bedding plants, soils, and so much more. And our drought-resistant plant options allow you to create a beautiful, colorful landscape while cutting back on your water usage. Drought-resistant plant varieties include daylilies, coneflowers, shrub roses, redbud trees, sugar maples, and so many others. You are only limited by your imagination.\n" +
        "  </p><p>\n" +
        "    Whatever your gardening needs, you are sure to find just what you are looking for at Hills Flat Lumber. <a href=\"/#/aboutus\">Come down and check out</a> the Nursery Department in Grass Valley or Colfax today.\n" +
        "  </p>\n" +
        "</div><p>\n" +
        "  &nbsp;\n" +
        "</p></div>"
    }
  };

export default {
  getDepartments (page, limit, dept_id) {
    let params = {
      page,
      limit
    };
    if (dept_id) {
      params.dept_id = dept_id;
    }
    return Axios.get (ENDPOINTS.MAIN, {params});
  },
  getInfoPage(name) {
    return pages[name];
  }
};
