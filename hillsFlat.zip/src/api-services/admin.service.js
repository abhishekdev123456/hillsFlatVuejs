import Axios from 'axios';
import store from '@/store';

const ENDPOINTS = {
  ABOUTUS: {
    SAVE: 'about-us/save',
    GET: 'about-us'
  },
  POSINFO: {
    SAVE: 'pos-settings/save',
    GET: 'pos-settings/stores'
  },
  SOCIAL: {
    UPDATE: 'social/update'
  },
  ORDERS: {
    OUTSTANDING: 'admin/orders/outstanding', // 'admin/orders/outstanding/v2',
    COMPLETED: 'admin/orders/completed',
    ORDER: 'admin/orders/'
  },
  FULFILLMENT: {
    DELIVERY: 'admin/fulfillment/delivery',
    SHIPPING: 'admin/fulfillment/shipping',
    PICKUP: 'admin/fulfillment/pickup'
  }
};

export default {
  getAbout() {
    return Axios.get(ENDPOINTS.ABOUTUS.GET, {
      headers: {
        'Business-Slug': store.state.business_slug
      }
    });
  },
  saveAbout(data) {
    return Axios.post(ENDPOINTS.ABOUTUS.SAVE, data, {
      headers: {
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        'Business-Slug': store.state.business_slug
      }
    });
  },

  getPosInfo() {
    return Axios.get(ENDPOINTS.POSINFO.GET, {
      headers: {
        'Business-Slug': store.state.business_slug
      }
    });
  },
  savePosInfo(data) {
    return Axios.post(ENDPOINTS.POSINFO.SAVE, data, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        'Business-Slug': store.state.business_slug
      }
    });
  },

  updateSocialLink(data) {
    return Axios.post(ENDPOINTS.SOCIAL.UPDATE, data, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        'Business-Slug': store.state.business_slug
      }
    });
  },
  updateFulfillmentDelivery(data) {
    return Axios.post(ENDPOINTS.FULFILLMENT.DELIVERY, data, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        'Business-Slug': store.state.business_slug
      }
    });
  },
  updateFulfillmentShipping(data) {
    return Axios.post(ENDPOINTS.FULFILLMENT.SHIPPING, data, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        'Business-Slug': store.state.business_slug
      }
    });
  },
  updateFulfillmentPickup(data) {
    return Axios.post(ENDPOINTS.FULFILLMENT.PICKUP, data, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        'Business-Slug': store.state.business_slug
      }
    });
  },
  getOutstandingOrders(data) {
    let params = data ? `?types=${data}` : '';
    return Axios.get(ENDPOINTS.ORDERS.OUTSTANDING + params, {
      headers: {
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
      }
    });
  },
  getCompletedOrders(data = {}) {
    return Axios.get(ENDPOINTS.ORDERS.COMPLETED, {
      headers: {
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
      },
      params: data
    });
  },
  getOrder(id = '', itemIds) {
    let itemIds_param = itemIds ? `?itemIds=${itemIds}` : '';
    return Axios.get(ENDPOINTS.ORDERS.ORDER + id + itemIds_param, {
      headers: {
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
      },
    });
  },
  markPrepared(id) {
    return Axios.post(`admin/orders/${id}/markPrepared`, {}, {
      headers: {
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
      },
    });
  }
};
