import Axios from 'axios';
import store from '@/store';

const ENDPOINTS = {
  GET_ORDERS: 'orders',
  GET_ORDER_DETAILS: 'orders/order',
  SUBMIT_CUSTOMER_ORDER: 'customer/orders/submit'
};

export default {
  getOrders() {
    let queryString = '';
    let activeUser = store.state.activeUser;

    if (activeUser) {
      queryString = 'customer_slug=' + activeUser.data.customer.slug;
    }

    return Axios.get(`${ENDPOINTS.GET_ORDERS}?${queryString}`);
  },
  getOrderDetails(id) {
    let queryString = 'param=' + id;

    return Axios.get(`${ENDPOINTS.GET_ORDER_DETAILS}?${queryString}`);
  },
  submitCustomerOrder(data) {
    data.device_id = store.state.device_id;
    return Axios.post(`${ENDPOINTS.SUBMIT_CUSTOMER_ORDER}`, data);
  }
};
