import Axios from 'axios';

const PREFIX_BRANDS = '/brands';
const PREFIX_SINGLE_BRAND = '/brand';

const ENDPOINTS = {
  FETCH: 'brands',
  PRODUCTS: 'products',
  VIDEOS: 'videos'
};

export default {
  getBrands(page, limit, search, sort) {
    let params = {
      page,
      limit,
      sort
    };
    if (search) {
      params.search = search;
    }
    return Axios.get(`${PREFIX_BRANDS}`, { params });
  },
  getBrandById(id) {
    return Axios.get(`${PREFIX_BRANDS}/brand?param=${id}`);
  },
  getProducts(brand_id, page, limit, sort, searchQuery = '') {
    let params = {
      param: brand_id,
      page: page,
      limit: limit,
      search: searchQuery
    };
    if (sort) {
      params.sort = sort;
    }
    return Axios.get(`${PREFIX_SINGLE_BRAND}/${ENDPOINTS.PRODUCTS}`, { params });
  },
  getImages(brand_id, page, limit) {
    let params = {
      param: brand_id,
      page,
      limit
    };

    return Axios.get(`${PREFIX_SINGLE_BRAND}/${ENDPOINTS.PRODUCTS}`, { params });
  },
  getVideos(brand_id) {
    return Axios.get(`${PREFIX_BRANDS}/${brand_id}/${ENDPOINTS.VIDEOS}`);
  }
};
