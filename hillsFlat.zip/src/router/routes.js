import AuthController from '@/controllers/auth.controller';

function loadPage(page) {
  return () => import(/* webpackChunkName: "page-[request]" */ `@/pages/${page}.vue`);
}
async function requireAuth(to, from, next) {
  let auth = await AuthController.checkAuthStatus().is_admin;
  if(!auth)
    return next({
      name: 'index'
    });
  return next();
}

export const routes = [
  {
    path: '/',
    name: 'index',
    component: loadPage('index')
  },
  {
    path: '/register',
    name: 'register',
    component: loadPage('auth/register'),
  },
  {
    path: '/login',
    name: 'login',
    component: loadPage('auth/login'),
  },
  {
    path: '/forgot-password',
    name: 'forgot-password',
    component: loadPage('auth/forgot-password'),
  },
  {
    path: '/reset-password',
    name: 'reset-password',
    component: loadPage('auth/reset-password'),
  },
  {
    path: '/cart',
    name: 'cart',
    component: loadPage('cart')
  },
  {
    path: '/products/:id/:title',
    name: 'products-id',
    component: loadPage('products/single')
  },
  {
    path: '/departments',
    name: 'departments',
    component: loadPage('departments/main'),
  },
  {
    path: '/departments/:id',
    name: 'departments-id',
    component: loadPage('departments/single'),
  },
  {
    path: '/department/:id/:title',
    name: 'department-products',
    component: loadPage('department-products')
  },
  {
    path: '/search',
    name: 'search',
    component: loadPage('search'),
    props: (route) => ({
      keyword: route.query.keyword,
      deptId: route.query.deptId,
      deptName: route.query.deptName
    })
  },
  {
    path: '/brands',
    name: 'brands',
    component: loadPage('brands/index'),
    props: (route) => ({
      keyword: route.query.keyword
    })
  },
  {
    path: '/brands/:id',
    name: 'brands-id',
    component: loadPage('brands/single'),
    props: (route) => ({
      brandProp: route.params.brand
    })
  },
  {
    path: '/settings',
    name: 'settings-index',
    redirect: '/settings/account',
    component: loadPage('settings/index'),
    children: [
      {
        path: '/orders',
        name: 'settings-orders',
        component: loadPage('settings/orders')
      },
      {
        path: '/account',
        name: 'settings-account',
        component: loadPage('settings/account')
      },
      {
        path: '/payment',
        name: 'settings-payment',
        component: loadPage('settings/account')
      },
    ]
  },
  {
    path: '/aboutus',
    name: 'about-us',
    component: loadPage('aboutus/index')
  },
  {
    path: '/terms',
    name: 'terms',
    component: loadPage('terms')
  },
  {
    path: '/virtual_tour',
    name: 'virtual-tour',
    component: loadPage('virtual-tour')
  },
  {
    path: '/admin',
    name: 'admin',
    redirect: 'admin/orders',
    meta: {
      layout: 'admin',
      permission: 'admin'
    },
    beforeEnter: requireAuth
  },
  {
    path: '/admin/settings',
    name: 'admin-settings',
    redirect: 'admin/settings/about-us',
    component: loadPage('admin/settings'),
    meta: {
      layout: 'admin',
      permission: 'admin'
    },
    beforeEnter: requireAuth,
    children: [
      {
        path: 'about-us',
        name: 'admin-settings-about-us',
        component: loadPage('admin/settings/about-us'),
        meta: {
          layout: 'admin',
          permission: 'admin'
        },
        beforeEnter: requireAuth
      },
      {
        path: 'pos-data-syncer',
        name: 'pos-data-syncer',
        component: loadPage('admin/settings/pos-data-syncer'),
        meta: {
          layout: 'admin',
          permission: 'admin'
        },
        beforeEnter: requireAuth
      },
      {
        path: 'fulfillment-options',
        name: 'fulfillment-options',
        component: loadPage('admin/settings/fulfillment-options'),
        meta: {
          layout: 'admin',
          permission: 'admin'
        },
        beforeEnter: requireAuth
      },
      {
        path: 'social-media-accounts',
        name: 'social-media-accounts',
        component: loadPage('admin/settings/social-media-accounts'),
        meta: {
          layout: 'admin',
          permission: 'admin'
        },
        beforeEnter: requireAuth
      },
      {
        path: 'tax-settings',
        name: 'tax-settings',
        component: loadPage('admin/settings/tax-settings'),
        meta: {
          layout: 'admin',
          permission: 'admin'
        },
        beforeEnter: requireAuth
      },
      {
        path: 'bank',
        name: 'admin-settings-bank',
        component: loadPage('admin/settings/bank'),
        meta: {
          layout: 'admin',
          permission: 'admin'
        },
        beforeEnter: requireAuth
      }
    ]
  },
  {
    path: '/admin/orders',
    name: 'admin-orders',
    component: loadPage('admin/orders'),
    meta: {
      layout: 'admin'
    }
  },
  {
    path: '/admin/prepare-order',
    name: 'admin-prepare-order',
    component: loadPage('admin/prepare-order'),
    meta: {
      layout: 'admin'
    }
  },
  // {
  //   path: '/admin/stats',
  //   name: 'admin-stats',
  //   component: loadPage('admin/stats'),
  //   meta: {
  //     layout: 'admin'
  //   }
  // },

  {
    path: '*',
    redirect: '/'
  }
];
