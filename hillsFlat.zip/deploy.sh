#!/bin/sh

cd /home/heyads/www-hillsflatlumber
if [ -d dist ]; then
    rm -rf public-site
    cp -R dist public-site
    cp .htaccess public-site/
fi
